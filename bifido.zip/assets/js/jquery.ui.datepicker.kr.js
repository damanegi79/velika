jQuery(function($)
{
	var holidays = {
    "0101":{type:0, title:"신정", year:""},
    "0301":{type:0, title:"삼일절", year:""},
    "0505":{type:0, title:"어린이날", year:""},
    "0606":{type:0, title:"현충일", year:""},
    "0815":{type:0, title:"광복절", year:""},
    "1003":{type:0, title:"개천절", year:""},
    "1009":{type:0, title:"한글날", year:""},
    "1225":{type:0, title:"크리스마스", year:""},
 
    "0209":{type:0, title:"설날", year:"2013"},
    "0210":{type:0, title:"설날", year:"2013"},
    "0211":{type:0, title:"설날", year:"2013"},
    "0918":{type:0, title:"추석", year:"2013"},
    "0919":{type:0, title:"추석", year:"2013"},
    "0920":{type:0, title:"추석", year:"2013"},
    "0517":{type:0, title:"석가탄신일", year:"2013"}
	};


    $.datepicker.regional['ko'] = {
                closeText: '닫기',
                prevText: '',
                nextText: '',
                currentText: '오늘',
                monthNames: ['01','02','03','04','05','06','07','08','09','10','11','12'],
                monthNamesShort: ['01','02','03','04','05','06','07','08','09','10','11','12'],
                dayNames: ['일','월','화','수','목','금','토'],
                dayNamesShort: ['일','월','화','수','목','금','토'],
                dayNamesMin: ['일','월','화','수','목','금','토'],
                weekHeader: 'Wk',
                dateFormat: 'yy-mm-dd',
                firstDay: 0,
                isRTL: false,
                showMonthAfterYear: true,
                yearSuffix: '.'};
        $.datepicker.setDefaults($.datepicker.regional['ko']);
		$.datepicker.setDefaults({beforeShowDay:function(day) 
		{
			var date = new Date();
            var result;
           
            var holiday = holidays[$.datepicker.formatDate("mmdd",day )];
            var thisYear = $.datepicker.formatDate("yy", day);
 
           
            if (holiday) {
                if(thisYear == holiday.year || holiday.year == "")
				{
					if (day < date) result =  [true, "date-holiday", holiday.title];
					else            result =  [true, "date-holiday", holiday.title];
                }
            }

            if(!result)
			{
                switch (day.getDay()) {
                    case 0: 
                        if (day < date)   result = [true, "date-sunday"];
						else              result = [true, "date-sunday"];
                        break;
                    case 6: 
						if (day < date)   result = [true, "date-saturday"];
						else              result = [true, "date-saturday"];
                        break;
                    default:
                        if (day < date)   result = [true, ""];
						else              result = [true, ""];
                        break;
                }
            }
 
            return result;
        }});
		
});
