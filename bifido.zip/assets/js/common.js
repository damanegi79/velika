var popupWidth = 0;
var tabEvent = jQuery.Event( "tabchange" );
tabEvent.target = null;

$(function()
{
	$(".blind_con").css({opacity:0.6, display:"none"});
	$(".modalBg").css({opacity:0.3, display:"none"});
	$(".blind_con").bind("touchmove", function (e){ e.preventDefault();});
	$(".alert_mesage_con").bind("touchmove", function (e){ e.preventDefault();});
	$(".modalBg").bind("touchmove", function ( e ){ e.preventDefault()});
	$("input[type='checkbox']").iCheck({handle:"checkbox"});
	$("input[type='radio']").iCheck({handle:"radio"});
	$("input[type='checkbox']").on("ifChecked", function (e)
	{
		$(this).attr("checked", true);
		$(this).change();
	});
	$("input[type='checkbox']").on("ifUnchecked", function (state)
	{
		$(this).attr("checked", false);
		$(this).change();
	});
	$("input[type='radio']").on("ifChecked", function (e)
	{
		$(this).attr("checked", true);
		$(this).change();
	});
	$("input[type='radio']").on("ifUnchecked", function (state)
	{
		$(this).attr("checked", false);
		$(this).change();
	});


	$(".pagination .first a, .pagination .last a, .pagination .next a, .pagination .prev a").text("");
	$(".tab_pannel").each(function ( i )
	{
		var tab = $(this);
		$(this).find("li a").bind("click", function ( e )
		{
			if($(this).parent().hasClass("on")) return;
			tab.find("li").removeClass("on");
			$(this).parent().addClass("on");
			tabEvent.target = $(this).parent();
			tab.trigger(tabEvent);
		});
	});
	

	$(".emt").text("");
	$('input[type="text"]').placeholder({color:"#aaa"});
	$('input[type="password"]').placeholder({color:"#aaa"});
	$('textarea').placeholder({color:"#aaa"});
	$(".datepicker_btn input[type='date']").css({opacity:0});
	$(window).resize( resizeWindow );
	$(window).resize();
} );


function addCheckBox( obj )
{
	obj.iCheck({handle:"checkbox"});
	obj.on("ifChecked", function (e)
	{
		$(this).attr("checked", true);
		$(this).change();
	});
	obj.on("ifUnchecked", function (state)
	{
		$(this).attr("checked", false);
		$(this).change();
	});
}


function addRadio( obj )
{
	obj.iCheck({handle:"radio"});
	obj.on("ifChecked", function (e)
	{
		$(this).attr("checked", true);
		$(this).change();
	});
	obj.on("ifUnchecked", function (state)
	{
		$(this).attr("checked", false);
		$(this).change();
	});
}



function resizeWindow ( e )
{
	resizePopup($(".modalPopupContainer"));
	resizePopup($(".alert_mesage"));
	resizePopup($(".alert_file"));
	
	$(".tab_pannel").each(function ( i )
	{
		if(!isMobile)
		{
			$(this).find("li").css({width:(($(this).parent().width()/$(this).find("li").length)+(8/($(this).find("li").length-1)))-21});
		}
		else
		{
			$(this).find("li").css({width:$(this).parent().width()/$(this).find("li").length});
		}
	});
	$(".loading_con").css({left:($(window).width()-$(".loading_con").width())/2, top:($(window).height()-$(".loading_con").height())/2})
}

function openPopup( path )
{
	if(isMobile)
	{
		showWindowPop("popup", path+"?mobile", $(window).width(), $(window).height());
	}
	else
	{
		openModalPopup( path );
	}
	
}


// 모달팝업 띄우기 
function openModalPopup ( url )
{
	closeModalPopup();
	showPopupFlag = true;
	$.get(url, function ( data )
	{
		$(".blind_con").css({"display":"block", opacity:0.3});
		$(".modalPopupContainer").css({display:"block"});
		$(".popupCon").empty();
		$(".popupCon").append( data );
		$(".popupCon").css({width:$(".popupCon").find(".popup_frame").width(), height:$(".popupCon").find(".popup_frame").height()});
		resizePopup($(".modalPopupContainer"));
		startPopupAnimation( $(".modalPopupContainer"));
		$(".blind_con").unbind("mousedown");
		$(".blind_con").bind("mousedown", function ( e )
		{
			closeModalPopup();
		});
	});
	$("body").unmousewheel(mouseweelFn);
}

function showLoading()
{
	$(".loading_con").css({"display":"block"});
	$(".blind_con").css({"display":"block", opacity:0.3});
}


function hideLoading()
{
	$(".loading_con").css({"display":"none"});
	$(".blind_con").css({"display":"none"});
}


// 모달팝업 닫기
function closeModalPopup()
{
	$("body").mousewheel(mouseweelFn);
	showPopupFlag = false;
	$(".blind_con").css({"display":"none"});
	$(".popupCon").empty();
	$(".popupCon").css({width:"", height:""});
	$(".modalPopupContainer").css({display:"none"});
	$(".blind_con").unbind("mousedown");
}


//팝업 모션
function startPopupAnimation( tar )
{
	
	if($.browser.webkit)
	{
		tar.css({"-webkit-transform":"scale3d(0.7,0.7,1)", opacity:0});
		TweenMax.to(tar, 0.8, {delay:0.2, "-webkit-transform":"scale3d(1,1,1)", ease:Elastic.easeOut, 
		onStart:function ()
		{
			tar.css({opacity:1});
		}
		,onComplete:function ()
		{
			tar.css({"-webkit-transform":""});
		}});
	}
	else if($.browser.mozilla)
	{
		TweenMax.to(tar, 0, {scaleX:0.7, scaleY:0.7, opacity:0});
		TweenMax.to(tar, 0.8, {delay:0.2, scaleX:1, scaleY:1, ease:Elastic.easeOut, onStart:function (){ tar.css({opacity:1});}});
	}
	else 
	{
		tar.css({opacity:0});
		TweenMax.to(tar, 0.4, {opacity:1});
	}
}


function resizePopup( target )
{
	if(target)
	{
		var w = target.width();
		var h = target.height();

		var x = ($(window).width() - w)/2;
		var y = ($(window).height() - h)/2;

		if(y<0) y =0;

		target.css ( { left:x , top:y } );
	}
	
}



function checkDevice()
{
    var mobileKeyWords = new Array('iphone', 'ipod', 'blackberry', 'android', 'windows ce', 'lg', 'mot', 'samsung', 'sonyericsson', 'pantech' );
    var device_name = "";
    for (var word in mobileKeyWords)
	{
        if (navigator.userAgent.toLowerCase().match( mobileKeyWords[word] ) != null)
		{
            device_name = mobileKeyWords[word];
            break;
        }
    }
	return device_name;
}


function showWindowPop(id, src, ww, hh)
{
	ww=parseInt(ww);
	hh=parseInt(hh);
	var left = (screen.availWidth - ww) / 2;
	var top = (screen.availHeight - hh) / 2;
	window.open (src, id, "width="+ww+"px, height="+hh+"px, left="+left+"px, top="+top+"px, resizable=no,status=no,scrollbars=no,menubar=no");
}


function getParameter (url, param)
{
	var p = url.split("?")[1];
	if(!p) return "";

	var s = p.split( param + "=" )[1];
	if(s)
	{
		var s2 = s.split("&")[0];
		return s2;
	}

	return s;
}



//커스텀 유틸
function Utils(){}

Utils.tabSizing = function (target, width, margin)
{
	target.css({width:((width/target.length)-margin)});
}


Utils.autoIframeHeight = function ( iframe )
{
	iframe.height = $(iframe).contents().height();
}

Utils.printer = function ( )
{
	var strFeature = "width="+$(window).width()+"px, height="+$(window).height()+"px, all=no";
	var objWin = window.open('', 'print', strFeature);
	$(objWin.document.body).css({"-webkit-print-color-adjust":"exact"});
	$(objWin.document.body).html($(".popup_frame .pop_list.intake").html());
	$(objWin.document.body).find(".print_btn").empty();
	$(objWin.document.body).find("img").each(function ()
	{
		var path = $(this).attr("src");
		$(this).attr("src", rootPath.substr(0, rootPath.length-1)+path);
	});
	objWin.print();
	return false;
	objWin.close();
}







//에니메이션 유틸
function AnimationUtils(){}


//달력
AnimationUtils.setDatepicker  = function( container, btnCon )
{
	var openFlag = false;

	 container.hide();
	 container.datepicker({onSelect:function (date)
	 {
		btnCon.find(".date_txt").val(date);
		$(".datepicker").hide();
		$(".blind_con").unbind("mousedown");
		$(".blind_con").css({display:"none"});
		openFlag = false;
	 }});

	 btnCon.bind("mousedown", function ( e )
	 {
		if(openFlag)
		{
			showPopupFlag = false;
			openFlag = false;
			$(".blind_con").unbind("mousedown");
			container.hide();
			return;
		}

		showPopupFlag = true;

		$(".blind_con").css({display:"block", opacity:0.3});

		$(window).resize( function (e)
		{
			if(!openFlag) return false;
			$(".datepicker").hide();
			$(".blind_con").unbind("mousedown");
			$(".blind_con").css({display:"none"});
		});

		if($(window).width() > 980)
		{
			container.css({left:($(window).width() - container.width())/2, top:($(window).height() - container.height())/2}).show();
			if($.browser.webkit)		
			{
				container.css({"-webkit-transform":"scale3d(0.7,0.7,1)", opacity:0});
				TweenMax.to(container, 0.8, {delay:0.2, "-webkit-transform":"scale3d(1,1,1)", ease:Elastic.easeOut, onStart:function (){ container.css({opacity:1}); }, onComplete:function (){ container.css({"-webkit-transform":""});}});
			}
			else if($.browser.mozilla)
			{
				TweenMax.to(container, 0, {scaleX:0.7, scaleY:0.7, opacity:0});
				TweenMax.to(container, 0.8, {delay:0.2, scaleX:1, scaleY:1, ease:Elastic.easeOut, onStart:function (){ container.css({opacity:1});}});
			}
			else 
			{
				var left = container.position().left;
				container.css({opacity:0, left:left-30});
				TweenMax.to(container, 0.6, {opacity:1, left:left, ease:Expo.easeOut});
			}
		}

		
		$(".blind_con").unbind("mousedown");
		$(".blind_con").bind("mousedown", function ( e )
		{
			$(".datepicker").hide();
			$(".blind_con").unbind("mousedown");
			$(".blind_con").css({display:"none"});
			openFlag = false;
			showPopupFlag = false;
			e.preventDefault();
			
		});
		openFlag = !openFlag;
		e.preventDefault();
		
	 });
}
