var timer;
var slider;
var scrollTop = 0;
var currentIdx = 0;

$(function ()
{
	slider = new Slider($(".visual_con .visual_set"), 
	{
		animationType:Slider.TRANSLATE_X, 
		cycle:true,
		swipe:false,
		changeFunc:sliderChange,
		speed:1

	});

	timer = setInterval( autoRolling, 5000 );

	$(window).resize(function ()
	{
		var ww = $(window).width();
		var hh = $(window).height();
		
		$(".visual_con").css({height:hh});
		$(".visual_set li").css({height:hh});
		
		$(".visual_set li").each(function ()
		{
			if(!checkDevice())
			{
				if(ww > hh && ww>1280)
				{
					var per = ww/1100;
					if(per<1)per = 1;
					$(this).find("img").css({position:"absolute", width:1280*per});
					$(this).find("img").css({left:-((1280*per)-ww)/2, top:-((800*per)-hh)/2});
				}
				else 
				{
					var per = hh/800;
					if(per<1)per = 1;
					$(this).find("img").css({position:"absolute", width:1280*per});
					$(this).find("img").css({left:-((1280*per)-ww)/2, top:-((800*per)-hh)/2})
				}
			}
			else
			{
				var per = ww/640;
				$(this).find("img").css({width:"100%", height:"auto"});
				$(this).css({height:874*per});
				$(".visual_con").css({height:874*per});
			}
		});		
		slider.resize();
	});
	$(window).resize();

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			slider.speed = 0.6;
			removeMouseWheel();
		}
		else
		{
			slider.speed = 2;
			addMouseWheel();
		}
	});

	$(".visual_set li img").bind("load", function ()
	{
		$(window).resize();
	});

	$(".visual_pager a").bind("click", function ( e )
	{
		slider.changePage( $(this).index() );
	});

			
	

	$(".banner_con li").each(function ()
	{
		$(this).find("a").bind("mouseenter", function ( e )
		{
			TweenMax.to($(this).find(".img_con"), 0.4, {opacity:1});
		});

		$(this).find("a").bind("mouseleave", function ( e )
		{
			TweenMax.to($(this).find(".img_con"), 0.4, {opacity:0.5});
		});
	});

	$(".pager_con").css({position:"relative", left:-$(".pager_con").width()/2});
	changePager(0);
	
	
});

function addMouseWheel()
{
	$("body").mousewheel(function (event, delta) {
		
		if (event.preventDefault) event.preventDefault();
		else event.returnValue = false;
		
		//if (!initFlag) return;
		scrollFn(-delta);
	});
	scrollFn(0);
}

function removeMouseWheel()
{
	$("body").unmousewheel();
}

function scrollFn(delta) 
{
	scrollTop = parseInt(scrollTop - (-delta * 100));
	var max = $("body").height() - $(window).height();
	if (scrollTop < 0) scrollTop = 0;
	if (scrollTop > max) scrollTop = max;
	TweenMax.to($("html,body"), 0.6, {scrollTop:scrollTop, ease:Cubic.easeOut});
	$(".visual_set li .title_con").each(function ( i )
	{
		var len = $(this).find(".title").length;
		$(this).find(".title").each(function ( j )
		{
			var top = scrollTop;
			if(currentIdx == i)
			{
				if(scrollTop<$(window).scrollTop())	TweenMax.to($(this), 0.6+(0.2*(j*j)), {top:top, ease:Cubic.easeOut});
				else 								TweenMax.to($(this), 0.6+(0.2*(len-(j*j))), {top:top, ease:Cubic.easeOuteaseOut});
			}
			else 
			{
				if(scrollTop<$(window).scrollTop())	TweenMax.to($(this), 0, {top:top, ease:Cubic.easeOut});
				else 								TweenMax.to($(this), 0, {top:top, ease:Cubic.easeOuteaseOut});
			}
		});			
	});
}


function autoRolling()
{
	 slider.changePage(slider.currentNum+1);
}

function sliderChange( idx )
{
	changePager(idx);
	if(!isMobile)changeTitle(idx);
	currentIdx = idx;
}

function changePager(idx)
{
	$(".pager_con a").removeClass("on");
	$(".pager_con a .on").css({"visibility":"hidden"});
	var on = $(".pager_con a .on").eq(idx);
	on.css({"visibility":"visible"});
	on.parent().addClass("on");
	//TweenMax.to(on, 0, {scaleX:0, scaleY:0});
	//TweenMax.to(on, 0.8, {scaleX:1, scaleY:1, ease:Expo.easeOut});
}

function changeTitle(idx)
{
	if(currentIdx > idx)
	{
		if(idx == 0) idx =$(".visual_set li").length-2;
	}
	$(".visual_set li").eq(idx).find(".title").each(function (i)
	{
		$(this).css({left:$(window).width()});
		TweenMax.to($(this), 1.2, {delay:0.1*i, left:0, ease:Cubic.easeOut});
	});
}
