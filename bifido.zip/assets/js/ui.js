var scrollTop = $(window).scrollTop();
var displayEvent = jQuery.Event( "changeDisplay" );
var isMobile = false;
var wheelFlag = false;

$(function ()
{
	displayEvent.mobile = isMobile;
	
	$(".header_con").on("mouseenter", function ( e )
	{
		var hh = $(this).find(".main_menu").height()+$(this).find(".all_menu_con").height();
		TweenMax.to($(this), 0.8, {height:hh, ease:Expo.easeOut});
		$(".header_blind").css({display:"block"});
		TweenMax.to($(".header_blind"), 0.4, {opacity:0.3});
	});

	$(".header_con").on("mouseleave", function ( e )
	{
		var hh = $(this).find(".main_menu").height();
		TweenMax.to($(this), 0.8, {height:hh, ease:Expo.easeInOut});
		TweenMax.to($(".header_blind"), 0.4, {opacity:0, onComplete:function ()
		{
			$(".header_blind").css({display:"none"});
		}});
	});

	$(".mobile_header .menu_btn").on("click", function ( e )
	{
		showGnb();
	});

	$(".mobile_gnb .close").on("click", function ( e )
	{
		hideGnb();
	});
	
	$(".mobile_header .lang_btn select").on("change", function ( e )
	{
		location.href = "/"+$(this).find("option:selected").val();
	});

	$(".mobile_gnb .main_li").each( function ( i )
	{
		$(this).bind("click", function ( e )
		{
			clickGnb(i);
		});
	});

	$("img.m_img").each( function ( i )
	{
		$(this).attr("path", $(this).attr("src"));
	});

	
	
	//�������� �̺�Ʈ
	$(window).resize( function ( e )
	{
		windowWidth = Math.min( $( window ).width(), $(window).innerWidth());

		if(windowWidth < 1000)
		{
			if(!isMobile)
			{
				
				isMobile = true;
				displayEvent.mobile = isMobile;
				$(window).trigger(displayEvent);
				displayImgae();
			}
		}
		else
		{
			if(isMobile)
			{
				isMobile = false;
				displayEvent.mobile = isMobile;
				$(window).trigger(displayEvent);
				displayImgae();
			}
		}

		
	});

	$(window).resize();

	setTimeout(function ()
	{ 
		$(window).trigger( displayEvent ); 
	}, 10);
	
	$(window).scroll(function ()
	{
		if(!wheelFlag) 
		{
			windowScroll();
			scrollTop = $(window).scrollTop();
		}
	});

	

});

function windowScroll()
{
	if(!isMobile)
	{
		var hh = 416-$(window).scrollTop();
		if(hh<0) hh = 0;
		$(".sub_header .bg_con").css({height:hh});
		$(".sub_header .bg_con img").css({top:-$(window).scrollTop()/4});
	}
	else
	{
		$(".sub_header .bg_con").css({height:""});
		$(".sub_header .bg_con img").css({top:0, width:""});
	}
}


function displayImgae()
{
	if(!isMobile)
	{
		$("img.m_img").each( function ( i )
		{
			$(this).attr("src", $(this).attr("path"));
		});
	}
	else
	{
		$("img.m_img").each( function ( i )
		{
			var pathAr = String($(this).attr("path")).split(".");
			var path = pathAr[0]+"_m."+pathAr[1];
			$(this).attr("src", path);
		});
		
	}
}

function clickGnb( idx )
{
	$(".mobile_gnb .main_li").each( function ( i )
	{
		if(idx == i)
		{
			if($(this).hasClass("on"))
			{
				$(this).find(".sub_con").css({display:"none"});
				TweenMax.to($(this).find(".arrow img"), 0.6, {rotation:0, ease:Expo.easeOut});
				$(this).removeClass("on");
			}
			else
			{
				$(this).find(".sub_con").css({display:"block"});
				TweenMax.to($(this).find(".arrow img"), 0.6, {rotation:180, ease:Expo.easeOut});
				$(this).addClass("on");
			}
		}
		else
		{
			$(this).find(".sub_con").css({display:"none"});
			TweenMax.to($(this).find(".arrow img"), 0.6, {rotation:0, ease:Expo.easeOut});
			$(this).removeClass("on");
		}
	});
}

function showGnb()
{
	clickGnb(-1);	
	$(".mobile_gnb").css({display:"block"});
	TweenMax.to($(".mobile_gnb"), 0, {x:-windowWidth});
	TweenMax.to($(".mobile_gnb"), 0.8, {x:0, ease:Expo.easeInOut});
	$(".blind_con").css({display:"block"});
	TweenMax.killTweensOf($(".blind_con"));
	TweenMax.to($(".blind_con"), 0.4, {alpha:0.6});
	$(".blind_con").bind("touchstart", function ( e )
	{
		hideGnb();
	});
}

function hideGnb()
{
	TweenMax.to($(".mobile_gnb"), 0, {x:0});
	TweenMax.to($(".mobile_gnb"), 0.8, {x:-windowWidth, ease:Expo.easeInOut, onComplete:function ()
	{
		$(".mobile_gnb").css({display:"none"});
	}});

	TweenMax.to($(".blind_con"), 0.8, {delay:0.3, alpha:0, onComplete:function ()
	{
		$(".blind_con").css({display:"none"});
	}});
	$(".blind_con").unbind("touchstart");
	
}

function mouseweelFn(event, delta)
{
	if (event.preventDefault) event.preventDefault();
	else event.returnValue = false;
	//if (!initFlag) return;
	scrollFn(-delta);
}

function scrollFn(delta) 
{
	scrollTop = parseInt(scrollTop - (-delta * 100));
	var max = $("body").height() - $(window).height();
	if (scrollTop < 0) scrollTop = 0;
	if (scrollTop > max) scrollTop = max;
	wheelFlag = true;

	TweenMax.to($("html,body"), 0.6, {scrollTop:scrollTop, ease:Cubic.easeOut, onUpdate:function ()
	{
		windowScroll();
	}, onComplete:function ()
	{
		wheelFlag = false;
	}});
};

