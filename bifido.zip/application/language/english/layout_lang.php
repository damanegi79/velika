﻿<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



/* header */
$lang['logo']='BIFIDO';

/* gnb */
$lang['gnb']= array(
		array('title'=>'ABOUT BIFIDO', 'link'=>'/en/about'),
		array('title'=>'BIFIDUS STORY', 'link'=>'/en/story'),
		array('title'=>'RAW MATERIAL', 'link'=>'/en/material'),
		array('title'=>'PRODUCT', 'link'=>'/en/product'),
		array('title'=>'CUSTOMER', 'link'=>'/en/customer')
);



/* menu_all */

/* ABOUT BIFIDO */
$lang['menu_all']= array();
$lang['menu_all'][0] = array(
		array(
				array('title'=>'COMPANY', 'link'=>'/en/about/company'),
				array('title'=>'Company Profile', 'link'=>'/en/about/company/profile'),
				array('title'=>'History', 'link'=>'/en/about/company/history'),
				array('title'=>'Partners', 'link'=>'/en/about/company/partners'),
				array('title'=>'Contact Us ', 'link'=>'/en/about/company/contact_us'),
				array('title'=>'VOD', 'link'=>'/en/about/company/vod')
		),
		array(
				array('title'=>'DOWNLOAD', 'link'=>'/en/about/download'),
				array('title'=>'Brochure', 'link'=>'/en/about/download/brochure'),
				array('title'=>'Paper', 'link'=>'/en/about/download/paper'),
				array('title'=>'Patents', 'link'=>'/en/about/download/patents'),
				array('title'=>'Certificate', 'link'=>'/en/about/download/certificate'),
				array('title'=>'Honor', 'link'=>'/en/about/download/honor')
		)
);


/* BIFIDUS STORY */
$lang['menu_all'][1] = array();
$lang['menu_all'][1][0] = array(
		array('title'=>'BIFIDUS STORY', 'link'=>'/en/story'),
		array('title'=>'Competitive Edge', 'link'=>'/en/story/competitive'),
		array('title'=>'Probiotics & Bifidus', 'link'=>'/en/story/probiotics'),
		array('title'=>'Core Strains', 'link'=>'/en/story/core_strains'),
		array('title'=>'Core Technology', 'link'=>'/en/story/core_technology'),
		array('title'=>'Character', 'link'=>'/en/story/character')
);

/* RAW MATERIAL */
$lang['menu_all'][2] = array(
		array(
				array('title'=>'PROBIOTICS', 'link'=>'/en/material/probiotics'),
				array('title'=>'Raw Material', 'link'=>'/en/material/probiotics/raw_material'),
				array('title'=>'Immunity', 'link'=>'/en/material/probiotics/immunity'),
				array('title'=>'Gut Health', 'link'=>'/en/material/probiotics/gut_health'),
				array('title'=>'Woman Health', 'link'=>'/en/material/probiotics/woman_health')
		),
		array(
				array('title'=>'FERMENTED GINSENG', 'link'=>'/en/material/fermented_ginseng'),
				array('title'=>'Ginseng Story', 'link'=>'/en/material/fermented_ginseng/ginseng_story'),
				array('title'=>'Active G5', 'link'=>'/en/material/fermented_ginseng/active_g5')
		)
);

/* PRODUCT */
$lang['menu_all'][3] = array(
		array(
				array('title'=>'PROBIOTICS', 'link'=>'/en/product'),
				array('title'=>'Health Functional Food', 'link'=>'/en/product/probiotics/health'),
				array('title'=>'Food', 'link'=>'/en/product/probiotics/food'),
				array('title'=>'Pet’s Feed', 'link'=>'/en/product/probiotics/pets_feed'),
				array('title'=>'Cosmetics', 'link'=>'/en/product/probiotics/cosmetics')
		),
		array(
				array('title'=>'FERMENTED GINSENG', 'link'=>'/en/product/fermented_ginseng'),
				array('title'=>'ZIGUNUK Brand', 'link'=>'/en/product/fermented_ginseng/zigunuk_brand'),
				array('title'=>'Partner’s Brand', 'link'=>'/en/product/fermented_ginseng/partners_brand')
		)
);


/* CUSTOMER */
$lang['menu_all'][4] = array();
$lang['menu_all'][4][0] = array(
		array('title'=>'CUSTOMER', 'link'=>'/en/customer'),
		array('title'=>'News', 'link'=>'/en/customer/news'),
		array('title'=>'Event', 'link'=>'/en/customer/event')
		//array('title'=>'Bifidus Webtoon','link'=>'/en/customer/webtoon')
		//array('title'=>'Shopping Mall', 'link'=>'http://www.zkmall.co.kr/')
);










