﻿<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



/* header */
$lang['logo']='BIFIDO';

/* gnb */
$lang['gnb']= array(
		array('title'=>'VỀ BIFIDO', 'link'=>'/vn/about'),
		array('title'=>'CÂU CHUYỆN CỦA BIFIDUS', 'link'=>'/vn/story'),
		array('title'=>'NGUYÊN LIỆU THÔ', 'link'=>'/vn/material'),
		array('title'=>'SẢN PHẨM', 'link'=>'/vn/product'),
		array('title'=>'KHÁCH HÀNG ', 'link'=>'/vn/customer')
);



/* menu_all */

/* ABOUT BIFIDO */
$lang['menu_all']= array();
$lang['menu_all'][0] = array(
		array(
				array('title'=>'GIỚI THIỆU CÔNG TY', 'link'=>'/vn/about/company'),
				array('title'=>'GIỚI THIỆU CÔNG TY', 'link'=>'/vn/about/company/profile'),
				array('title'=>'LỊCH SỬ', 'link'=>'/vn/about/company/history'),
				array('title'=>'ĐỐI TÁC', 'link'=>'/vn/about/company/partners'),
				array('title'=>'LIÊN HỆ VỚI CHÚNG TÔI', 'link'=>'/vn/about/company/contact_us'),
				array('title'=>'VOD', 'link'=>'/vn/about/company/vod')
		),
		array(
				array('title'=>'TẢI XUỐNG', 'link'=>'/vn/about/download'),
				array('title'=>'TỜ QUẢNG CÁO', 'link'=>'/vn/about/download/brochure'),
				array('title'=>'GIẤY CHỨNG NHẬN', 'link'=>'/vn/about/download/paper'),
				array('title'=>'BẰNG SÁNG CHẾ', 'link'=>'/vn/about/download/patents'),
				array('title'=>'GIẤY CHỨNG NHẬN', 'link'=>'/vn/about/download/certificate'),
				array('title'=>'DANH HIỆU', 'link'=>'/vn/about/download/honor')
		)
);


/* BIFIDUS STORY */
$lang['menu_all'][1] = array();
$lang['menu_all'][1][0] = array(
		array('title'=>'CÂU CHUYỆN CỦA BIFIDUS', 'link'=>'/vn/story'),
		array('title'=>'LỢI THẾ CẠNH TRANH', 'link'=>'/vn/story/competitive'),
		array('title'=>'Probiotics & Bifidus', 'link'=>'/vn/story/probiotics'),
		array('title'=>'CHỨNG NHẬN', 'link'=>'/vn/story/core_strains'),
		array('title'=>'CÔNG NGHỆ NHÂN', 'link'=>'/vn/story/core_technology'),
		array('title'=>'ĐẶC TÍNH', 'link'=>'/vn/story/character')
);

/* RAW MATERIAL */
$lang['menu_all'][2] = array(
		array(
				array('title'=>'PROBIOTICS', 'link'=>'/vn/material/probiotics'),
				array('title'=>'NGUYÊN LIỆU THÔ', 'link'=>'/vn/material/probiotics/raw_material'),
				array('title'=>'MIỄN DỊCH', 'link'=>'/vn/material/probiotics/immunity'),
				array('title'=>'SỨC KHỎE CỦA RUỘT', 'link'=>'/vn/material/probiotics/gut_health'),
				array('title'=>'SỨC KHỎE CỦA PHỤ NỮ', 'link'=>'/vn/material/probiotics/woman_health')
		),
		array(
				array('title'=>'NHÂN SÂM LÊN MEN', 'link'=>'/vn/material/fermented_ginseng'),
				array('title'=>'CÂU CHUYỆN CỦA NHÂN SÂM', 'link'=>'/vn/material/fermented_ginseng/ginseng_story'),
				array('title'=>'Active G5', 'link'=>'/vn/material/fermented_ginseng/active_g5')
		)
);

/* PRODUCT */
$lang['menu_all'][3] = array(
		array(
				array('title'=>'SẢN PHẨM PROBIOTICS', 'link'=>'/vn/product'),
				array('title'=>'HỰC PHẨM CÓ LỢI CHO SỨC KHỎE', 'link'=>'/vn/product/probiotics/health'),
				array('title'=>'THỰC PHẨM', 'link'=>'/vn/product/probiotics/food'),
				array('title'=>'THỨC ĂN CHO VẬT NUÔI', 'link'=>'/vn/product/probiotics/pets_feed'),
				array('title'=>'MỸ PHẨM', 'link'=>'/vn/product/probiotics/cosmetics')
		),
		array(
				array('title'=>'NHÂN SÂM LÊN MEN', 'link'=>'/vn/product/fermented_ginseng'),
				array('title'=>'NHÃN HIỆU ZIGUNUK', 'link'=>'/vn/product/fermented_ginseng/zigunuk_brand'),
				array('title'=>'NHÃN HIỆU CỦA ĐỐI TÁC', 'link'=>'/vn/product/fermented_ginseng/partners_brand')
		)
);


/* CUSTOMER */
$lang['menu_all'][4] = array();
$lang['menu_all'][4][0] = array(
		array('title'=>'KHÁCH HÀNG', 'link'=>'/vn/customer'),
		array('title'=>'TIN TỨC', 'link'=>'/vn/customer/news'),
		array('title'=>'SỰ KIỆN', 'link'=>'/vn/customer/event')
		//array('title'=>'Bifidus Webtoon','link'=>'/vn/customer/webtoon')
		//array('title'=>'Shopping Mall', 'link'=>'http://www.zkmall.co.kr/')
);










