<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



/* header */
$lang['logo']='BIFIDO';

/* gnb */
$lang['gnb']= array(
		array('title'=>'ABOUT BIFIDO', 'link'=>'/kr/about'),
		array('title'=>'BIFIDUS STORY', 'link'=>'/kr/story'),
		array('title'=>'RAW MATERIAL', 'link'=>'/kr/material'),
		array('title'=>'PRODUCT', 'link'=>'/kr/product'),
		array('title'=>'CUSTOMER', 'link'=>'/kr/customer')
);



/* menu_all */

/* ABOUT BIFIDO */
$lang['menu_all']= array();
$lang['menu_all'][0] = array(
		array(
				array('title'=>'회사', 'link'=>'/kr/about/company'),
				array('title'=>'회사 프로필', 'link'=>'/kr/about/company/profile'),
				array('title'=>'연혁', 'link'=>'/kr/about/company/history'),
				array('title'=>'파트너', 'link'=>'/kr/about/company/partners'),
				array('title'=>'Contact Us ', 'link'=>'/kr/about/company/contact_us'),
				array('title'=>'VOD', 'link'=>'/kr/about/company/vod')
		),
		array(
				array('title'=>'다운로드', 'link'=>'/kr/about/download'),
				array('title'=>'브로셔', 'link'=>'/kr/about/download/brochure'),
				array('title'=>'논문', 'link'=>'/kr/about/download/paper'),
				array('title'=>'특허', 'link'=>'/kr/about/download/patents'),
				array('title'=>'증명서', 'link'=>'/kr/about/download/certificate'),
				array('title'=>'수상', 'link'=>'/kr/about/download/honor')
		)
);


/* BIFIDUS STORY */
$lang['menu_all'][1] = array();
$lang['menu_all'][1][0] = array(
		array('title'=>'비피더스 스토리', 'link'=>'/kr/story'),
		array('title'=>'경쟁력', 'link'=>'/kr/story/competitive'),
		array('title'=>'프로바이오틱스 & 비피더스', 'link'=>'/kr/story/probiotics'),
		array('title'=>'핵심균주', 'link'=>'/kr/story/core_strains'),
		array('title'=>'핵심 기술', 'link'=>'/kr/story/core_technology'),
		array('title'=>'캐릭터', 'link'=>'/kr/story/character')
);

/* RAW MATERIAL */
$lang['menu_all'][2] = array(
		array(
				array('title'=>'프로바이오틱스', 'link'=>'/kr/material/probiotics'),
				array('title'=>'원료', 'link'=>'/kr/material/probiotics/raw_material'),
				array('title'=>'연구자료', 'link'=>'/kr/material/probiotics/immunity'),
				array('title'=>'장 건강', 'link'=>'/kr/material/probiotics/gut_health'),
				array('title'=>'여성 건강', 'link'=>'/kr/material/probiotics/woman_health')
		),
		array(
				array('title'=>'발효인삼', 'link'=>'/kr/material/fermented_ginseng'),
				array('title'=>'인삼이야기', 'link'=>'/kr/material/fermented_ginseng/ginseng_story'),
				array('title'=>'Active G5', 'link'=>'/kr/material/fermented_ginseng/active_g5')
		)
);

/* PRODUCT */
$lang['menu_all'][3] = array(
		array(
				array('title'=>'프로바이오틱스 제품', 'link'=>'/kr/product'),
				array('title'=>'건강기능식품', 'link'=>'/kr/product/probiotics/health'),
				array('title'=>'식품', 'link'=>'/kr/product/probiotics/food'),
				array('title'=>'애완동물의 보조사료', 'link'=>'/kr/product/probiotics/pets_feed'),
				array('title'=>'화장품', 'link'=>'/kr/product/probiotics/cosmetics')
		),
		array(
				array('title'=>'발효인삼', 'link'=>'/kr/product/fermented_ginseng'),
				array('title'=>'지근억 브랜드', 'link'=>'/kr/product/fermented_ginseng/zigunuk_brand'),
				array('title'=>'파트너 브랜드', 'link'=>'/kr/product/fermented_ginseng/partners_brand')
		)
);


/* CUSTOMER */
$lang['menu_all'][4] = array();
$lang['menu_all'][4][0] = array(
		array('title'=>'고객센터', 'link'=>'/kr/customer'),
		array('title'=>'뉴스', 'link'=>'/kr/customer/news'),
		array('title'=>'이벤트', 'link'=>'/kr/customer/event')
		//array('title'=>'Bifidus Webtoon','link'=>'/kr/customer/webtoon')
		//array('title'=>'Shopping Mall', 'link'=>'http://www.zkmall.co.kr/')
);










