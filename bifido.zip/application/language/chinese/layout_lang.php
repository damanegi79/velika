﻿<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



/* header */
$lang['logo']='BIFIDO';

/* gnb */
$lang['gnb']= array(
		array('title'=>'公司简介', 'link'=>'/ch/about'),
		array('title'=>'双歧杆菌的故事', 'link'=>'/ch/story'),
		array('title'=>'原料', 'link'=>'/ch/material'),
		array('title'=>'产品', 'link'=>'/ch/product'),
		array('title'=>'顾客', 'link'=>'/ch/customer')
);



/* menu_all */

/* ABOUT BIFIDO */
$lang['menu_all']= array();
$lang['menu_all'][0] = array(
		array(
				array('title'=>'公司', 'link'=>'/ch/about/company'),
				array('title'=>'公司概况', 'link'=>'/ch/about/company/profile'),
				array('title'=>'历史', 'link'=>'/ch/about/company/history'),
				array('title'=>'合作伙伴', 'link'=>'/ch/about/company/partners'),
				array('title'=>'联系我们', 'link'=>'/ch/about/company/contact_us'),
				array('title'=>'影像', 'link'=>'/ch/about/company/vod')
		),
		array(
				array('title'=>'下载', 'link'=>'/ch/about/download'),
				array('title'=>'宣传册', 'link'=>'/ch/about/download/brochure'),
				array('title'=>'论文', 'link'=>'/ch/about/download/paper'),
				array('title'=>'专利', 'link'=>'/ch/about/download/patents'),
				array('title'=>'认证书', 'link'=>'/ch/about/download/certificate'),
				array('title'=>'荣誉', 'link'=>'/ch/about/download/honor')
		)
);


/* BIFIDUS STORY */
$lang['menu_all'][1] = array();
$lang['menu_all'][1][0] = array(
		array('title'=>'双歧杆菌的故事', 'link'=>'/ch/story'),
		array('title'=>'竞争优势', 'link'=>'/ch/story/competitive'),
		array('title'=>'益生菌&双歧杆菌', 'link'=>'/ch/story/probiotics'),
		array('title'=>'核心菌株', 'link'=>'/ch/story/core_strains'),
		array('title'=>'核心技术', 'link'=>'/ch/story/core_technology'),
		array('title'=>'漫画人物', 'link'=>'/ch/story/character')
);

/* RAW MATERIAL */
$lang['menu_all'][2] = array(
		array(
				array('title'=>'益生菌', 'link'=>'/ch/material/probiotics'),
				array('title'=>'原料', 'link'=>'/ch/material/probiotics/raw_material'),
				array('title'=>'研究资料', 'link'=>'/ch/material/probiotics/immunity'),
				array('title'=>'肠道健康', 'link'=>'/ch/material/probiotics/gut_health'),
				array('title'=>'女性健康', 'link'=>'/ch/material/probiotics/woman_health')
		),
		array(
				array('title'=>'发酵人参', 'link'=>'/ch/material/fermented_ginseng'),
				array('title'=>'人参的故事', 'link'=>'/ch/material/fermented_ginseng/ginseng_story'),
				array('title'=>'Active G5', 'link'=>'/ch/material/fermented_ginseng/active_g5')
		)
);

/* PRODUCT */
$lang['menu_all'][3] = array(
		array(
				array('title'=>'益生菌产品', 'link'=>'/ch/product'),
				array('title'=>'保健食品', 'link'=>'/ch/product/probiotics/health'),
				array('title'=>'一般食品', 'link'=>'/ch/product/probiotics/food'),
				array('title'=>'宠物食品', 'link'=>'/ch/product/probiotics/pets_feed'),
				array('title'=>'化妆品', 'link'=>'/ch/product/probiotics/cosmetics')
		),
		array(
				array('title'=>'发酵人参', 'link'=>'/ch/product/fermented_ginseng'),
				array('title'=>'池根亿品牌产品', 'link'=>'/ch/product/fermented_ginseng/zigunuk_brand'),
				array('title'=>'合作伙伴品牌', 'link'=>'/ch/product/fermented_ginseng/partners_brand')
		)
);


/* CUSTOMER */
$lang['menu_all'][4] = array();
$lang['menu_all'][4][0] = array(
		array('title'=>'顾客', 'link'=>'/ch/customer'),
		array('title'=>'新闻', 'link'=>'/ch/customer/news'),
		array('title'=>'企业动态', 'link'=>'/ch/customer/event')
		//array('title'=>'Bifidus Webtoon','link'=>'/ch/customer/webtoon')
		//array('title'=>'Shopping Mall', 'link'=>'http://www.zkmall.co.kr/')
);










