<script type="text/javascript">
$(function ()
{
	$(".list_con input[type='checkbox']").bind("change", function ( e )
	{
		
		if($(this).is(".chk_all"))
		{
			if( $(this).is(":checked") )	$(".chk_item").prop('checked', true);
			else 							$(".chk_item").prop('checked', false);
		}
		else
		{
			if(! $(this).is(":checked") )	$(".chk_all").prop('checked', false);
		}
	});

	$("#delete_btn").bind("click", function ( e )
	{
		if($(".chk_item:checked").length == 0)
		{
			alert("삭제할 리스트를 선택하세요.");
		}
		else
		{
			if(confirm("선택한 리스트를 삭제 하시겠습니까?"))
			{
				$("#delete_form").submit();
			}
		}
	});
	$("#lang_slt").change(function (e)
	{
		location.href="/admin/customer/news?lang="+$(this).val();
	});
});

</script>

		<!-- page-wrapper -->
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           	NEWS 관리
                        </h1>
                    </div>
                </div>
                
                <div class="row" style="position:relative;">
                	<div class="col-lg-8" style="margin:10px 0">
                	 	<a href="javascript:" id="delete_btn" class="btn btn-sm btn-danger" style="float:left;"type="button">삭제</a>
	                	<select	id="lang_slt" class="form-control" style="width:200px;float:right">
		                    <option value="" <?Php if($lang == ""){ echo 'selected'; }?>>ALL</option>
		                    <option value="ko" <?Php if($lang == "ko"){ echo 'selected'; }?>>Korean</option>
		                    <option value="en" <?Php if($lang == "en"){ echo 'selected'; }?>>English</option>
		                    <option value="ch" <?Php if($lang == "ch"){ echo 'selected'; }?>>Chinese</option>
		                    <option value="vn" <?Php if($lang == "vn"){ echo 'selected'; }?>>Vietnamese</option>	
		                </select>
	                </div>
                </div>
                
                <form id="delete_form" action="/admin/delete_news" method="POST">
                <div class="row text-center" style="position:relative;">
                    <div class="col-lg-8">
                        <div class="list_con">
                            <table class="table table-bordered table-hover">
                            	<colgroup>
                            		<col width="5%">
                            		<col width="8%">
                            		<col width="">
                            		<col width="20%">
                            		<col width="10%">
                            	</colgroup>
                                <thead>
                                    <tr>
                                    	<th class="text-center"><input class="chk_all" type="checkbox"></th>
                                        <th class="text-center">No.</th>
                                        <th class="text-center">Title</th>
                                        <th class="text-center">Date</th>
                                        <th class="text-center">Languege</th>
                                    </tr>
                                </thead>
                                <tbody>
                                	<?php $i=1; ?>
                                	<?php foreach ($news_list as $list):?>
                                	
                                	<tr>
                                    	<td><input class="chk_item" type="checkbox" name="chk_list[]" value="<?= $list->idx ?>"></td>
                                        <td><?= $i+$page ?></td>
                                        <td style="text-align:left"><a href="/admin/customer/news_detail?<?='lang='.$lang.'&per_page='.$page.'&idx='.$list->idx; ?>"><?= $list->title ?></a></td>
                                        <td><?= $list->date ?></td>
                                        <td><?= $list->lang ?></td>
                                    </tr>
                                		
                                	<?php $i++; ?>
                                	<?php endforeach;?>
                                	
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                 <input type="hidden" name="prev" value="/admin/customer/news<?= '?lang='.$lang.'&per_page='.$page ?>">
                </form>
                
                <div class="row text-center" style="position:relative;">
                	<div class="col-lg-8" <?php if($pagination ==""){ echo'style="height:80px"';}?>>
	                    <nav>
	                    	<?= $pagination ?>
					   </nav>
					   <a href="/admin/customer/news_write" style="position:absolute;right:20px;top:20px;" type="button" class="btn btn-primary">작성하기</a>
				   </div>
                </div>
            </div>
           <!-- //Page Heading -->
        </div>
        <!-- //page-wrapper -->