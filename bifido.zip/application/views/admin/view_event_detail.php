<script type="text/javascript">


$(function ()
{
	$("#modify_btn").bind("click", function ( e )
	{
		if($("#s_date").val() == "")
		{
			alert("시작일을 입력하세요.");
			$("#s_date").focus();
			return;		
		}

		if($("#e_date").val() == "")
		{
			alert("종료일을 입력하세요.");
			$("#e_date").focus();
			return;		
		}
				
		if($("#title_txt").val() == "")
		{
			alert("제목을 입력하세요.");
			$("#title_txt").focus();
			return;		
		}

		if($("#location_txt").val() == "")
		{
			alert("장소를 입력하세요.");
			$("#location_txt").focus();
			return;		
		}
				
		if($("#sub_title_txt").val() == "")
		{
			alert("간략정보를 입력하세요.");
			$("#sub_title_txt").focus();
			return;		
		}

		if(CKEDITOR.instances.editor.getData() == "")
		 {
			alert("내용을 입력하세요.");
			return;		
		}

				
		if($("#upload_file").val())
		{
			$('#upload_form').append($("#upload_file"));
			$("#upload_con").html('<input class="form-control" id="upload_file" name="userfile" name="userfile" type="file">');
			$('#upload_form').ajaxForm({success: function(data)
			{
			     if(data)
			     {
				    $("#thumb_path").val(data);
				   	$("#editor").val(CKEDITOR.instances.editor.getData());
					$("#modify_form").submit();
			   	 }
			     else 
			     {
			    	 alert("파일 업로드 실패");
			     }
					     
			     $('#upload_form').empty();
			}});
			$('#upload_form').submit();
			
		}
		else 
		{
			$("#editor").val(CKEDITOR.instances.editor.getData());
			$("#modify_form").submit();
		}

				
	});	
});

</script>


		<!-- page-wrapper -->
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           	EVENT 관리
                        </h1>
                    </div>
                </div>
                
                <form id="modify_form" action="/admin/modify_event" method="POST">
                <div class="row text-center" style="position:relative;">
                    <div class="col-lg-10">
                        <div class="list_con">
                            <table class="table table-bordered table-hover">
                            	<colgroup>
                            		<col width="10%">
                            		<col width="">
                            	</colgroup>
                                <tbody>
                                	 <tr>
                                    	<th class="text-center" style="vertical-align:middle">언어</th>
                                        <td class="text-left">
                                        	<select	name="lang_slt" class="form-control" style="width:200px">
							                    <option value="ko" <?php if($event_list->lang == "ko"){ echo 'selected';} ?>>Korean</option>
							                    <option value="en" <?php if($event_list->lang == "en"){ echo 'selected';} ?>>English</option>
							                    <option value="ch" <?php if($event_list->lang == "ch"){ echo 'selected';} ?>>Chinese</option>
							                    <option value="vn" <?php if($event_list->lang == "vn"){ echo 'selected';} ?>>Vietnamese</option>	
							                </select>	
										</td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">국가</th>
                                        <td class="text-left">
							                <select	name="country_slt" class="form-control" style="width:200px">
							                    <option value="korea" <?php if($event_list->country == "korea"){ echo 'selected';} ?>>Korea</option>
							                    <option value="vietnam" <?php if($event_list->country == "vietnam"){ echo 'selected';} ?>>Vietnam</option>
							                    <option value="lituania" <?php if($event_list->country == "lituania"){ echo 'selected';} ?>>Lituania</option>
							                    <option value="taiwan" <?php if($event_list->country == "taiwan"){ echo 'selected';} ?>>Taiwan</option>
							                    <option value="china" <?php if($event_list->country == "china"){ echo 'selected';} ?>>China</option>
							                    <option value="singapore" <?php if($event_list->country == "singapore"){ echo 'selected';} ?>>Singapore</option>
							                    <option value="poland" <?php if($event_list->country == "poland"){ echo 'selected';} ?>>Poland</option>
							                    <option value="turkey" <?php if($event_list->country == "turkey"){ echo 'selected';} ?>>Turkey</option>
							                    <option value="hongkong" <?php if($event_list->country == "hongkong"){ echo 'selected';} ?>>HongKong</option>
							                    <option value="jordan" <?php if($event_list->country == "jordan"){ echo 'selected';} ?>>Jordan</option>
							                    <option value="germany" <?php if($event_list->country == "germany"){ echo 'selected';} ?>>Germany</option>
							                    <option value="swizerland" <?php if($event_list->country == "swizerland"){ echo 'selected';} ?>>Swizerland</option>
							                    <option value="usa" <?php if($event_list->country == "usa"){ echo 'selected';} ?>>USA</option>
							                    <option value="france" <?php if($event_list->country == "france"){ echo 'selected';} ?>>France</option>
							                    <option value="malaysia" <?php if($event_list->country == "malaysia"){ echo 'selected';} ?>>Malaysia</option>
							                    <option value="myanmar" <?php if($event_list->country == "myanmar"){ echo 'selected';} ?>>Myanmar</option>
							                    <option value="thailand" <?php if($event_list->country == "thailand"){ echo 'selected';} ?>>Thailand</option>
							                    <option value="etc" <?php if($event_list->country == "etc"){ echo 'selected';} ?>>기타</option>
							                </select>	
										</td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">시작 ~ 종료</th>
                                        <td class="text-left">
                                        	<div class="col-lg-3" style="padding-left:0">
                                        		<input class="form-control" id="s_date" name="s_date" type="date" placeholder="0000-00-00" value="<?= $event_list->s_date ?>">
                                        	</div>
                                        	<div class="col-lg-3">
                                        		<input class="form-control" id="e_date" name="e_date" type="date" placeholder="0000-00-00" value="<?= $event_list->e_date ?>">
                                        	</div>
                                        </td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">제목</th>
                                        <td class="text-left"><input class="form-control" id="title_txt" name="title_txt" type="text" placeholder="제목을 입력하세요." value="<?=$event_list->title?>"></td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">장소</th>
                                        <td class="text-left"><input class="form-control" id="location_txt" name="location_txt" type="text" placeholder="장소를 입력하세요."  value="<?=$event_list->location?>"></td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">간략정보</th>
                                        <td class="text-left">
                                        	<textarea class="form-control" id="sub_title_txt" name="sub_title_txt" placeholder="간략정보를 입력하세요."><?=$event_list->subTitle?></textarea>
                                        </td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">썸네일</th>
                                        <td class="text-left">
                                        	<div class="col-lg-1" style="padding-left:0">
                                        		<?php if(empty($list->thumb)):?>
												<img src="/assets/images/common/default_event.png" style="width:100px;height:46px;border:solid 1px #c6c6c6" />
												<?php else:?>
												<img src="<?= $list->thumb ?>" style="width:100px;height:46px;border:solid 1px #c6c6c6" />
												<?php endIf;?>
                                        	</div>
                                        	<div class="col-lg-3" id="upload_con">
                								<input class="form-control" id="upload_file" name="userfile" name="userfile" type="file">
                                        	</div>
                                        	<span><font color="#ff0000">썸네일 사이즈 203 * 93</font></span>
                                        </td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">내용</th>
                                        <td class="text-left">
                                        	<div class="editor_con">
                                        		<textarea name="editor" id="editor" rows="10" cols="80"></textarea>
									            <script>
									                CKEDITOR.replace( 'editor' , {filebrowserImageUploadUrl:'/admin/upload_edit', height:400});
									                <?Php
									                	$content = str_replace("\r", "", $event_list->content);
									                	$content = str_replace("\n", "", $content);
									                	echo "CKEDITOR.instances.editor.setData('".$content."');"
									               	?>
									            </script> 
									        </div>
									   </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="thumb_path" name="thumb_path" value="<?=$event_list->thumb ?>">
                <input type="hidden" name="idx" value="<?= $event_list->idx ?>">
                <input type="hidden" name="prev" value="/admin/customer/event_detail<?= '?lang='.$lang.'&per_page='.$page.'&idx='.$event_list->idx ?>">
                </form>
                
               	<form id="upload_form" action="/admin/upload_file/event" method="post" enctype="multipart/form-data" style="display:none"></form> 
                
               
                
                <div class="row text-center" style="position:relative;">
                	<div class="col-lg-10">
                		<button type="button" id="modify_btn" class="btn btn-warning" style="width:80px">수정하기</button>
                		
                		<form id="delete_form" action="/admin/delete_event" method="POST">
                			<input name="chk_list[]" type="hidden" value="<?= $event_list->idx ?>">
                			<input type="hidden" name="prev" value="/admin/customer/event<?= '?lang='.$lang.'&per_page='.$page ?>">
                			<button type="submit" id="delete_btn" class="ml10 btn btn-danger" style="width:80px">삭제하기</button>
                		</form>
                	    <a href="/admin/customer/event?<?= 'lang='.$lang.'&per_page='.$page ?>" type="button" class="ml10 btn btn-primary" style="width:80px">리스트</a>
					</div>
                </div>
            </div>
           <!-- //Page Heading -->
        </div>
        <!-- //page-wrapper -->