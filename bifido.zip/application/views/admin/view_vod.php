<script type="text/javascript">
$(function ()
{
	$(window).resize(function ()
	{
		if($(".thumb_con").length>0)
		{
			$(".regist_btn").css({"height":$(".thumb_con").height()+10});
			$(".regist_con .regist_btn a").css({position:"relative", top:($(".regist_btn").height()/2)-20});
		}
		else 
		{
			$(".regist_con .regist_btn").css({"padding":"150px 0"});
		}
	});
	$(window).resize();
			
	$(".regist_con .regist_btn a").bind("click", function ()
	{
		$(".regist_con .regist_btn").css({display:"none"});	
		$(".regist_con .regist_target").css({display:"block"});
		$(".regist_con .regist_ok").bind("click", function ()
		{
			if($("#youtube_path").val() == "")
			{
				alert("유투브 동영상 아이디를 입력하세요.");
				$("#youtube_path").focus();
				return;	
			}

			for(var j=0; j<$(".regist_con textarea").length; j++)
			{
				var textarea = $(".regist_con textarea").eq(j);
				if(textarea.val() == "")
				{
					alert("내용을 입력하세요.");
					textarea.focus();
					return;	
				}
			}
			
			if($("#upload_file").val())
			{
				$('#upload_form').ajaxForm({success: function(data)
				{
				     if(data)
				     {
				    	 uploadMain(data);
				   	 }
				     else 
				     {
				    	 alert("파일 업로드 실패");
				     }
				     $("#upload_file").val("");
				}});
				$('#upload_form').submit();
				
			}
			else 
			{
				alert("파일을 선택하세요.");
				$("#upload_file").focus();
				return;
			}
		});
		
		
	});

	$(".list_con").each(function ()
	{
		var list = $(this);
		$(this).find(".delete_btn").bind("click", function ()
		{
			if(confirm("삭제하시겠습니까?"))
			{
				list.find("#delete_form").submit();
			}
		});
		$(this).find(".modify_btn").bind("click", function ()
		{
			list.find(".modify_con").css({display:"block"});
			list.find(".list_btn").css({display:"none"});
		});
		$(this).find(".regist_cancel").bind("click", function ()
		{
			list.find(".modify_con").css({display:"none"});
			list.find(".list_btn").css({display:"block"});
		});
	});

	function uploadMain( data )
	{
		$("#img_path").val(data);
		$('#upload_main').submit();
	}
	
	$(".regist_con .regist_target .regist_cancel").bind("click", function ()
	{
		$(".regist_con .regist_btn").css({display:"block"});
		$(".regist_con .regist_target").css({display:"none"});
		$(".regist_con input").val("");
		$(".regist_con textarea").val("");
	});

	
	
});

</script>
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           VOD 관리
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
                
                		<?php $i=0; ?>
	                    <?php foreach($vod_list as $list): ?>
	                    <?php if( $i%4 == 0){ echo '<div class="row">';} ?>
	                
		                <div class="col-lg-3 text-center list_con">
	                        <div class="panel panel-default">
	                        	<div class="thumb_con">
		                            <div class="panel-body">
		                                <img class="img-thumbnail" src="<?= $list->imgPath?>" style="max-width:230px;width:100%;height:auto" >
		                            </div>
		                            <div class="panel-body list_btn">
			                           <a href="javascript:" class="btn  btn-warning modify_btn" style="width:80px">수정</a>
			                           
			                           <form id="delete_form" action="/admin/delete_vod" method="post">
			                           		<input name="list_id" type="hidden" value="<?= $list->id ?>">
			                           		<input name="img_path" type="hidden" value=".<?= $list->imgPath ?>">
			                           		<a href="javascript:" class="ml10 btn  btn-danger delete_btn" style="width:80px">삭제</a>
			                           </form>
			                        </div>
		                        </div>
		                        <div class="modify_con panel-body" style="display:none">
			                      <form id="modify_vod" action="/admin/modify_vod" method="post">
			                      	<div class="form-group">
		                                <label for="category" style="vertical-align:top;position:relative;top:6px;margin-right:5px">About probiotics</label>
		                                <input id="category" name="category" type="checkbox" style="width:25px;height:25px" <?Php if($list->category =="about"){ echo "checked"; } ?>>
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>유투브 동영상 아이디</label>
		                                <input id="youtube_path" name="youtube_path" class="form-control" type="text" value="<?= $list->youtubePath ?>">
		                            </div>
		                            <p class="mt10 help-block"><font color="#ff0000">타이틀 2줄 이하</font></p>
		                            <div class="form-group">
		                                <label>국문 타이틀</label>
		                                <textarea id="title_kr" name="title_kr" class="form-control"><?= $list->titleKr ?></textarea>
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>영문 타이틀</label>
		                                <textarea id="title_en" name="title_en" class="form-control"><?= $list->titleEn ?></textarea>
		                            </div>
		                            <div class="form-group">
		                                <label>중국어 타이틀</label>
		                                <textarea id="title_ch" name="title_ch" class="form-control"><?= $list->titleCh ?></textarea>
		                            </div>
		                            <div class="form-group">
		                                <label>베트남어 타이틀</label>
		                                <textarea id="title_vn" name="title_vn" class="form-control"><?= $list->titleVn ?></textarea>
		                            </div>
		                            
			                         <div class="panel-body">
		                             	<button  class="btn  btn-success regist_ok" style="width:80px">저장</button>
		                                <a href="javascript:" class="ml10 btn  btn-danger regist_cancel" style="width:80px">취소</a>
		                              </div>
		                              <input name="list_id" type="hidden" value="<?= $list->id ?>">
			                         </form>      
		                        </div>
	                        </div>
	                        
	                    </div>
	                    <?php if( $i%4 == 3){ echo '</div>';} ?>
	                    <?php $i++;?>
	                    <?php endforeach;?>
	                
                		<div class="col-lg-3 text-center">
                			<!--  regist_con  -->
	                        <div class="panel panel-default regist_con">
	                        	
	                            <div class="panel-body regist_btn">
	                                <a href="javascript:" class="btn  btn-default">동영상을 등록해 주세요.</a>
	                            </div>
	                             <div class="panel-body regist_target" style="display:none;">
	                             
	                             	<form id="upload_form" action="/admin/upload_file/vod" method="post" enctype="multipart/form-data">
		                                <div class="form-group" style="text-align: center">
			                                <h3>쎔네일 등록</h3>
			                                <input id="upload_file" name="userfile" type="file" style="margin:0 auto">
			                                <p class="mt10 help-block"><font color="#ff0000">이미지 사이즈 235*168</font></p>
			                            </div>
		                            </form>
		                            <form id="upload_main" action="/admin/upload_vod" method="post">
		                            
		                            <div class="form-group">
		                                <label for="category" style="vertical-align:top;position:relative;top:6px;margin-right:5px">About probiotics</label>
		                                <input id="category" name="category" type="checkbox" style="width:25px;height:25px">
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>유투브 동영상 아이디</label>
		                                <input id="youtube_path" name="youtube_path" class="form-control" type="text">
		                            </div>
		                            <p class="mt10 help-block"><font color="#ff0000">타이틀 2줄 이하</font></p>
		                            <div class="form-group">
		                                <label>국문 타이틀</label>
		                                <textarea id="title_kr" name="title_kr" class="form-control"></textarea>
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>영문 타이틀</label>
		                                <textarea id="title_en" name="title_en" class="form-control"></textarea>
		                            </div>
		                            <div class="form-group">
		                                <label>중국어 타이틀</label>
		                                <textarea id="title_ch" name="title_ch" class="form-control"></textarea>
		                            </div>
		                            <div class="form-group">
		                                <label>베트남어 타이틀</label>
		                                <textarea id="title_vn" name="title_vn" class="form-control"></textarea>
		                            </div>
		                            
		                            <input id="img_path" name="img_path" type="hidden">
		                            </form>
		                            
		                             <div class="panel-body">
		                             	<button  class="btn  btn-success regist_ok" style="width:80px">저장</button>
		                                <a href="javascript:" class="ml10 btn  btn-danger regist_cancel" style="width:80px">취소</a>
		                            </div>
		                           
	                            </div>
	                            
	                        </div>
	                        <!--  //regist_con  -->
	                    </div>
               
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->