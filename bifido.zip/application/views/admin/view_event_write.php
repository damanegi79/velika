<script type="text/javascript">


$(function ()
{
	$("#enter_btn").bind("click", function ( e )
	{
		if($("#s_date").val() == "")
		{
			alert("시작일을 입력하세요.");
			$("#s_date").focus();
			return;		
		}

		if($("#e_date").val() == "")
		{
			alert("종료일을 입력하세요.");
			$("#e_date").focus();
			return;		
		}
		
		if($("#title_txt").val() == "")
		{
			alert("제목을 입력하세요.");
			$("#title_txt").focus();
			return;		
		}

		if($("#location_txt").val() == "")
		{
			alert("장소를 입력하세요.");
			$("#location_txt").focus();
			return;		
		}
		
		if($("#sub_title_txt").val() == "")
		{
			alert("간략정보를 입력하세요.");
			$("#sub_title_txt").focus();
			return;		
		}

		if(CKEDITOR.instances.editor.getData() == "")
		 {
			alert("내용을 입력하세요.");
			return;		
		}

		
		if($("#upload_file").val())
		{
			$('#upload_form').append($("#upload_file"));
			$("#upload_con").html('<input class="form-control" id="upload_file" name="userfile" name="userfile" type="file">');
			$('#upload_form').ajaxForm({success: function(data)
			{
			     if(data)
			     {
				    $("#thumb_path").val(data);
				   	$("#editor").val(CKEDITOR.instances.editor.getData());
					$("#upload_event").submit();
			   	 }
			     else 
			     {
			    	 alert("파일 업로드 실패");
			     }
			     
			     $('#upload_form').empty();
			}});
			$('#upload_form').submit();
			
		}
		else 
		{
			$("#upload_event").submit();
			return;
		}

		/*
		
		
		*/
	});
});

</script>


		<!-- page-wrapper -->
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           	EVENT 관리
                        </h1>
                    </div>
                </div>
                
                <form id="upload_event" action="/admin/upload_event" method="POST">
                <div class="row text-center" style="position:relative;">
                    <div class="col-lg-10">
                        <div class="list_con">
                            <table class="table table-bordered table-hover">
                            	<colgroup>
                            		<col width="10%">
                            		<col width="">
                            	</colgroup>
                                <tbody>
                                	 <tr>
                                    	<th class="text-center" style="vertical-align:middle">언어</th>
                                        <td class="text-left">
                                        	<select	name="lang_slt" class="form-control" style="width:200px">
							                    <option value="ko" selected>Korean</option>
							                    <option value="en">English</option>
							                    <option value="ch">Chinese</option>
							                    <option value="vn">Vietnamese</option>	
							                </select>	
										</td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">국가</th>
                                        <td class="text-left">
                                        	<select	name="country_slt" class="form-control" style="width:200px">
							                    <option value="korea" selected>Korea</option>
							                    <option value="vietnam">Vietnam</option>
							                    <option value="lituania">Lituania</option>
							                    <option value="taiwan">Taiwan</option>
							                    <option value="china">China</option>
							                    <option value="singapore">Singapore</option>
							                    <option value="poland">Poland</option>
							                    <option value="turkey">Turkey</option>
							                    <option value="hongkong">HongKong</option>
							                    <option value="jordan">Jordan</option>
							                    <option value="germany">Germany</option>
							                    <option value="swizerland">Swizerland</option>
							                    <option value="usa">USA</option>
							                    <option value="france">France</option>
							                    <option value="malaysia">Malaysia</option>
							                    <option value="myanmar">Myanmar</option>
							                    <option value="thailand">Thailand</option>
							                    <option value="etc">기타</option>
							                </select>	
                                        </td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">시작 ~ 종료</th>
                                        <td class="text-left">
                                        	<div class="col-lg-3" style="padding-left:0">
                                        		<input class="form-control" id="s_date" name="s_date" type="date" placeholder="0000-00-00">
                                        	</div>
                                        	<div class="col-lg-3">
                                        		<input class="form-control" id="e_date" name="e_date" type="date" placeholder="0000-00-00">
                                        	</div>
                                        </td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">제목</th>
                                        <td class="text-left"><input class="form-control" id="title_txt" name="title_txt" type="text" placeholder="제목을 입력하세요."></td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">장소</th>
                                        <td class="text-left"><input class="form-control" id="location_txt" name="location_txt" type="text" placeholder="장소를 입력하세요."></td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">간략정보</th>
                                        <td class="text-left">
                                        	<textarea class="form-control" id="sub_title_txt" name="sub_title_txt" placeholder="간략정보를 입력하세요."></textarea>
                                        </td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">썸네일</th>
                                        <td class="text-left">
                                        	<div class="col-lg-3" id="upload_con" style="padding-left:0">
                								<input class="form-control" id="upload_file" name="userfile" name="userfile" type="file">
                                        	</div>
                                        	<span><font color="#ff0000">썸네일 사이즈 203 * 93</font></span>
                                        </td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">내용</th>
                                        <td class="text-left">
                                        	<div class="editor_con">
                                        		<textarea name="editor" id="editor" rows="10" cols="80"></textarea>
									            <script>
									                CKEDITOR.replace( 'editor' , {filebrowserImageUploadUrl:'/admin/upload_edit',height:400});
									            </script> 
									        </div>
									   </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <input type="hidden" id="thumb_path" name="thumb_path">
                </form>
                
                <form id="upload_form" action="/admin/upload_file/event" method="post" enctype="multipart/form-data" style="display:none"></form> 
                
                <div class="row text-center" style="position:relative;">
                	<div class="col-lg-10">
                		<button type="button" id="enter_btn" class="btn btn-primary" style="width:80px">작성완료</button>
                	   <a href="/admin/customer/event" type="button" class="ml10 btn btn-danger" style="width:80px">취소</a>
					</div>
                </div>
            </div>
           <!-- //Page Heading -->
        </div>
        <!-- //page-wrapper -->