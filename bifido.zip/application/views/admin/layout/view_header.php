<!DOCTYPE html>
<html lang="ko">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link rel="stylesheet" type="text/css" href="/assets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="/assets/css/admin.css" />
<link rel="stylesheet" type="text/css" href="/assets/font-awesome/css/font-awesome.min.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/bootstrap.js"></script>
<script type="text/javascript" src="/external/ckeditor/ckeditor.js"></script>
<style>
.al{text-align:left }
.ac{text-align:center }
.ar{text-align:right }
.vt{vertical-align:top }

.mt2{margin-top:2px }
.mt4{margin-top:4px }
.mt5{margin-top:5px }
.mt6{margin-top:6px }
.mt8{margin-top:8px }
.mt10{margin-top:10px }
.mt15{margin-top:15px }
.mt20{margin-top:20px }
.mt25{margin-top:25px }
.mt30{margin-top:30px }

.ml2{margin-left:2px }
.ml4{margin-left:4px }
.ml5{margin-left:5px }
.ml8{margin-left:8px }
.ml10{margin-left:10px }
.ml15{margin-left:15px }
.ml20{margin-left:20px }
.ml25{margin-left:25px }
.ml30{margin-left:30px }
form{display:inline}
</style>

<script type="text/javascript">

</script>
</head>
<body>
    <div id="wrapper">
        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="/admin">BIFIDO 관리자</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> Administrator <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                
                	<!-- 
                    <li <?Php if($this->uri->segment(2)=="main_visual"){ echo 'class="active"';}?>>
                        <a href="/admin/main_visual">메인 비주얼관리</a>
                    </li>
                     -->
                    <li <?Php if($this->uri->segment(2)=="vod"){ echo 'class="active"';}?>>
                        <a href="/admin/vod">VOD 관리</a>
                    </li>
                    <li <?Php if($this->uri->segment(2)=="download"){ echo 'class="active"';}?>>
                        <a href="javascript:;" data-toggle="collapse" data-target="#download" aria-expanded="true">다운로드 관리 <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="download" class="collapse <?Php if($this->uri->segment(2)=="download"){ echo 'in'; } else { echo 'out'; }?>" aria-expanded="falose">
                            <li <?Php if($this->uri->segment(3)=="brochure"){ echo 'class="active"';}?>>
                                <a href="/admin/download/brochure">Brochure</a>
                            </li>
                            <li <?Php if($this->uri->segment(3)=="paper"){ echo 'class="active"';}?>>
                                <a href="/admin/download/paper">Paper</a>
                            </li>
                            <li <?Php if($this->uri->segment(3)=="patents"){ echo 'class="active"';}?>>
                                <a href="/admin/download/patents">Patents</a>
                            </li>
                             <li <?Php if($this->uri->segment(3)=="certificate"){ echo 'class="active"';}?>>
                                <a href="/admin/download/certificate">Certificate</a>
                            </li <?Php if($this->uri->segment(3)=="honor"){ echo 'class="active"';}?>>
                            <li>
                                <a href="/admin/download/honor">Honor</a>
                            </li>
                        </ul>
                    </li>
                    <li <?Php if($this->uri->segment(2)=="board"){ echo 'class="active"';}?>>
                        <a href="javascript:;" data-toggle="collapse" data-target="#customer" aria-expanded="true">게시판 관리<i class="fa fa-fw fa-caret-down"></i></a>
                         <ul id="customer" class="collapse <?Php if($this->uri->segment(2)=="customer"){ echo 'in'; } else { echo 'out'; }?>" aria-expanded="falose">
                            <li <?Php if($this->uri->segment(3)=="news"){ echo 'class="active"';}?>>
                                <a href="/admin/customer/news">News</a>
                            </li>
                            <li <?Php if($this->uri->segment(3)=="event"){ echo 'class="active"';}?>>
                                <a href="/admin/customer/event">Event</a>
                            </li>
                        </ul>
                    </li>
                    
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>