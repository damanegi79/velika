<script type="text/javascript">
$(function ()
{
	$(window).resize(function ()
	{
		if($(".thumb_con").length>0)
		{
			$(".regist_btn").css({"height":$(".thumb_con").height()});
			$(".regist_con .regist_btn a").css({position:"relative", top:($(".regist_btn").height()/2)-20});
		}
		else 
		{
			$(".regist_con .regist_btn").css({"padding":"80px 0"});
		}
	});
	$(window).resize();
			
	$(".regist_con .regist_btn a").bind("click", function ()
	{
		$(".regist_con .regist_btn").css({display:"none"});	
		$(".regist_con .regist_target").css({display:"block"});

		$(".regist_con .regist_ok").bind("click", function ()
		{

			if($(".regist_con #cate_select"))
			{
				if($(".regist_con #cate_select").val()=="")
				{
					alert("카테고리를 선택해 주세요.");
					$(".regist_con #cate_select").focus()
					return;
				}
			}
			
			var chkCount = 0;
			$(".country_check input[type='checkbox']").each(function()
			{
				if($(this).is(":checked")) chkCount++;
			});

			if(chkCount == 0)
			{
				alert("노출국가를 1개 이상 선택하세요.");
				return;
			}
			
			var flag = false;
			$(".regist_con input[type='text']").each(function ( i )
			{
				if(!$(this).is(":disabled"))
				{
					if($(this).val() == "")
					{
						flag = true;
						alert("타이틀을 입력하세요.");
						$(this).focus();
						return false;
					}
				}
			});
			if(flag) return;
			
			if($("#upload_file").val())
			{
				
				$('#upload_form').ajaxForm({success: function(data)
				{
				     if(data)
				     {
				    	 uploadDownload(data);
				   	 }
				     else 
				     {
				    	 alert("파일 업로드 실패");
				     }
				     $("#upload_file").val("");
				}});
				$('#upload_form').submit();
				
			}
			else 
			{
				alert("파일을 선택하세요.");
				$("#upload_file").focus();
				return;
			}
		});
	});

	
	$(".country_check input[type='checkbox']").change(function ( e )
	{
		var idAr = $(this).attr("id").split("_");
		var idx = idAr[2];
		var country = idAr[1];
		
		if($(this).is(":checked"))
		{
			 $("#title_"+country+"_"+idx).attr("disabled", false);
		}
		else
		{
			 $("#title_"+country+"_"+idx).attr("disabled", true);
			 $("#title_"+country+"_"+idx).val("");
		}
		
	});

	
	$(".list_con").each(function ()
	{
		var list = $(this);
		$(this).find(".delete_btn").bind("click", function ()
		{
			if(confirm("삭제하시겠습니까?"))
			{
				list.find("#delete_form").submit();
			}
		});
		$(this).find(".modify_btn").bind("click", function ()
		{
			list.find(".modify_con").css({display:"block"});
			list.find(".list_btn").css({display:"none"});
		});
		$(this).find(".regist_cancel").bind("click", function ()
		{
			list.find(".modify_con").css({display:"none"});
			list.find(".list_btn").css({display:"block"});
		});
	});

	function uploadDownload( data )
	{
		$("#file_path").val(data);
		$('#upload_main').submit();
	}
	
	$(".regist_con .regist_target .regist_cancel").bind("click", function ()
	{
		$(".regist_con .regist_btn").css({display:"block"});
		$(".regist_con .regist_target").css({display:"none"});
		
		$(".regist_con .country_check input[type='checkbox']").attr("checked", false);
		if($(".regist_con #cate_select")) 
		{
			$(".regist_con #cate_select option").attr("selected", false);
			$(".regist_con #cate_select option").eq(0).attr("selected", true);
		}
		
		$(".regist_con #upload_file").val("");
		$(".regist_con input[type='text']").val("").attr("disabled", true);
	});

	
	
});

</script>
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           	다운로드 관리 
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
                
		                <?php $i=0;?>
	                    <?php foreach($pdf_list as $list): ?>
	                    <?php if( $i%4 == 0){ echo '<div class="row">';} ?>
	                    
	                    <?php
	                    	$nameAr = explode("/", $list->filePath);
	                    	$name = $nameAr[3];
	                    ?>
	                
		                <div class="col-lg-3 text-center list_con">
	                        <div class="panel panel-default">
	                        	<div class="thumb_con">
		                            <div class="panel-body">
		                                <img class="img-thumbnail" src="/assets/images/common/pdf_icon.png" >
		                                <p class="mt20"><?= $name ?></p>
		                            </div>
		                            <div class="panel-body list_btn">
			                           <a href="javascript:" class="btn  btn-warning modify_btn" style="width:80px">수정</a>
			                           
			                           <form id="delete_form" action="/admin/delete_pdf/<?= $category ?>" method="post">
			                           		<input name="list_id" type="hidden" value="<?= $list->id ?>">
			                           		<input name="file_path" type="hidden" value=".<?= $list->filePath ?>">
			                           		<a href="javascript:" class="ml10 btn  btn-danger delete_btn" style="width:80px">삭제</a>
			                           </form>
			                        </div>
		                        </div>
		                        <div class="modify_con panel-body" style="display:none">
			                      <form id="modify_vod" action="/admin/modify_pdf/<?=$category?>" method="post">
			                      <?php 
		                            	if($category == "brochure")
		                            	{
		                            		$s1 = "";
		                            		$s2 = "";
		                            		
		                            		if($list->category2 =="general_Infomation") $s1="selected";
		                            		else if($list->category2 =="products") $s2="selected";
		                            	
		                            		
				                            echo '<div class="form-group mt20">';
				                            echo '<label>카테고리</label>';
				                            echo '<select id="cate_select" name="cate_select" class="form-control">';
				                            echo '<option value="">카테고리를 선택해 주세요.</option>';
				                            echo '<option value="general_Infomation" '.$s1.'>General Infomation</option>';
				                            echo '<option value="products" '.$s2.'>Products</option>';
				                            echo '</select>';
				                            echo '</div>';
		                            	}
		                            ?>
			                      <div class="form-group country_check">
		                                 <label>노출 국가</label>
		                                <div>
			                                <input id="leng_kr_<?= $i+1 ?>" name="leng_kr" type="checkbox" style="width:20px;height:20px" <?php if($list->usedKr) echo 'checked'; ?>>
			                                <label for="leng_kr_<?= $i+1 ?>" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">Korean</label>
		                                </div>
		                                <div>
			                                <input id="leng_en_<?= $i+1 ?>" name="leng_en" type="checkbox" style="width:20px;height:20px" <?php if($list->usedEn) echo 'checked'; ?>>
			                                <label for="leng_en_<?= $i+1 ?>" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">English</label>
		                                </div>
		                                <div>
			                                <input id="leng_ch_<?= $i+1 ?>" name="leng_ch" type="checkbox" style="width:20px;height:20px" <?php if($list->usedCh) echo 'checked'; ?>>
			                                <label for="leng_ch_<?= $i+1 ?>" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">Chinese</label>
		                                </div>
		                                <div>
			                                <input id="leng_vn_<?= $i+1 ?>" name="leng_vn" type="checkbox" style="width:20px;height:20px" <?php if($list->usedVn) echo 'checked'; ?>>
			                                <label for="leng_vn_<?= $i+1 ?>" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">Vietnamese</label>
		                                </div>
		                            </div>
		                            <div class="form-group country_title">
		                                <label>국문 타이틀</label>
		                                <input id="title_kr_<?= $i+1 ?>" name="title_kr" class="form-control" type="text" <?php if(!$list->usedKr) echo 'disabled'; ?> value="<?= $list->titleKr ?>">
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>영문 타이틀</label>
		                                <input id="title_en_<?= $i+1 ?>" name="title_en" class="form-control" type="text" <?php if(!$list->usedEn) echo 'disabled'; ?> value="<?= $list->titleEn ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>중국어 타이틀</label>
		                                <input id="title_ch_<?= $i+1 ?>" name="title_ch" class="form-control" type="text" <?php if(!$list->usedCh) echo 'disabled'; ?> value="<?= $list->titleCh ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>베트남어 타이틀</label>
		                                <input id="title_vn_<?= $i+1 ?>" name="title_vn" class="form-control" type="text" <?php if(!$list->usedVn) echo 'disabled'; ?> value="<?= $list->titleVn ?>">
		                            </div>
		                            
			                         <div class="panel-body">
		                             	<button  class="btn  btn-success regist_ok" style="width:80px">저장</button>
		                                <a href="javascript:" class="ml10 btn  btn-danger regist_cancel" style="width:80px">취소</a>
		                              </div>
		                               
		                              <input name="list_id" type="hidden" value="<?= $list->id ?>">
			                         </form>      
		                        </div>
	                        </div>
	                        
	                    </div>
	                    <?php if( $i%4 == 3){ echo '</div>';} ?>
	                    <?php $i++;?>
	                    <?php endforeach;?>
                
                		
                		<div class="col-lg-3 text-center">
                			<!--  regist_con  -->
	                        <div class="panel panel-default regist_con">
	                        	
	                            <div class="panel-body regist_btn">
	                                <a href="javascript:" class="btn  btn-default">PDF 파일을 등록해 주세요.</a>
	                            </div>
	                             <div class="panel-body regist_target" style="display:none;">
	                             
	                             	<form id="upload_form" action="/admin/upload_file/pdf" method="post" enctype="multipart/form-data">
		                                <div class="form-group" style="text-align: center">
			                                <h3>PDF파일 등록</h3>
			                                <input id="upload_file" name="userfile" type="file" style="margin:0 auto">
			                            </div>
		                            </form>
		                            <form id="upload_main" action="/admin/upload_pdf/<?= $category ?>" method="post">
		                            <?php 
		                            	if($category == "brochure")
		                            	{
				                            echo '<div class="form-group mt20">';
				                            echo '<label>카테고리</label>';
				                            echo '<select id="cate_select" name="cate_select" class="form-control">';
				                            echo '<option value="" selected>카테고리를 선택해 주세요.</option>';
				                            echo '<option value="general_Infomation">General Infomation</option>';
				                            echo '<option value="products">Products</option>';
				                            echo '</select>';
				                            echo '</div>';
		                            	}
		                            ?>
		                            <div class="form-group country_check">
		                                 <label>노출 국가</label>
		                                <div>
			                                <input id="leng_kr_0" name="leng_kr" type="checkbox" style="width:20px;height:20px">
			                                <label for="leng_kr_0" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">Korean</label>
		                                </div>
		                                <div>
			                                <input id="leng_en_0" name="leng_en" type="checkbox" style="width:20px;height:20px">
			                                <label for="leng_en_0" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">English</label>
		                                </div>
		                                <div>
			                                <input id="leng_ch_0" name="leng_ch" type="checkbox" style="width:20px;height:20px">
			                                <label for="leng_ch_0" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">Chinese</label>
		                                </div>
		                                <div>
			                                <input id="leng_vn_0" name="leng_vn" type="checkbox" style="width:20px;height:20px">
			                                <label for="leng_vn_0" style="width:100px;vertical-align:top;margin-top:5px;text-align:left">Vietnamese</label>
		                                </div>
		                            </div>
		                            <div class="form-group">
		                                <label>국문 타이틀</label>
		                                <input id="title_kr_0" name="title_kr" class="form-control" type="text" disabled>
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>영문 타이틀</label>
		                                <input id="title_en_0" name="title_en" class="form-control" type="text" disabled>
		                            </div>
		                            <div class="form-group">
		                                <label>중국어 타이틀</label>
		                                <input id="title_ch_0" name="title_ch" class="form-control" type="text" disabled>
		                            </div>
		                            <div class="form-group">
		                                <label>베트남어 타이틀</label>
		                                <input id="title_vn_0" name="title_vn" class="form-control" type="text" disabled>
		                            </div>
		                            
		                            <input id="file_path" name="file_path" type="hidden">
		                            </form>
		                            
		                             <div class="panel-body">
		                             	<button  class="btn  btn-success regist_ok" style="width:80px">저장</button>
		                                <a href="javascript:" class="ml10 btn  btn-danger regist_cancel" style="width:80px">취소</a>
		                            </div>
		                           
	                            </div>
	                            
	                        </div>
	                        <!--  //regist_con  -->
	                    </div>
               
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->