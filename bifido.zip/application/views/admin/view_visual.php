<script type="text/javascript">
$(function ()
{
	$(window).resize(function ()
	{
		if($(".thumb_con").length>0)
		{
			$(".regist_btn").css({"height":$(".thumb_con").height()+10});
			$(".regist_con .regist_btn a").css({position:"relative", top:($(".regist_btn").height()/2)-20});
		}
		else 
		{
			$(".regist_con .regist_btn").css({"padding":"150px 0"});
		}
	});
	$(window).resize();
			
	$(".regist_con .regist_btn a").bind("click", function ()
	{
		$(".regist_con .regist_btn").css({display:"none"});	
		$(".regist_con .regist_target").css({display:"block"});
		$(".regist_con .regist_ok").bind("click", function ()
		{
			if($(".regist_con #main_title_kr").val()=="")
			{
				alert("국문 메인 타이틀을 입력하세요.");
				$(".regist_con #main_title_kr").focus();
				return;
			}
			
			if($(".regist_con #sub_title_kr").val()=="")
			{
				alert("국문 서브 타이틀을 입력하세요.");
				$(".regist_con #sub_title_kr").focus();
				return;
			}

			if($(".regist_con #info_text_kr").val()=="")
			{
				alert("국문 내용을 입력하세요.");
				$(".regist_con #info_text_kr").focus();
				return;
			}

			if($(".regist_con #main_title_en").val()=="")
			{
				alert("영문 메인 타이틀을 입력하세요.");
				$(".regist_con #main_title_en").focus();
				return;
			}
			
			if($(".regist_con #sub_title_en").val()=="")
			{
				alert("영문 서브 타이틀을 입력하세요.");
				$(".regist_con #sub_title_en").focus();
				return;
			}

			if($(".regist_con #info_text_en").val()=="")
			{
				alert("영문 내용을 입력하세요.");
				$(".regist_con #info_text_en").focus();
				return;
			}

			if($(".regist_con #main_title_ch").val()=="")
			{
				alert("중국어 메인 타이틀을 입력하세요.");
				$(".regist_con #main_title_ch").focus();
				return;
			}
			
			if($(".regist_con #sub_title_ch").val()=="")
			{
				alert("중국어 서브 타이틀을 입력하세요.");
				$(".regist_con #sub_title_ch").focus();
				return;
			}

			if($(".regist_con #info_text_ch").val()=="")
			{
				alert("중국어 내용을 입력하세요.");
				$(".regist_con #sub_title_ch").focus();
				return;
			}

			if($(".regist_con #main_title_vn").val()=="")
			{
				alert("베트남어 메인 타이틀을 입력하세요.");
				$(".regist_con #main_title_vn").focus();
				return;
			}
			
			if($(".regist_con #sub_title_vn").val()=="")
			{
				alert("베트남어 서브 타이틀을 입력하세요.");
				$(".regist_con #sub_title_vn").focus();
				return;
			}

			if($(".regist_con #info_text_vn").val()=="")
			{
				alert("베트남어 내용을 입력하세요.");
				$(".regist_con #info_text_vn").focus();
				return;
			}
			
			if($("#upload_file").val())
			{
				$('#upload_form').ajaxForm({success: function(data)
				{
				     if(data)
				     {
				    	 uploadMain(data);
				   	 }
				     else 
				     {
				    	 alert("파일 업로드 실패");
				     }
				     $("#upload_file").val("");
				}});
				$('#upload_form').submit();
				
			}
			else 
			{
				alert("파일을 선택하세요.");
				$("#upload_file").focus();
				return;
			}
		});
		
		
	});

	$(".list_con").each(function ()
	{
		var list = $(this);
		$(this).find(".delete_btn").bind("click", function ()
		{
			if(confirm("삭제하시겠습니까?"))
			{
				list.find("#delete_form").submit();
			}
		});
		$(this).find(".modify_btn").bind("click", function ()
		{
			list.find(".modify_con").css({display:"block"});
			list.find(".list_btn").css({display:"none"});
		});
		$(this).find(".regist_cancel").bind("click", function ()
		{
			list.find(".modify_con").css({display:"none"});
			list.find(".list_btn").css({display:"block"});
		});
	});

	function uploadMain( data )
	{
		$("#img_path").val(data);
		$('#upload_main').submit();
	}
	
	$(".regist_con .regist_target .regist_cancel").bind("click", function ()
	{
		$(".regist_con .regist_btn").css({display:"block"});
		$(".regist_con .regist_target").css({display:"none"});
		$(".regist_con input").val("");
		$(".regist_con textarea").val("");
	});

	
	
});

</script>
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                                                             메인 비주얼 관리	
                        </h1>
                    </div>
                </div>
                <!-- /.row -->
                
               		<?php $i=0; ?>
	                <?php foreach($main_list as $list): ?>
	                <?php if( $i%4 == 0){ echo '<div class="row">';} ?>
	                
		                <div class="col-lg-3 text-center list_con">
	                        <div class="panel panel-default">
	                        	<div class="thumb_con">
		                            <div class="panel-body">
		                                <img class="img-thumbnail" src="<?= $list->imgPath?>"  style="max-width:230px;width:100%;height:auto" >
		                            </div>
		                            <div class="panel-body list_btn">
			                           <a href="javascript:" class="btn  btn-warning modify_btn" style="width:80px">수정</a>
			                           
			                           <form id="delete_form" action="/admin/delete_main" method="post">
			                           		<input name="list_id" type="hidden" value="<?= $list->id ?>">
			                           		<input name="img_path" type="hidden" value=".<?= $list->imgPath ?>">
			                           		<a href="javascript:" class="ml10 btn  btn-danger delete_btn" style="width:80px">삭제</a>
			                           </form>
			                        </div>
		                        </div>
		                        <div class="modify_con panel-body" style="display:none">
			                      <form id="modify_main" action="/admin/modify_main" method="post">
			                      	<div class="page-header">
		                            	<h3>국문 내용</h3>
		                            </div>
		                            <div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_kr" name="main_title_kr" class="form-control" type="text" value="<?= $list->mainTitleKr ?>">
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_kr" name="sub_title_kr" class="form-control" type="text" value="<?= $list->subTitleKr ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_kr" name="info_text_kr" class="form-control"><?= $list->infoTextKr ?></textarea>
		                            </div>
		                           
		                            
		                            <div class="page-header">
		                            	<h3>영문 내용</h3>
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_en" name="main_title_en" class="form-control" type="text" value="<?= $list->mainTitleEn ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_en" name="sub_title_en" class="form-control" type="text" value="<?= $list->subTitleEn ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_en" name="info_text_en" class="form-control"><?= $list->infoTextEn ?></textarea>
		                            </div>
		                            
		                            
		                             
		                             <div class="page-header">
		                            	 <h3>중국어 내용</h3>
		                            </div>
		                           
		                            <div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_ch" name="main_title_ch" class="form-control" type="text" value="<?= $list->mainTitleCh ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_ch" name="sub_title_ch" class="form-control" type="text" value="<?= $list->subTitleCh ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_ch" name="info_text_ch" class="form-control"><?= $list->infoTextCh ?></textarea>
		                            </div>
		                            
		                             
		                            <div class="page-header">
		                            	 <h3>베트남어 내용</h3>
		                            </div>
		                             
		                          	<div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_vn" name="main_title_vn" class="form-control" type="text" value="<?= $list->mainTitleVn ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_vn" name="sub_title_vn" class="form-control" type="text" value="<?= $list->subTitleVn ?>">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_vn" name="info_text_vn" class="form-control"><?= $list->infoTextVn ?></textarea>
		                            </div>
		                            
			                         <div class="panel-body">
		                             	<button  class="btn  btn-success regist_ok" style="width:80px">저장</button>
		                                <a href="javascript:" class="ml10 btn  btn-danger regist_cancel" style="width:80px">취소</a>
		                              </div>
		                              <input name="list_id" type="hidden" value="<?= $list->id ?>">
			                         </form>      
		                        </div>
	                        </div>
	                        
	                    </div>
	                      <?php if( $i%4 == 3){ echo '</div>';} ?>
	                    <?php $i++;?>
	                <?php endforeach;?>
               
                		<div class="col-lg-3 text-center">
                			<!--  regist_con  -->
	                        <div class="panel panel-default regist_con">
	                        	
	                            <div class="panel-body regist_btn">
	                                <a href="javascript:" class="btn  btn-default">이미지를 등록해 주세요.</a>
	                            </div>
	                             <div class="panel-body regist_target" style="display:none;">
	                             
	                             	<form id="upload_form" action="/admin/upload_file/main" method="post" enctype="multipart/form-data">
		                                <div class="form-group" style="text-align: center">
			                                <h3>이미지 등록</h3>
			                                <input id="upload_file" name="userfile" type="file" style="margin:0 auto">
			                                <p class="mt10 help-block"><font color="#ff0000">이미지 사이즈 1280*1000</font></p>
			                            </div>
		                            </form>
		                            <form id="upload_main" action="/admin/upload_main" method="post">
		                         	<div class="page-header">
		                            	<h3>국문 내용</h3>
		                            </div>
		                            <div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_kr" name="main_title_kr" class="form-control" type="text">
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_kr" name="sub_title_kr" class="form-control" type="text">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_kr" name="info_text_kr" class="form-control"></textarea>
		                            </div>
		                            
		                            <div class="page-header">
		                            	<h3>영문 내용</h3>
		                            </div>
		                            
		                            <div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_en" name="main_title_en" class="form-control" type="text">
		                            </div>
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_en" name="sub_title_en" class="form-control" type="text">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_en" name="info_text_en" class="form-control"></textarea>
		                            </div>
		                            
		                            
		                            
		                             <div class="page-header">
		                            	 <h3>중국어 내용</h3>
		                            </div>
		                           
		                            <div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_ch" name="main_title_ch" class="form-control" type="text">
		                            </div>
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_ch" name="sub_title_ch" class="form-control" type="text">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_ch" name="info_text_ch"  class="form-control"></textarea>
		                            </div>
		                            
		                             
		                            <div class="page-header">
		                            	 <h3>베트남어 내용</h3>
		                            </div>
		                             
		                            <div class="form-group">
		                                <label>메인 타이틀</label>
		                                <input id="main_title_vn" name="main_title_vn" class="form-control" type="text">
		                            </div>
		                            <div class="form-group">
		                                <label>서브타이틀</label>
		                                <input id="sub_title_vn" name="sub_title_vn" class="form-control" type="text">
		                            </div>
		                            <div class="form-group">
		                                <label>정보글</label>
		                                <textarea id="info_text_vn" name="info_text_vn" class="form-control"></textarea>
		                            </div>
		                            <input id="img_path" name="img_path" type="hidden">
		                            <input id="count" name="count" type="hidden" value="<?=count($main_list)+1;?>">
		                            </form>
		                            
		                             <div class="panel-body">
		                             	<button  class="btn  btn-success regist_ok" style="width:80px">저장</button>
		                                <a href="javascript:" class="ml10 btn  btn-danger regist_cancel" style="width:80px">취소</a>
		                            </div>
		                           
	                            </div>
	                            
	                        </div>
	                        <!--  //regist_con  -->
	                    </div>
               
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->