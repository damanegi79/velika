<script type="text/javascript">


$(function ()
{
	$("#enter_btn").bind("click", function ( e )
	{
		if($("#title_txt").val() == "")
		{
			alert("제목을 입력하세요.");
			$("#title_txt").focus();
			return;		
		}
		if(CKEDITOR.instances.editor.getData() == "")
		{
			alert("내용을 입력하세요.");
			return;		
		}
		$("#editor").val(CKEDITOR.instances.editor.getData());
		$("#upload_form").submit();
		
	});
});

</script>


		<!-- page-wrapper -->
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           	NEWS 관리
                        </h1>
                    </div>
                </div>
                
                <form id="upload_form" action="/admin/upload_news" method="POST">
                <div class="row text-center" style="position:relative;">
                    <div class="col-lg-10">
                        <div class="list_con">
                            <table class="table table-bordered table-hover">
                            	<colgroup>
                            		<col width="10%">
                            		<col width="">
                            	</colgroup>
                                <tbody>
                                	 <tr>
                                    	<th class="text-center" style="vertical-align:middle">언어</th>
                                        <td class="text-left">
                                        	<select	name="lang_slt" class="form-control" style="width:200px">
							                    <option value="ko" selected>Korean</option>
							                    <option value="en">English</option>
							                    <option value="ch">Chinese</option>
							                    <option value="vn">Vietnamese</option>	
							                </select>	
										</td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">제목</th>
                                        <td class="text-left"><input class="form-control" id="title_txt" name="title_txt" type="text" placeholder="제목을 입력하세요."></td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">내용</th>
                                        <td class="text-left">
                                        	<div class="editor_con">
                                        		<textarea name="editor" id="editor" rows="10" cols="80"></textarea>
									            <script>
									                CKEDITOR.replace( 'editor' , {filebrowserImageUploadUrl:'/admin/upload_edit',height:400});
									            </script> 
									        </div>
									   </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                </form>
                
                <div class="row text-center" style="position:relative;">
                	<div class="col-lg-10">
                		<button type="button" id="enter_btn" class="btn btn-primary" style="width:80px">작성완료</button>
                	   <a href="/admin/customer/news" type="button" class="ml10 btn btn-danger" style="width:80px">취소</a>
					</div>
                </div>
            </div>
           <!-- //Page Heading -->
        </div>
        <!-- //page-wrapper -->