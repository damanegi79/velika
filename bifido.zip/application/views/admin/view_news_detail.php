<script type="text/javascript">


$(function ()
{
	$("#modify_btn").bind("click", function ( e )
	{
		if($("#title_txt").val() == "")
		{
			alert("제목을 입력하세요.");
			$("#title_txt").focus();
			return;		
		}
		if(CKEDITOR.instances.editor.getData() == "")
		{
			alert("내용을 입력하세요.");
			$("#title_txt").focus();
			return;		
		}
		$("#editor").val(CKEDITOR.instances.editor.getData());
		$("#modify_form").submit();
		
	});

	$("#delete_btn").bind("click", function ( e )
	{
		if(confirm("게시물을 삭제 하시겠습니까?"))
		{
			$("#delete_form").submit();
		}
	});
	
});

</script>


		<!-- page-wrapper -->
		<div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                           	NEWS 관리
                        </h1>
                    </div>
                </div>
                
                <form id="modify_form" action="/admin/modify_news" method="POST">
                <div class="row text-center" style="position:relative;">
                    <div class="col-lg-10">
                        <div class="list_con">
                            <table class="table table-bordered table-hover">
                            	<colgroup>
                            		<col width="10%">
                            		<col width="">
                            	</colgroup>
                                <tbody>
                                	 <tr>
                                    	<th class="text-center" style="vertical-align:middle">언어</th>
                                        <td class="text-left">
                                        	<select	name="lang_slt" class="form-control" style="width:200px">
							                    <option value="ko" <?php if($news_list->lang == "ko"){ echo 'selected';} ?>>Korean</option>
							                    <option value="en" <?php if($news_list->lang == "en"){ echo 'selected';} ?>>English</option>
							                    <option value="ch" <?php if($news_list->lang == "ch"){ echo 'selected';} ?>>Chinese</option>
							                    <option value="vn" <?php if($news_list->lang == "vn"){ echo 'selected';} ?>>Vietnamese</option>	
							                </select>	
										</td>
                                    </tr>
                                    <tr>
                                    	<th class="text-center" style="vertical-align:middle">제목</th>
                                        <td class="text-left"><input class="form-control" id="title_txt" name="title_txt" type="text" placeholder="제목을 입력하세요." value="<?=$news_list->title?>"></td>
                                    </tr>
                                     <tr>
                                    	<th class="text-center" style="vertical-align:middle">내용</th>
                                        <td class="text-left">
                                        	<div class="editor_con">
                                        		<textarea name="editor" id="editor" rows="10" cols="80"></textarea>
									            <script>
									                CKEDITOR.replace( 'editor' , {filebrowserImageUploadUrl:'/admin/upload_edit', height:400});
									                <?Php
									                	$content = str_replace("\r", "", $news_list->content);
									                	$content = str_replace("\n", "", $content);
									                	echo "CKEDITOR.instances.editor.setData('".$content."');"
									               	?>
									            </script> 
									        </div>
									   </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <input type="hidden" name="idx" value="<?= $news_list->idx ?>">
                <input type="hidden" name="prev" value="/admin/customer/news_detail<?= '?lang='.$lang.'&per_page='.$page.'&idx='.$news_list->idx ?>">
                </form>
                
               
                
                <div class="row text-center" style="position:relative;">
                	<div class="col-lg-10">
                		<button type="button" id="modify_btn" class="btn btn-warning" style="width:80px">수정하기</button>
                		
                		<form id="delete_form" action="/admin/delete_news" method="POST">
                			<input name="chk_list[]" type="hidden" value="<?= $news_list->idx ?>">
                			 <input type="hidden" name="prev" value="/admin/customer/news<?= '?lang='.$lang.'&per_page='.$page ?>">
                			<button type="button" id="delete_btn" class="ml10 btn btn-danger" style="width:80px">삭제하기</button>
                		</form>
                	    <a href="/admin/customer/news?<?= 'lang='.$lang.'&per_page='.$page ?>" type="button" class="ml10 btn btn-primary" style="width:80px">리스트</a>
					</div>
                </div>
            </div>
           <!-- //Page Heading -->
        </div>
        <!-- //page-wrapper -->