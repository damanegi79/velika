<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="ch">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>瘦身纤体酸奶粉</h2>
		<div class="info_con">
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left"'; ?>>
					<h4 class="title">产品成分</h4>
					<p class="tit">益生菌</p>
										
					<div class="list_con">
						<ul>
							<li>乳双歧杆菌
							<li>发酵乳杆菌
							<li>嗜酸乳杆菌
						</ul>
					
					</div>
					<p class="tit mt20">瘦身纤体酸奶粉</p>
										
					<div class="list_con">
						<ul>
							<li>两歧双歧杆菌粉</li>
							<li>长双歧杆菌粉</li>
							<li>乳双歧杆菌粉</li>
							<li>嗜酸乳杆菌粉</li>
							<li>发酵乳杆菌粉</li>
							<li>肠球菌粉</li>
						</ul>
					
					</div>
				</div>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:180px;padding-top:20px"'; ?>>
					<p class="tit mt20">食用纤维&低聚糖</p>
					<div class="list_con">
						<ul>
							<li>抗性糊精（可溶性纤维）</li>
							<li>菊苣粉</li>
							<li>低聚半乳糖</li>
							<li>低聚果糖</li>
							<li>低聚木糖</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">藤黄果提取物</h4>
				
				<div class="list_con">
					<ul>
						
						<li>HCA(60%) :  840毫克</li>
					
					</ul>
				
				</div>
			</div>
			<div class="pop_list">
				<div class="infi_slim">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_slim_img1_ch_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_slim_img1_ch.png" />
					<?php endIf;?>
					
				</div>
			</div>
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<h4 class="title">营养成分（1袋）</h4>
				
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;"'; ?>>
					<ul>
						<li>热量 : 20千卡</li>
						<li>碳水化合物 : 18克</li>
						<li>蛋白质 : 0毫克</li>					
					</ul>
				
				</div>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:200px"'; ?>>
					<ul>
						<li>脂肪 : 0毫克</li>
						<li>钠 : 20毫克</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">食用方法</h4>
				<div class="intake_con slim">
					<ul>
						<li>
							<div class="blind">
								<h4>*莓果思慕雪</h4>
								<div>
									<ol>
										<li>草莓2个</li>
										<li>Blueberry 5ea</li>
										<li>牛奶100毫升</li>
										<li>思慕雪粉末20克（1袋）</li>
										<li>冰块 2个</li>
									</ol>
								</div>
								<p>
									<strong>食用方法</strong><br />
									将材料放入搅拌机，搅拌至冰沙状。
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img2_ch.png" />
						</li>
						<li>
							<div class="blind">
								<h4>绿色思慕雪</h4>
								<div>
									<strong>小贴士</strong>
									<ol>
										<li>包菜1/8个</li>
										<li>苹果1/2个</li>
										<li>青花菜 25克</li>
										<li>牛奶100毫升</li>
										<li>思慕雪粉末20克（1袋）</li>
										<li>冰块 2个</li>
									</ol>
								</div>
								<p>
									<strong>食用方法</strong><br />
									将材料放入搅拌机，搅拌至冰沙状。
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img3_ch.png" />
						</li>
						<li>
							<div class="blind">
								<h4>谷物思慕雪</h4>
								<div>
									<ol>
										<li>藜麦 25克</li>
										<li>糙米 15克</li>
										<li>牛奶100毫升</li>
										<li>思慕雪粉末20克（1袋）</li>
										<li>冰块 2个</li>
									</ol>
								</div>
								<p>
									<strong>食用方法</strong><br />
									将材料放入搅拌机，搅拌至冰沙状
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img4_ch.png" />
						</li>
						<li>
							<div class="blind">
								<h4>坚果思慕雪</h4>
								<div>
									<strong>小贴士</strong>
									<ol>
										<li>杏仁 3个</li>
										<li>核桃 3个</li>
										<li>葡萄干 3个</li>
										<li>牛奶100毫升</li>
										<li>思慕雪粉末20克（1袋）</li>
										<li>冰块 3个</li>
									</ol>
								</div>
								<p>
									<strong>食用方法</strong><br />
									将材料放入搅拌机，搅拌至冰沙状。
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img5_ch.png" />
						</li>
					</ul>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">打印</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">贮存条件</h4>
				<div class="stroage_con">
					<div class="img_con">
						<img src="/assets/images/popup/product_slim_img6_ch.png" />
					</div>
					<p class="mt15">
						避免高温高湿和直光照射，置于通风，阴凉干燥处保存，冷藏效果更佳。
					</p>
				</div>
			</div>
			<div class="pop_list last">
				<h4 class="title">特色</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">使用来自健康人体的专利菌株。</span></li>
					<li><span class="num">02</span><span class="txt">无需担心卡路里的健康营养的零食。</span></li>
					<li><span class="num">03</span><span class="txt">双重保健食品（减肥与肠道健康）</span></li>
					<li><span class="num">04</span><span class="txt">含有840毫克的HCA。</span></li>
					<li><span class="num">05</span><span class="txt">含1亿的乳酸菌。</span></li>
					<li><span class="num">06</span><span class="txt">可制作多种美味的减肥餐。</span></li>
				</ol>
				<div class="ac">
					<img class="charact_img" src="/assets/images/popup/product_slim_img7_ch.png" />
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>