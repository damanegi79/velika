<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="ch">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	
	$(".popup_frame .tab_pannel li a").bind("click", function ( e )
	{
		$(".popup_frame .tab_pannel li").removeClass("on");
		$(this).parent().addClass("on");
		
		var idx = $(this).parent().index();
		
		$(".popup_frame .tab_content li").css({display:"none"});
		$(".popup_frame .tab_content li").eq(idx).css({display:"block"});
	});
	resizeWindow();

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>池根亿 益生菌</h2>
		<div class="info_con">
			<div class="pop_list" style="overflow:hidden">
				<div style="float:left">
					<h4 class="title">成分</h4>
					<p class="tit">益生菌</p>
					<div class="list_con">
						<ul>
							<li>两歧双歧杆菌 20亿/包</li>
							<li>长双岐杆菌 20亿/包</li>
							<li>嗜酸乳杆菌 4亿/包</li>
						</ul>
					</div>
					<p class="tit mt20">益生元</p>
					<div class="list_con">
						<ul>
							<li>低聚半乳糖</li>
							<li>低聚果糖</li>
						</ul>
					</div>
				</div>
				<!-- 
				<div class="video_con" style="float:right">
					<h4 class="title">RELEVANT VIDEO</h4>
					<div class="movie_con">
						<iframe allowfullscreen="" class="YOUTUBE-iframe-video" data-thumbnail-src="https://i.ytimg.com/s_vi/xC7hSuKVyYI/default.jpg?sqp=4CVLFiH7DQU&amp;rs=AOn4CLBcYa3LJ6wYcHfnnK8TeeduQFuNUg" frameborder="0" width="235" height="168" src="https://www.youtube.com/embed/4CVLFiH7DQU?feature=player_embedded&amp;wmode=opaque" ></iframe>
					</div>
				</div>
				-->
			</div>
			<div class="pop_list">
				<h4 class="title">营养成分（每袋）</h4>
				<div class="list_con">
					<ul>
						<li>热量：10千卡</li>
						<li>碳水化合物：2克</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">食用办法</h4>
				<div class="intake_con zigunuk">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_zigunuk_img1_ch_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_zigunuk_img1_ch.png" />
						<?php endIf;?>
					</div> 
					<div class="blind">
						<ol>
							<li>在家中或工作单位每天服用一袋。</li>
							<li>每天2克，用水或其他液体冲服。</li>
						</ol>
					</div>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">打印</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">贮存条件</h4>
				<div class="stroage_con">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_zigunuk_img2_ch_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_zigunuk_img2_ch.png" />
						<?php endIf;?>
						
					</div>
					<p>
						避免高温高湿和直光照射，置于通风，阴凉干燥处保存，冷藏效果更佳。
					</p>
				</div>
				
			</div>
			<div class="pop_list">
				<h4 class="title">特色</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">使用来自人体的专利益生菌。</span></li>
					<li><span class="num">02</span><span class="txt">双歧杆菌和乳酸杆菌的完美组合。</span></li>
					<li><span class="num">03</span><span class="txt">含益生元低聚糖。</span></li>
					<li><span class="num">04</span><span class="txt">改善不规律生活引起的肠道亚健康。</span></li>
				</ol>
				<div class="ac">
					
					<img class="charact_img" src="/assets/images/popup/product_zigunuk_img3_ch.png" />
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">建议</h4>
				
				<div class=tab_pannel>
					<ul>
						<li class="on"><a href="javascript:">适用人群</a></li>
						<li><a href="javascript:">食用方法</a></li>
						<li><a href="javascript:">见效时间</a></li>
						<li><a href="javascript:">选择我们产品的理由</a></li>
					</ul>
				</div>
				
				<div class=tab_content>
					<ul>
						<li>
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab1_ch_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab1_ch.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab2_ch_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab2_ch.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab3_ch_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab3_ch.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab4_ch_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab4_ch.png" />
							<?php endIf;?>
							<div class="story_btn">
								<span class="txt">see more details</span>
								<a href="/ch/story">BIFIDUS STORY<span class="arrow"></span></a>
							</div>
						</li>
					</ul>
				</div>
				
			</div>
			<div class="pop_list last note_con">
				<h4 class="title">功能</h4>
				
				<div class="ac">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_zigunuk_img4_ch_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_zigunuk_img4_ch.png" />
					<?php endIf;?>
				</div>
			</div>
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>