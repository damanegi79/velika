<script type="text/javascript">
setTimeout(function ()
{
	$(".player").append('<iframe allowfullscreen="" class="YOUTUBE-iframe-video" data-thumbnail-src="https://i.ytimg.com/s_vi/xC7hSuKVyYI/default.jpg?sqp=<?=$idx?>&amp;rs=AOn4CLBcYa3LJ6wYcHfnnK8TeeduQFuNUg" frameborder="0" width="700" height="400" src="https://www.youtube.com/embed/<?=$idx?>?feature=player_embedded&amp;wmode=opaque" ></iframe>');
}, 500);

</script>
			

<div class="popup_frame">
	<div class="vod_popup">
		<div class="player"></div>
		<!-- <a class="emt close_btn" href="javascript:closeModalPopup();">close</a>-->
	</div>
</div>