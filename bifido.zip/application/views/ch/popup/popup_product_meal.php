<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="ch">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>BIFIDO餐粉</h2>
		<div class="info_con">
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left"'; ?>>
					<h4 class="title">营养成分</h4>
					<p class="tit">益生菌</p>
					
					<div class="list_con">
						<ul>
							<li>两歧双歧杆菌粉</li>
							<li>长双歧杆菌粉</li>
							<li>嗜酸乳杆菌粉</li>
						</ul>
					
					</div>
				</div>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:180px;padding-top:20px"'; ?>>
					<p class="tit mt20">益生元</p>
					<div class="list_con">
						<ul>
							<li>菊苣纤维</li>
							<li>抗性麦芽糊精</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="pop_list">
				<div class="infi_slim">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_meal_img7_ch_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_meal_img7_ch.png" />
					<?php endIf;?>
				</div>
			</div>
			<div class="pop_list" style="overflow:hidden">
				<h4 class="title">营养成分（1袋）</h4>

					<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;"'; ?>>
						<ul>
							<li>热量：55 千卡</li>
							<li>碳水化合物：16克</li>
							<li>蛋白质： 2克 </li>
					
						</ul>
					</div>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:200px"'; ?>>
					<ul>
						<li>脂肪 : 1.5克 </li>
						<li>胆固醇：≦ 10毫克</li>
						<li>钠：20 毫克</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">食用方法</h4>
				<div class="intake_con meal">
					<ul>
						<li>
							<div class="blind">
								<h4>希腊酸奶</h4>
								<p>比菲德餐粉 20克<br />牛奶 80毫升</p>
								<div>
									<strong>tips</strong>
									<ol>
										<li>为获得更加柔滑的口感，可将比菲德餐粉与牛奶混合搅拌。</li>
										<li>添加新鲜水果，谷物麦片，坚果以及水果干可DIY更营养的比菲德餐！</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img1_ch.png" />
						</li>
						<li>
							<div class="blind">
								<h4>芝士蛋糕</h4>
								<p>比菲德餐粉 40克<br />牛奶 100毫升</p>
								<div>
									<strong>小贴士</strong>
									<ol>
										<li>混合后置于冰箱 2-3个小时。</li>
										<li>可添加水果和果酱。</li>
										<li>比菲德餐芝士蛋糕需冷藏保管。</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img2_ch.png" />
						</li>
						<li>
							<div class="blind">
								<h4>酸奶冰激凌</h4>
								<p>比菲德餐粉 20克<br />牛奶 80毫升</p>
								<div>
									<strong>小贴士</strong>
									<ol>
										<li>用搅蛋器混合牛奶与比菲德粉，更多气泡，更多美味。</li>
										<li>可添加喜爱的水果或风味牛奶，如草莓，香蕉，咖啡，绿茶等。</li>
										<li>可添加新鲜水果和谷物坚果。</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img3_ch.png" />
						</li>
						<li>
							<div class="blind">
								<h4>酸奶奶油 </h4>
								<p>比菲德餐粉 20克<br />牛奶 100毫升</p>
								<div>
									<strong>小贴士</strong>
									<ol>
										<li>柔滑而不甜腻，可涂抹于多种饼干或面包上食用。</li>
										<li>学生及职场人士的营养、简约且美味的早餐。</li>
										<li>女士的健康美味减肥餐。</li>
										<li>老年人的保健食品。</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img4_ch.png" />
						</li>
					</ul>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">打印</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">贮存条件</h4>
				<div class="stroage_con">
					<div class="img_con">
						<img src="/assets/images/popup/product_meal_img5_ch.png" />
					</div>
					<p class="mt15">
						避免高温高湿和直光照射，置于通风，阴凉干燥处保存，冷藏效果更佳。
					</p>
				</div>
				
			</div>
			<div class="pop_list last">
				<h4 class="title">特色</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">健康的早餐，美味的选择！</span></li>
					<li><span class="num">02</span><span class="txt">营养酸奶，呵护您的肠道健康！</span></li>
					<li><span class="num">03</span><span class="txt">健康多一点! 糖分少一点！</span></li>
					<li><span class="num">04</span><span class="txt">含有获得专利的人体由来的菌株!</span></li>
					<li><span class="num">05</span><span class="txt">比菲德餐，热量低，又健康！</span></li>
				</ol>
				<div class="ac">
					
					<img class="charact_img" src="/assets/images/popup/product_meal_img6_ch.png" />
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>