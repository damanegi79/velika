<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});
	$(window).resize();
			
			
	function resizeImg( e )
	{
				
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>化妆品</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bori_detox_cream_img.png" />
							</div>
							<div class="txt_con">
								<h4>排毒霜</h4>
								<p>
									通过双歧杆菌发酵液，发酵红参以及发酵黄芩的完美结合让皮肤重新焕发光彩。
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bori_detox_serum_img.png" />
							</div>
							<div class="txt_con">
								<h4>排毒精华</h4>
								<p>
									结合天然活性益生菌和发酵植物提取物，无酒精，无人工合成色素，更贴近自然，更健康！
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/pbs_img.png" />
							</div>
							<div class="txt_con">
								<h4>PBS （益生菌美颜方案）</h4>
								<p>
									吃出美，吃出健康！让BORI AR81 PBS 成就您的内外兼修之美
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->