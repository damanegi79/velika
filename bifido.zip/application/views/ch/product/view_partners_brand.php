<script type="text/javascript">

$(function ()
{
	
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		if(idx == 0)
		{
			$(".partners1").css({display:"block"});
			$(".partners2").css({display:"none"});
		}
		else
		{
			$(".partners1").css({display:"none"});
			$(".partners2").css({display:"block"});
		}
		
	});			
});

</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">			
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>合作伙伴品牌</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- tab_pannel
					<div class="tab_pannel">
						<ul>
							<li class="on"><a href="javascript:">ODM PROCESS</a></li>
							<li><a href="javascript:">PRODUCT</a></li>
						</ul>
					</div>
					 -->
					
					<div class="partners1">
						<div class="blind">
							<h2>ODM PROCESS</h2>
							<ol>
								<li>
									<h4>Demand by customer</h4>
								</li>
								<li>
									<h4>Consult about business</h4>
									<p>Sales department & central institute of research</p>
								</li>
								<li>
									<h4>Conclude the contract</h4>
									<p>Sales department</p>
								</li>
								<li>
									<h4>Develop preparations & Decide on specimen</h4>
									<p>Planning department & central institute of research</p>
								</li>
								<li>
									<h4>Develop design & Decide on specimen</h4>
									<p>Production department & central institute of research</p>
								</li>
								<li>
									<h4>Produce</h4>
									<p>Production department & central institute of research</p>
								</li>
								<li>
									<h4>Deliver</h4>
									<p>Production support department</p>
								</li>
							</ol>
						</div>
						<div class="img_con">
							<img src="/assets/images/product/odm_img_ch.png" />
						</div>
					</div>
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->