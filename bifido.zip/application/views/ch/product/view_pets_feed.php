<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});

	$(window).resize();
	
	

	function resizeImg( e )
	{
		
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>宠物的益生菌</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/real_bifidus_img.png" />
							</div>
							<div class="txt_con">
								<h4>REAL BIFIDUS (宠物用)</h4>
								<p>
									REAL BIFIDUS是一款专供宠物用的益生菌产品，它运用了独特的配方和菌株，让宠物更加健康。 同时通过BIFIDO公司的独有的小片剂技术，让喂养宠物更容易！
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/real_bifidus_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->


						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/cat_img.png" />
							</div>
							<div class="txt_con">
								<h4>REAL BIFIDUS (猫)</h4>
								<p>
									是一款同时含必需营养素和益生菌的产品。同时它也运用了BIFIDO公司的独有的小片剂技术，让您的小猫可以方便地食用美味的可咀嚼型益生菌产品。这是一款专为猫研发制作的益生菌产品，因为我们添加了猫类必需氨基酸-牛磺酸和L-赖氨酸，让您的小猫更健康！
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/cat_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->						
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/cd7_img.png" />
							</div>
							<div class="txt_con">
								<h4>CD7 (鸡)</h4>
								<p>
									CD7特别添加了4种植物乳酸菌和3种双歧杆菌，这些菌株可以改善鸡类的肠道健康，增加鸡肠道内的有益益生菌，减少有害菌。
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/cd7_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/k9_img.png" />
							</div>
							<div class="txt_con">
								<h4>K9 (牛)</h4>
								<p>
									K9特别添加了3种双歧杆菌和两种乳酸杆菌， 这些菌株可以调节牛肠道的菌群平衡和改善牛的肠道健康。
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/k9_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/mr6_img.png" />
							</div>
							<div class="txt_con">
								<h4>MR.6 (鱼)</h4>
								<p>
									MR.6特别添加了3种植物乳酸杆菌和3种双歧杆菌，这些菌株可以调节鱼类肠道的菌群平衡和改善鱼类的肠道健康。
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/mr6_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->