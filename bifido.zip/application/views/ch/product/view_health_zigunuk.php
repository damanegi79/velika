<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["zigunuk", "partners"];
		var idx =e.target.index();
		location.href = "/ch/product/probiotics/health?category="+linkAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">池根亿品牌产品</a></li>
						<li><a href="javascript:">合作伙伴品牌</a></li>
					</ul>
				</div>
				<!-- //tab_pannel -->
				<div class="box mt50"></div>
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>婴幼儿用 <span>(3-36个月)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bifiduc_baby_img.png" />
							</div>
							<div class="txt_con">
								<h4>池根亿婴幼儿益生菌</h4>
								<p>
									本产品是由首尔大学食品营养学科池根亿教授研究团队利用从韩国人的肠胃里分离出的双歧杆菌（BGN4, BORI）和乳酸杆菌研发而成，是一款适用于3个月到36个月婴幼儿的双歧杆菌营养食品.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/ch/popup/product_baby');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->

					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>女性用 <span>(减肥&肠道健康)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/slim_yogurtics_img.png" />
							</div>
							<div class="txt_con">
								<h4>瘦身纤体酸奶粉</h4>
								<p>
									酸奶与益生菌的完美结合，DIY属于个人风格的多种美味早餐，保持肠道健康的同时拥有苗条的身材。
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/ch/popup/product_slim');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>成人用</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_bifidus_img.png" />
							</div>
							<div class="txt_con">
								<h4>池根亿 益生菌</h4>
								<p>
									本产品是由首尔大学食品营养学科池根亿教授研究组利用从韩国人的肠胃里分离出的双歧杆菌（BGN4, BORI），乳酸杆菌以及双歧杆菌的生长因子低聚半乳糖研发的一款适用于成人的双歧杆菌保健食品。
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/ch/popup/product_zigunuk');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_prog_img_en.png" />
							</div>
							<div class="txt_con">
								<h4>Dr.G Synbiotics</h4>
								<p>
									本产品是由首尔大学食品营养学科池根亿教授研究组利用从韩国人的肠胃里分离出的双歧杆菌（BGN4, BORI），乳酸杆菌以及双歧杆菌的生长因子低聚果糖（含量≧3000mg)研发的一款适用于全家的双重保健食品。
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/ch/popup/product_prog');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->