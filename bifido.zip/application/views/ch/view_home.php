<script type="text/javascript" src="/assets/js/main.js"></script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">

		<!-- bifido_home -->
		<section class="bifido_home">
			
			<!-- visual_con -->
			<div class="visual_con">
				<div class="visual_set">
					<div class="rol_target">
						<ul class="rol_ul">
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg1.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg1_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">成就健康生活</h2>
									<p class="title">
										世界级优质益生菌 BIFIDO Co., Ltd.
									</p>
								</div>
							</li>
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg2.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg2_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">为改善免疫系统尽最大努力</h2>
									<p class="title">
										世界级优质益生菌 BIFIDO Co., Ltd.
									</p>
								</div>
							</li>
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg3.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg3_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">专注于双歧杆菌</h2>
									<p class="title">
										世界级优质益生菌 BIFIDO Co., Ltd.
									</p>
								</div>
							</li>
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg4.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg4_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">关心人类健康</h2>
									<p class="title">
										世界级优质益生菌 BIFIDO Co., Ltd.
									</p>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- //visual_con -->
			
			<!-- "visual_pager" -->
			<div class="visual_pager">
				<div class="pager_con">
					<a href="javascript:"><span class="emt on">1</span></a>
					<a href="javascript:"><span class="emt on">2</span></a>
					<a href="javascript:"><span class="emt on">3</span></a>
					<a href="javascript:"><span class="emt on">4</span></a>
				</div>
			</div>
			<!-- //"visual_pager" -->
			
			<!-- banner_con -->
			<div class="banner_con">
				<!-- banner_set -->
				<div class="banner_set">
					<ul>
						<li>
							<a href="/ch/story">
								<div class="img_con"><img class="m_img" src="/assets/images/main/banner_icon1.png" alt="BIFIDUS STORY" /></div>
								<div class="txt_con">
									<h4>双歧杆菌的故事</h4>
									<p>介绍双歧杆菌的故事</p>
								</div>
							</a>
						</li>
						<li>
							<a href="/ch/customer/event">
								<div class="img_con"><img class="m_img" src="/assets/images/main/banner_icon2.png" alt="BIFIDUS STORY" /></div>
								<div class="txt_con">
									<h4>未来动向</h4>
									<p>确认公司动态并加入我们</p>
								</div>
							</a>
						</li>
						<li>
							<a href="/ch/product">
								<div class="img_con"><img class="m_img" src="/assets/images/main/banner_icon3.png" alt="BIFIDUS STORY" /></div>
								<div class="txt_con">
									<h4>新产品</h4>
									<p>增强免疫系统的产品</p>
								</div>
							</a>
						</li>
					</ul>
				</div> 
				<!-- //banner_set -->
			</div> 
			<!-- //banner_con -->
			
		</section>
		<!-- //bifido_home -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->