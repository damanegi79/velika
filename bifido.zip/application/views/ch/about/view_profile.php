
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>专注领域</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					带着对最高生物科学技术的挑战精神，BIFIDO以食品科学技术为依托，正在努力成为世界最强的益生菌公司。
				</div>
				<!-- //sub_title -->
				<!-- profile -->
				<div class="profile">
					<!-- profile_list -->
					<div class="profile_list">
						<ul>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon1.png" alt="Professional on bifidus" />
									</div>
									<h4 class="titl">专注于双歧杆菌</h4>
								</div>
								<div class="txt_con">
									<p>
										我们专注于乳酸菌的基础研究和乳酸菌的产品开发。在众多益生菌中，双歧杆菌被认为是保持肠道菌群平衡最重要的一种有益的微生物。如今, 双歧杆菌和其他乳酸菌被广泛运用于功能食品中。而 株式会社BIFIDO利用有关双歧杆菌的大量研究成果，正在发展成为双岐杆菌领域的龙头企业。
									</p>
								</div>
							</li>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon2.png" alt="Business area" />
									</div>
									<h4 class="titl">业务范围</h4>
								</div>
								<div class="txt_con">
									<p>
										我们运用自身的技术进行乳酸菌和发酵红参的生产， 同时还提供终产品和定牌产品。为了扩大乳酸菌在我们日常生活中的应用，我们努力发展成为乳酸菌功能食品领域的龙头企业。
									</p>
								</div>
							</li>
							<li class="end">
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon3.png" alt="Research & Development" />
									</div>
									<h4 class="titl">研究开发领域</h4>
								</div>
								<div class="txt_con">
									<p>
										株式会社BIFIDO的CEO池根亿是首尔大学食品营养学科教授，他在路易斯安那大学和斯坦福大学先后进行过研究活动，是肠内微生物和双歧杆菌乳酸菌领域的权威学者。设在首尔大学的实验室被指定为以生菌剂为主要研究领域的国家指定研究所。国家指定研究所是科技部主管的项目，在全国范围选定需要战略性培养的一些核心技术领域的优秀研究室作为国家指定研究室，并支援核心研究力量。
									</p>
								</div>
							</li>
						</ul>
					</div>
					<!-- //profile_list -->
				</div>
				<!-- //profile -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->