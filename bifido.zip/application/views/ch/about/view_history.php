<script type="text/javascript">
$(function ()
{
	$(".history_set .current img").css({"position":"relative"});
	$(".history_set .old img").css({"position":"relative"});
	
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		TweenMax.to($(".history_set"), 0.8, {y:-$(".history_content").height()*idx, ease:Expo.easeInOut});
		TweenMax.to($(".history_top .top_set"), 0.6, {y:-$(".history_top").height()*idx, ease:Expo.easeInOut});
		if(idx == 1)
		{
			$(".history_top").css({})
			TweenMax.to($(".history_set .current img"), 0, {y:$(".history_content").height()/2});
			TweenMax.to($(".history_set .current img"), 1.2, {y:0, ease:Expo.easeInOut});
			$(".history_mobile .current").css({display:"block"});
			$(".history_mobile .old").css({display:"none"});
			
		}
		else
		{
			
			TweenMax.to($(".history_set .old img"), 0, {y:-$(".history_content").height()/2});
			TweenMax.to($(".history_set .old img"), 1.2, {y:0, ease:Expo.easeInOut});
			$(".history_mobile .current").css({display:"none"});
			$(".history_mobile .old").css({display:"block"});
		}
	});

});

</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			$this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>公司沿革</h4>
					<span class="line"></span>
				</div>
				
				<!-- tab_pannel -->
				<div class=tab_pannel>
					<ul>
						<li class="on"><a href="javascript:">1988 ~ 2003</a></li>
						<li><a href="javascript:">2004 ~ 现在</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
					
				<!-- //main_title -->
				<!-- history -->
				<div class="history">
					
					<!-- history_con -->
					<div class="history_top">
						<div class="top_set">
							<div class="history_old">
								<div class="blind">
									<h4>1988~2003</h4>
									<p>the quickening period</p>
								</div>
								<img src="/assets/images/about_bifido/history_en_top_old.png" />
							</div>
							
							<div class="history_current">
								<div class="blind">
									<h4>2004~CURRENT</h4>
									<p>time of development</p>
								</div>
								<img src="/assets/images/about_bifido/history_en_top_current.png" />
							</div>
						</div>
					</div>
					<!-- //history_top -->
					
					<!-- history_content -->
					<div class="history_content">
						<div class="history_set">
							<div class="history_con old">
								<span class="line"></span>
								<ol class="blind">
									<li>
										<h4>1988</h4>
										<p>Bifidus research and study by Pro.JI</p>
									</li>
									<li>
										<h4>1988 ~ Current</h4>
										<p>We have researched bifidus 27 years</p>
									</li>
									<li>
										<h4>1999.10</h4>
										<p>BIFIDO CO., Ltd. was established in Seoul</p>
									</li>
									<li>
										<h4>2001.06</h4>
										<p>'Zigunuk Bifidus' was introduced to the market</p>
									</li>
									<li>
										<h4>2002.12</h4>
										<p>‘Zigunuk Bifidus Baby'was introduced to the market</p>
									</li>
									<li>
										<h4>2003.03</h4>
										<p>National Research Labortory for Probiotics.</p>
									</li>
									<li>
										<h4>2003.09</h4>
										<p>The first factory</p>
									</li>
								</ol>
								<img src="/assets/images/about_bifido/history_ch_old.png" />
							</div>
							
							<div class="history_con current">
								<span class="line"></span>
								<ol class="blind">
									<li>
										<h4>1988</h4>
										<p>Bifidus research and study by Pro.JI</p>
									</li>
									<li>
										<h4>1988 ~ Current</h4>
										<p>We have researched bifidus 27 years</p>
									</li>
									<li>
										<h4>1999.10</h4>
										<p>BIFIDO CO., Ltd. was established in Seoul</p>
									</li>
									<li>
										<h4>2001.06</h4>
										<p>'Zigunuk Bifidus' was introduced to the market</p>
									</li>
									<li>
										<h4>2002.12</h4>
										<p>‘Zigunuk Bifidus Baby'was introduced to the market</p>
									</li>
									<li>
										<h4>2003.03</h4>
										<p>National Research Labortory for Probiotics.</p>
									</li>
									<li>
										<h4>2003.09</h4>
										<p>The first factory</p>
									</li>
								</ol>
								<img src="/assets/images/about_bifido/history_ch_current.png" />
							</div>
						</div>
						<!-- //history_set -->
						<!-- history_mobile -->
						<div class="history_mobile">
							<div class="history_con old">
								<img src="/assets/images/about_bifido/history_ch_old_m.png" />
							</div>
							<div class="history_con current">
								<img src="/assets/images/about_bifido/history_ch_current_m.png" />
							</div>
						</div>
						<!-- //history_mobile -->
					</div>
					<!-- //history_content -->
					
				</div>
				<!-- //profile -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->