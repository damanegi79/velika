<script type="text/javascript">
	

$(function ()

	{
	
		$(".vod_list li").bind("mouseenter", function ()
	
		{
		
			TweenMax.to($(this).find("img"), 1, {scaleX:1.2, scaleY:1.2, ease:Cubic.easeOut});
		
});

		$(".vod_list li").bind("mouseleave", function ()

		{
			
TweenMax.to($(this).find("img"), 1, {scaleX:1, scaleY:1, ease:Cubic.easeOut});
	
		});
	});
	


function showVod( id )
	
{
	
		if(!isMobile)

		{
		
			openModalPopup("/ch/popup/vod/"+id);
	
		}
	
		else

		{
		
			location.href = "http://www.youtube.com/embed/"+id;
	
		}

	}


</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>VOD</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- vod -->
				<div class="vod">
					<div class="vod_list">
						<ul>
							<?php $count=0; ?>
							<?php foreach($vod_list as $list): ?>
							<?php if($list->category != "about"):?>
							<li class="<?php if($count%4=="0"){echo 'l';}?> <?php if($count>3){ echo 't';}?>">
								<a href="javascript:showVod('<?=$list->youtubePath?>');">
									<div class="thumb_con">
										<img src="<?=$list->imgPath?>" />
										<span class="play"></span>
									</div>
									<p class="title"><?=nl2br($list->titleCh)?></p>
								</a>
							</li>
							<?php $count++; ?>
							<?php endif;?>
							<?php endforeach;?>
						</ul>
					</div>
					
					<div class="sub_title">About probiotics (Animation with characters)</div>
					
					<div class="vod_list">
						<ul>
							<?php $count=0; ?>
							<?php foreach($vod_list as $list): ?>
							<?php if($list->category == "about"):?>
							<li class="<?php if($count%4=="0"){echo 'l';}?> <?php if($count>3){ echo 't';}?>">
								<a href="javascript:showVod('<?=$list->youtubePath?>');">
									<div class="thumb_con">
										<img src="<?=$list->imgPath?>" />
										<span class="play"></span>
									</div>
									<p class="title"><?=$list->titleCh?></p>
								</a>
							</li>
							<?php $count++; ?>
							<?php endif;?>
							<?php endforeach;?>
						</ul>
					</div>
				</div>
				<!-- //profile -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->