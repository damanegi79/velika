<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/ch/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1_on.png" /></div>
								<h4>发酵人参</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4>BIFIDO的竞争优势</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>专利文献</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<h4>什么是发酵人参？</h4>
						<p class="mt10">
							迄今为止,从高丽人参中分离出30多种人参皂苷单体，根据构造不同可分为原人参二醇系皂苷，原人参三醇系皂苷和齐墩果烷，而其药理功效也不相同，人参皂苷是人参中最主要的的功能性成分，但人参皂苷只有经过微生物或者酶分解成小分子后才能被人体吸收。<br />
							<br />
							我们已经研发出利用食品级微生物发酵人参的方法以提高人参皂苷的吸收率，并称之为“发酵人参”。
						</p>	
					</div>
					
					<div class="fermented_list">
						<div class="ginseng_list">
							<ol class="blind">
								<li>
									<h4>GINSENG</h4>
									<p>Before Red Ginseng made its mark,<br />common ginsengs were the best<br />in its own right.</p>
								</li>
								<li>
									<h4>RED GINSENG</h4>
									<p>Before we found out about<br />Fermented Ginseng Extract,<br />Red Ginseng was the best.</p>
								</li>
								<li>
									<h4>PERMENTED<br />GINSENG EXTRACT</h4>
									<p>But now the time belongs to<br />Fermented Ginseng Extracts.<br />It generates plenty of effective<br />medicinal ingredient.</p>
								</li>
							</ol>
							<img class="m_img" src="/assets/images/raw_material/permented_img1_ch.png" />
						</div>	
					</div>
					
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->