<script type="text/javascript">

$(function ()
{
	$(".intro_list").each(function ( i )
	{
		var left = $(".probiotics").width()*i;
		$(this).css({left:left});
	});

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		var left = -1000*idx;
		TweenMax.to($(".intro_con .list_set"), 1, {x:left, ease:Expo.easeInOut});
		$(".intro_con_m .intro_list").css({display:"none"});
		$(".intro_con_m .intro_list").eq(idx).css({display:"block"});
	});

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".service_list li").removeClass("blind");
		}
		else
		{
			$(".service_list li").addClass("blind");
		}
	});

});



</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>我们生产的益生菌</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics -->
				<div class="probiotics">
				
					<!-- "produce_con" -->
					<div class="produce_con">
						<ul>
							<li class="l">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img1.png" /></div>
								<p class="title">B.bifidum <strong>BGN4</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img2.png" /></div>
								<p class="title">B.longum <strong>BORI</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img3.png" /></div>
								<p class="title">B.lactis <strong>AD011</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img4.png" /></div>
								<p class="title">B.lactis <strong>AS60</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img5.png" /></div>
								<p class="title">B.infantis <strong>BH07</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img6.png" /></div>
								<p class="title">L.acidophilus <strong>AD031</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img7.png" /></div>
								<p class="title">L.paracasei <strong>BH08</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img8.png" /></div>
								<p class="title">L.plantarum <strong>BH02</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img9.png" /></div>
								<p class="title">L.casei <strong>IBS041</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img10.png" /></div>
								<p class="title">L.fermentum <strong>BH03</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img11.png" /></div>
								<p class="title">L.rhamnosus <strong>BH09</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img12.png" /></div>
								<p class="title">L.bulgaricus <strong>BH04</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img13.png" /></div>
								<p class="title">L.lactis <strong>BH10</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img14.png" /></div>
								<p class="title">S.thermophilus <strong>BH05</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img15.png" /></div>
								<p class="title">E.faecium <strong>BH06</strong></p>
							</li>
						</ul>
					</div>
					<!-- //"produce_con" -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>产品介绍</h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						<strong>我们可以提供多种形态和浓度的产品。</strong>
						BIFIDO根据顾客的需求可提供粉末，小袋，胶囊及片剂型的产品。各产品可包装为菌原料粉， PTP包装的散装胶囊，散装片剂以及瓶装或纸盒包装的终产品。
					</div>
					<!-- //sub_title -->
					
					<!-- tab_pannel -->
					<div class="tab_pannel">
						<ul>
							<li class="on"><a href="javascript:">粉末</a></li>
							<li><a href="javascript:">小袋装</a></li>
							<li><a href="javascript:">胶囊</a></li>
							<li><a href="javascript:">片剂</a></li>
						</ul>
					</div>
					<!-- //tab_pannel -->
					
					<!-- intro_con" -->
					<div class="intro_con">
						<!-- list_set" -->
						<div class="list_set">
							<!-- powder" -->
							<div class="intro_list powder">
								<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img_ch.png" /></div>
								<div class="txt_con">
									<h4>粉末形态</h4>
									<p>
										通过离心分离及冻干过程，培养的益生菌稳定性得到增强，<br />
										利用严选的赋形剂稀释，从而增加生菌粉的稳定性。
									</p>
									<p>
										品质保证系统是维持BIFIDO粉末形态产品优质的重要因素。<br />
										BIFIDO质量管理团队对产品的外观、水分、水分活性、<br />
										赋形剂、颜色、味道等进行严格地监控。

									</p>
									<p>
										根据客户的需求可以在原益生菌粉末中添加益生元等其它成分。
									</p>
								</div>
							</div>
							<!-- //powder -->
							<!-- stick" -->
							<div class="intro_list stick">
								<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img_ch.png" /></div>
								<div class="txt_con">
									<h4>小袋装</h4>
									<p>
										我们的产品在包装时注入氮气以维持益生菌的稳定性。<br />
										通过自动化生产线，可实现多种形态和不同尺寸产品的生产。<br />
										在二次包装时添加干燥剂，<br />
										双重保护产品不受任何危险环境因素的影响。

									</p>
									<p>
										为了减少小袋密封时受热的影响，<br />
										我们使用独有的冷却系统密封小袋。
									</p>
								</div>
							</div>
							<!-- //stick" -->
							<!-- capsule" -->
							<div class="intro_list capsule">
								<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img_ch.png" /></div>
								<div class="txt_con">
									<h4>胶囊形态</h4>
									<p>
										胶囊形态可避免益生菌与氧气的接触，提高稳定性。<br />
										BIFIDO<a href="javascript:openPopup('/ch/popup/material_enteral');">肠溶包衣技术<span class="link"></span></a>
										提高了益生菌在消化道的存活率。

									</p>
									<div class="list">
										<dl>
											<dt style="width:110px">· <strong>优点 :</strong></dt>
											<dd>服用方便，携带简便。</dd>
										</dl>
										<dl>
											<dt style="width:110px">· <strong>缺点 :</strong></dt>
											<dd>
												益生元是益生菌的生长因子，<br />
												可添加在胶囊中的益生元量有限。
											</dd>
										</dl>
									</div>
									<div class="list">
										<dl>
											<dt style="width:130px">· 胶囊材料 :</dt>
											<dd>Gelatin, HPMC, HPMCP</dd>
										</dl>
										<dl>
											<dt style="width:130px">· 胶囊尺寸 :</dt>
											<dd>0 / 1</dd>
										</dl>
									</div>
								</div>
							</div>
							<!-- //capsule -->
							<!-- tablet" -->
							<div class="intro_list tablet">
								<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img_ch.png" /></div>
								<div class="txt_con">
									<h4>片剂形态</h4>
									<p>
										BIFIDO<a href="javascript:openPopup('/ch/popup/material_tablet');">小片剂技术</a><span class="link"></span>不仅可以维持益生菌的活性，还可以降低粘合剂的添加量。<br />
										<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2_ch.png" />
									</p>
								</div>
							</div>
							<!-- //tablet -->
						</div>
						<!-- //list_set" -->
					</div>
					<!-- //intro_con" -->
					
					<!-- intro_con_m" -->
					<div class="intro_con_m">
						<!-- powder" -->
						<div class="intro_list powder">
							<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img_ch_m.png" /></div>
							<div class="txt_con">
								<h4>粉末形态</h4>
								<p>
									通过离心分离及冻干过程，培养的益生菌稳定性得到增强，利用严选的赋形剂稀释，从而增加生菌粉的稳定性。
								</p>
								<p>
									品质保证系统是维持比菲德粉末形态产品优质的重要因素。<br />
									BIFIDO质量管理团队对产品的外观、水分、水分活性、赋形剂、颜色、味道等进行严格地监控。
								</p>
								<p>
									根据客户的需求可以在原益生菌粉末中添加益生元等其它成分。
								</p>
							</div>
						</div>
						<!-- //powder -->
						<!-- stick" -->
						<div class="intro_list stick">
							<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img_ch_m.png" /></div>
							<div class="txt_con">
								<h4>小袋装</h4>
								<p>
									我们的产品在包装时注入氮气以维持益生菌的稳定性。<br />
									通过自动化生产线，可实现多种形态和不同尺寸产品的生产。<br />
									在二次包装时添加干燥剂，双重保护产品不受任何危险环境因素的影响。

								</p>
								<p>
									为了减少小袋密封时受热的影响，我们使用填缝枪，利用超音波密封小袋。
								</p>
							</div>
						</div>
						<!-- //stick" -->
						<!-- capsule" -->
						<div class="intro_list capsule">
							<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img_ch_m.png" /></div>
							<div class="txt_con">
								<h4>胶囊形态</h4>
								<p>
									胶囊形态可避免益生菌与氧气的接触，提高稳定性。<br />
									BIFIDO<a href="javascript:openPopup('/ch/popup/material_enteral');">肠溶包衣技术<span class="link"></span></a>
									提高了益生菌在消化道的存活率。
									<br />
									<br />
									· <strong>优点 :</strong>服用方便，携带简便。<br />
									· <strong>缺点 :</strong>益生元是益生菌的生长因子，可添加在胶囊中的益生元量有限。<br />
									<br />
									· 胶囊材料 : Gelatin, HPMC, HPMCP<br />
									· 胶囊尺寸 : G0 / 1<br />
								</p>
							</div>
						</div>
						<!-- //capsule -->
						<!-- tablet" -->
						<div class="intro_list tablet">
							<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img_ch_m.png" /></div>
							<div class="txt_con">
								<h4>片剂形态</h4>
								<p>
									BIFIDO<a href="javascript:openPopup('/ch/popup/material_tablet');">小片剂技术</a><span class="link"></span>不仅可以维持益生菌的活性，还可以降低粘合剂的添加量。<br />
									<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2_ch_m.png" />
								</p>
							</div>
						</div>
						<!-- //tablet -->
					</div>
					<!-- //intro_con_m" -->
					
					<!-- main_title -->
					<div class="main_title">
						<p>我们产品的主要优势</p>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- product_con -->
					<div class="product_con">
						<div class="product_list">
							<ul>
								<li style="top:30px;left:20px">
									<h4>来源于人体</h4>
									<p>
										临床试验证明, 人源性益生菌更容易附着于肠壁绒毛, <br />
										并在肠道生长繁殖。
									</p>
								</li>
								<li class="r" style="top:30px;right:20px">
									<h4>
										有据可查的研究论文和专利
									</h4>
									<p>
										· 26个专利<br />
										· 100余篇有关乳酸菌研究论文 
									</p>
								</li>
								<li style="bottom:30px;left:20px">
									<h4>BIFIDO是专门研究双歧杆菌的企业</h4>
									<p>
										我们在益生菌的研究和培养上具备专业性，<br />
										尤其是在人源性厌氧性双歧杆菌领域。

									</p>
								</li>
								<li class="r" style="bottom:30px;right:20px">
									<h4>低风险</h4>
									<p>
										· 无须担心动物来源益生菌引起无益的<br />
										DNA结合的潜在风险。
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">更多内容</span>
							<a href="/ch/story">BIFIDUS STORY<span class="icon"></span></a>
						</div>
					</div>
					<!-- //product_con -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>文献服务 <span>(研究论文，专利, 认证)</span></h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						BIFIDO具备丰富的益生菌研究经验
					</div>
					<!-- //sub_title -->
					
					<!-- "service_con" -->
					<div class="service_con ch">
						<div class="service_list">
							<ul>
								<li class="blind">
									<h4>COMPANY</h4>
									<p>
										· GMP certificate
									</p>
								</li>
								<li class="blind">
									<h4>STRAINS</h4>
									<p>
										· Halal certi clinical<br />
										· Studies stability data<br />
										· Etc.
									</p>
								</li>
								<li class="blind">
									<h4>DOCUMENTS FOR REGISTRATION</h4>
									<p>
										· Certificate of free sales<br />
										· Certificate of analysis<br />
										· Health certificate<br />
										· Certificate of origin<br />
										· Etc.
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">更多内容 </span>
							<a href="/ch/about/download/brochure">DOWNLOAD<span class="icon"></span></a>
						</div>
					</div>
					<!-- //"service_con" -->
					
					
					
				</div>
				<!-- //probiotics -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->