<script type="text/javascript">

$(function ()
{
	var selectNum = 0;
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/ch/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});

	$(".activ_list li").each(function ( i )
	{
		$(this).find("a").bind("click", function ( e )
		{
			changeActiv5($(this).parent().index());
		});
	});

	changeActiv5(0);

	function changeActiv5( idx )
	{
		$(".activ_list li").each(function ( i )
		{
			if(idx == i)
			{
				$(this).css({opacity:1});
			}
			else
			{
				$(this).css({opacity:0});
			}
		});
		$(".activ_info .info_con").css({display:"none"});
		$(".activ_info .info_con").eq(idx).css({display:"block"});
		
		selectNum = idx;
	}

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".activ_info .info_con").css({display:"block"});
		}
		else
		{
			changeActiv5(selectNum);
		}
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1.png" /></div>
								<h4>发酵人参</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2_on.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4>BIFIDO的竞争优势</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>专利文献</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<p>
							通过发酵人参，人参皂苷的糖基部分转化成非糖基部分，换一句话说，人参皂苷被双歧杆菌分解成小分子的人参皂苷元。
							<br /><br />
							发酵人参含有高浓度的Compound K, Rh1, Rh2, Rg5, Rk1等多种人参皂苷代谢产物，不仅能提高人体的吸收率，还可以提高其药理效果。
						</p>	
					</div>
					
					<div class="fermented_list">
						<div class="list_page">
							<h3>人参皂苷的药理功效</h3>
							<div class="line2"></div>
							<div class="activ_list">
								<h4 class="blind">ginsenosides</h4>
								<div class="menu_con">
									<ul>
										<li style="top:-154px;left:-78px"><a href="javascript:">RG1</a></li>
										<li style="top:-154px;left:86px"><a href="javascript:">RG2</a></li>
										<li style="top:-32px;left:149px"><a href="javascript:">RG3</a></li>
										<li style="top:90px;left:85px"><a href="javascript:">C.K</a></li>
										<li style="top:90px;left:-77px"><a href="javascript:">RH1</a></li>
										<li style="top:-32px;left:-141px"><a href="javascript:">RH2</a></li>
									</ul>
								</div>
							</div>
							<div class="activ_info">
								<div class="info_con">
									<h2>RG1</h2>
									<div class="list_set">
										<ul>
											<li>增强免疫力</li>
											<li>防止血小板凝固</li>
											<li>提高记忆力</li>
										</ul>
										<ul>
											<li>缓解疲劳和压力</li>
											<li>刺激神经系统</li>
											<li>促进细胞分裂和DNS合成</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RG2</h2>
									<div class="list_set">
										<ul>
											<li>防止血小板凝固</li>
											<li>提高记忆力</li>
											<li>调节细胞内钙离子的汇集</li>
										</ul>
										<ul>
											<li>诱导乙酰胆碱分泌</li>
											<li>抑制过多的儿茶酚胺生成</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RG3</h2>
									<div class="list_set">
										<ul>
											<li>抑制癌细胞增殖</li>
											<li>抑制血管内的血液凝固</li>
											<li>用于抗肿瘤药物</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>Compound K</h2>
									<div class="list_set">
										<ul>
											<li>抑制肿瘤细胞的增殖和炎症</li>
											<li>抗肿瘤活性</li>
											<li>抗促癌活性和抗肿瘤功效</li>
											<li>抗过敏功效</li>
										</ul>
										<ul>
											<li>缓解阿尔茨海默病</li>
											<li>抗糖尿病和抗氧化</li>
											<li>促进胰岛素分泌</li>
											<li>保肝和护肤的功效</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RH1</h2>
									<div class="list_set">
										<ul>
											<li>抗过敏功效</li>
											<li>抗炎症效果</li>
											<li>抑制多种癌细胞的细胞毒性作用</li>
										</ul>
										<ul>
											<li>防止肿瘤细胞的增殖和分化</li>
											<li>抑制肝脏疾病</li>
											<li>防止血小板凝固</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RH2</h2>
									<div class="list_set">
										<ul>
											<li>防止肿瘤细胞的增殖和分化</li>
											<li>抗炎症效果</li>
										</ul>
										<ul>
											<li>抗过敏功效</li>
											<li>促进胰岛素分泌和提高胰岛素敏感度</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="line2 mt40"></div>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->