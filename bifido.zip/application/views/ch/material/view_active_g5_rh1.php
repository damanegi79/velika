<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/ch/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});		
	
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">CLINICAL TRIAL</a></li>
						<li class="on"><a href="javascript:">RH1</a></li>
						<li><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li><a href="javascript:">COMPOUND K</a></li>
						<?Php else: ?>
							<li><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				<!-- main_title -->
				<div class="main_title">
					<label>Fermented Ginseng</label>
					<h4>RH1</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="active_g5_list">
						
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/raw_material/rh1_img.png" />
							</div>
							<div class="list_set">
								<h4>人参皂苷 Rh1的功效</h4>
								<ol>
									<li><span class="num">01</span><span class="txt">抗过敏效果</span></li>
									<li><span class="num">02</span><span class="txt">抗炎症效果</span></li>
									<li><span class="num">03</span><span class="txt">抑制多种癌细胞的细胞毒性作用</span></li>
									<li><span class="num">04</span><span class="txt">防止肿瘤细胞的增殖和分化</span></li>
									<li><span class="num">05</span><span class="txt">抑制肝脏疾病</span></li>
									<li><span class="num">06</span><span class="txt">防止血小板凝固</span></li>
								</ol>
							</div>
						</div>
						
						<div class="list_bottom">
							<h4>专利 : M生产人参皂苷 Rh1的方法</h4>
							<p>
								本发明是关于生产人参皂苷Rh1的方法，详细阐述了双歧杆菌微生物与人参萃取物相互反应而生成人参代谢产物人参皂苷Rh1的方法。
							</p>						
						</div>
						
						<div class="page_bottom">
							<h4>论文</h4>
							<ol>
								<li>
									<span>1.</span>
									<span class="txt">
										Control of phenotypic expression of cultured B16 melanoma cells by plant glycosides. Cancer Res. 45: 2781-2784 (1985)
									</span>
								</li>
								<li>
									<span>2.</span>
									<span class="txt">
										Plant-glycoside modulation of cell surface related to control of differentiation in cultured B16 melanoma cells.Cancer Res. 47: 3863-3867 (1987)
									</span>
								</li>
								<li>
									<span>3.</span>
									<span class="txt">
										Immunocytochemical localization of rH1 sodium channel in adult rat heart atria and ventricle. Presence in terminal intercalated disks. Circulation. 1996 Dec 15; 94(12):3083-6.
									</span>
								</li>
								<li>
									<span>4.</span>
									<span class="txt">
										Anti-invasive activity of ginsenoside Rh1 and Rh2 in the HT1080 cells. J. Ginseng Res. 22: 216-221 (1998)
									</span>
								</li>
								<li>
									<span>5.</span>
									<span class="txt">
										Pharmacological properties of a new aziridinylbenzoquinone, RH1 (2,5-diaziridinyl-3-(hydroxymethyl)-6-methyl-1,4-benzoquinone), in mice - cytochrome b5 reductase in human tumour cells. Biochemical Pharmacology, Volume 59,?Number 7, 1 April 2000, pp. 831-837(7)
									</span>
								</li>
								<li>
									<span>6.</span>
									<span class="txt">
										A ginsenoside-Rh1, a component of ginseng saponin, activates estrogen receptor in human breast carcinoma MCF-7 cells. J. Steroid Biochem Mol Biol. 2003 Mar; 84(4):463-8.
									</span>
								</li>
								<li>
									<span>7.</span>
									<span class="txt">
										Ginsenoside Rh1 possesses antiallergic and anti-inflammatory activities. Int. Arch. Allergy Immunol. 133: 113-120 (2004)
									</span>
								</li>
								<li>
									<span>8.</span>
									<span class="txt">
										RH1 Induces Cellular Damage in an NAD(P)H:Quinone. Oxidoreductase 1-Dependent Manner: Relationship between DNA Cross-linking, Cell Cycle Perturbations, and Apoptosis THE JOURNAL OF PHARMACOLOGY AND EXPERIMENTAL THERAPEUTICS, Vol. 313, No. 2
									</span>
								</li>
								<li>
									<span>9.</span>
									<span class="txt">
										Isolation of Ginsenoside Rh1 and Compound K from Fermented Ginseng and Efficacy Assessment on Systemic Anaphylactic Shock. Food Sci.Biotechnol.Vol.17,No.4,pp.000~000 (2008)
									</span>
								</li>
								<li>
									<span>10.</span>
									<span class="txt">
										Oral administration of ginsenoside Rh1 inhibits the development of atopic dermatitis-like skin lesions induced by oxazolone in hairless mice International Immunopharmacology-02210; No of Pages 8 (2010)
									</span>
								</li>
							</ol>						
						</div>
						
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->