<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/ch/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1.png" /></div>
								<h4>发酵人参</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3_on.png" /></div>
								<h4>BIFIDO的竞争优势</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>专利文献</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
					
					<div class="fermented_list">
						<div class="list_page">
							<h3>BIFIDO ACTIVE G5</h3>
							
							<div class="line2"></div>
							
							<div class="g5_list">
								<ul class="blind">
									<li>Support the Immune System</li>
									<li>Enhance Physical Energy</li>
									<li>Bodily Stamina and Fatigue Resistance</li>
									<li>Support Memory Functions</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img1_ch.png" />
							</div>

							<div class="g5_list_2">
								<ul class="blind">
									<li>GINSENG</li>
									<li>FERMENTED GINSENG</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img2_ch.png" /><br /><br />
								<p>
									通过发酵人参，含糖基的人身皂苷转化为无糖基的人参皂苷。 
									<br /><br />
									换一句话说，人参被双歧杆菌分解成小分子的人参皂苷元。发酵人参含有高浓度的Compound K, Rh1, Rh2, Rg5, Rk1等多种人参皂苷代谢产物，不仅能提高人体的吸收率，还可以提高其药理效果。
								</p><br />
								<h4>对比发酵人参 ACTIVE G5与人参提取液</h4><br />
								<img class="m_img" src="/assets/images/raw_material/g5_img3_ch.png" /> 
							</div>
							
							<div class="line2 mt40"></div>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->