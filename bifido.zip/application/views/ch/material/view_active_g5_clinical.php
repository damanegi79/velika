<script type="text/javascript">

$(function ()
{
	
	$(".tab_pannel.tab1").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/ch/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});	

	$(".tab_pannel.tab2").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		$(".list_page p").css({display:"none"});
		$(".list_page .list"+(idx+1)).css({display:"block"});
	});		
	
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel tab1" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">CLINICAL TRIAL</a></li>
						<li><a href="javascript:">RH1</a></li>
						<li><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li><a href="javascript:">COMPOUND K</a></li>
						<?Php else: ?>
							<li><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				
				<!-- main_title -->
				<div class="main_title">
					<h4>ACTIVE G5</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="clinical_list">
						<div class="clinical_img">
							<img src="/assets/images/raw_material/clinical_img.png" />
						</div>
						<p class="title">
							通过发酵人参，人参皂苷的糖基部分转化成非糖基部分，换一句话说，人参被双歧杆菌分解成小分子的人参皂苷元。发酵人参含有高浓度的Compound K, Rh1, Rh2, Rg5, Rk1等多种人参皂苷代谢产物，不仅能提高人体的吸收率，还可以提高其药理效果。
						</p>	
						<!-- tab_pannel -->
						<div class="tab_pannel tab2">
							<ul>
								<li class="on"><a href="javascript:">研究目的</a></li>
								<li><a href="javascript:">研究方法</a></li>
								<li><a href="javascript:">研究结果</a></li>
								<li><a href="javascript:">研究结论</a></li>
							</ul>
						</div>
						<!-- tab_pannel -->
						
						<!-- list_page -->
						<div class="list_page">
							<p class="list1">
								过敏性鼻炎在临床上定义为鼻腔粘膜暴露在过敏性抗原中, 出现以IgE为媒介的鼻腔障碍。多数研究报告提到人参和发酵红参具有抗炎作用, 特别是对Th2类型的炎症有效。本文研究目的在于评价发酵红参对过敏性鼻炎的治疗效果。
							</p>
							<p class="list2" style="display:none">
								维持四周的双盲安慰剂对照试验中, 59名慢性过敏性鼻炎患者随机分成两组：服用发酵红参组（实验组）和服用安慰剂组（对照组）。实验中，主要功效变量是鼻部症状总分（Total Nasal Symptom Score, TNSS）, 包括鼻漏、喷嚏、瘙痒、鼻塞；次要功效变量包括鼻炎生活质量（Rhinitis Quality of Life, RQol）评分和通过皮肤点刺试验（skin prick test）检测的皮肤对吸入性过敏原的作用。
							</p>
							<p class="list3" style="display:none">
								从第一到第四周的实验中, 实验组和对照组对于TNSS分数和TNSS持续分数方面无显著性差异。首先, 鼻塞症状方面, 安慰剂没有引起任何变化, 而发酵红参则显著性有效（P<0.005）；其次, RQoL方面, 服用发酵红参组得到显著提高, 而安慰剂组无任何变化（P<0.05）；最后, 发酵红参降低皮肤对慢性过敏原的反应性（P<0.05）。发酵红参具有良好的耐受性。 
							</p>
							<p class="list4" style="display:none">
								发酵红参能够有效改善慢性过敏性鼻炎患者的鼻塞症状和生活质量。 
							</p>
						</div>
						<!-- list_page -->
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->