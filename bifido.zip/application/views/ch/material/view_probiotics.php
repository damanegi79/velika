<script type="text/javascript">

$(function ()
{
	$(".intro_list").each(function ( i )
	{
		var left = $(".probiotics").width()*i;
		$(this).css({left:left});
	});

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		var left = -$(".probiotics").width()*idx;
		TweenMax.to($(".intro_con .list_set"), 1, {x:left, ease:Expo.easeInOut});
	});
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>PROBIOTICS WE PRODUCE</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics -->
				<div class="probiotics">
				
					<!-- "produce_con" -->
					<div class="produce_con">
						<ul>
							<li class="l">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img1.png" /></div>
								<p class="title">B.bifidum <strong>BGN4</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img2.png" /></div>
								<p class="title">B.longum <strong>BORI</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img3.png" /></div>
								<p class="title">B.lactis <strong>AD011</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img4.png" /></div>
								<p class="title">B.lactis <strong>AS60</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img5.png" /></div>
								<p class="title">B.infantis <strong>BH07</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img6.png" /></div>
								<p class="title">L.acidophilus <strong>AD031</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img7.png" /></div>
								<p class="title">L.paracasei <strong>BH08</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img8.png" /></div>
								<p class="title">L.plantarum <strong>BH02</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img9.png" /></div>
								<p class="title">L.casei <strong>IBS041</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img10.png" /></div>
								<p class="title">L.fermentum <strong>BH03</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img11.png" /></div>
								<p class="title">L.rhamnosus <strong>BH09</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img12.png" /></div>
								<p class="title">L.bulgaricus <strong>BH04</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img13.png" /></div>
								<p class="title">L.lactis <strong>BH10</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img14.png" /></div>
								<p class="title">S.thermophilus <strong>BH05</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img15.png" /></div>
								<p class="title">E.faecium <strong>BH06</strong></p>
							</li>
						</ul>
					</div>
					<!-- //"produce_con" -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>SERVICE INTRODUCTION</h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						<strong>Different form and concentration of products we can provide.</strong><FERMENTATION LMW (Low Molecular Weight) />
						BIFIDO can offer powder , stick , capsule and tablet dosage forms according to customer’s requirement. Each form can be packed as<br />
						raw materials, bulk capsule and tablet with PTP packing and finished product with bottle or box packing.
					</div>
					<!-- //sub_title -->
					
					<!-- tab_pannel -->
					<div class=tab_pannel>
						<ul>
							<li class="on"><a href="javascript:">POWDER</a></li>
							<li><a href="javascript:">STICK</a></li>
							<li><a href="javascript:">CAPSULE</a></li>
							<li><a href="javascript:">TABLET</a></li>
						</ul>
					</div>
					<!-- //tab_pannel -->
					
					<!-- intro_con" -->
					<div class="intro_con">
						<!-- list_set" -->
						<div class="list_set">
							<!-- powder" -->
							<div class="intro_list powder">
								<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img.png" /></div>
								<div class="txt_con">
									<h4>Powder Form</h4>
									<p>
										Through centrifuge and freeze-drying process, the<br />
										stability of probiotics culture was increased.<br />
										By diluting the original powder with special<br />
										excipient, stability of probiotics powder<br />
										is increased.
									</p>
									<p>
										Quality assurance system is important to keep the<br />
										good quality of BIFIDO powder form product.<br />
										Appearance, moisture, water activity, excipient, color,<br />
										flavor etc. are monitored strictly by BIFIDO Quality Control Team.
									</p>
									<p>
										Bulk probiotics powder can be applied into the production of finished product<br />
										with other ingredients such as prebiotics according to customer’s requirement.
									</p>
								</div>
							</div>
							<!-- //powder -->
							<!-- stick" -->
							<div class="intro_list stick">
								<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img.png" /></div>
								<div class="txt_con">
									<h4>Stick Form</h4>
									<p>
										We offer the service of stick packing with injection of<br />
										nitrogen gas to keep the concentration of probiotics<br />
										contained in the product. By our auto-production<br />
										line, different size of stick probiotics products can<br />
										be produced. In secondary packing, <br />
										we add desiccant to double protect product from<br />
										any environmental hazard factor.
									</p>
									<p>
										To decrease the heat effect during sealing the stick,<br />
										we use a caulking gun and seal up sticks by sonication.
									</p>
								</div>
							</div>
							<!-- //stick" -->
							<!-- capsule" -->
							<div class="intro_list capsule">
								<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img.png" /></div>
								<div class="txt_con">
									<h4>Capsule Form</h4>
									<p>
										Capsule form can keep probiotics away from oxygen<br />
										to increase the stability. BIFIDO <a href="javascript:openModalPopup('/en/popup/material_enteral');">enteral-coating<br />
										technique<span class="link"></span></a> will increase the survival rate of<br />
										probiotics in the digestive tract.
									</p>
									<div class="list">
										<dl>
											<dt style="width:130px">· Capsule  Materials :</dt>
											<dd>Gelatin, HPMC, HPMCP</dd>
										</dl>
										<dl>
											<dt style="width:130px">· Capsule Size :</dt>
											<dd>0 / 1</dd>
										</dl>
									</div>
									<div class="list">
										<dl>
											<dt style="width:110px">· <strong>Advantage  :</strong></dt>
											<dd>Easy to carry and take.</dd>
										</dl>
										<dl>
											<dt style="width:110px">· <strong>Disadvantage :</strong></dt>
											<dd>Prebiotics acts as a growth factor of probiotics is needed.<br />
	                           					The amount of prebiotics added in a capsule is limited. </dd>
										</dl>
									</div>
								</div>
							</div>
							<!-- //capsule -->
							<!-- tablet" -->
							<div class="intro_list tablet">
								<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img.png" /></div>
								<div class="txt_con">
									<h4>Tablet Form</h4>
									<p>
										BIFIDO <a href="javascript:openModalPopup('/en/popup/material_tablet');">small tablet technique</a><span class="link_icon"></span>can not only keep the activity of probiotics,<br />
										but also decrease the quantities of binders.<br />
										<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2.png" />
									</p>
								</div>
							</div>
							<!-- //tablet -->
						</div>
						<!-- //list_set" -->
					</div>
					<!-- //intro_con" -->
					
					<!-- main_title -->
					<div class="main_title">
						<p>MAIN COMPETITIVENESS OF OUR PRODUCTS</p>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- product_con -->
					<div class="product_con">
						<div class="product_list">
							<ul>
								<li style="top:30px;left:20px">
									<h4>HUMAN-ORIGIN</h4>
									<p>
										Human-origin probiotics is much easier to adhere<br />
										to the villi and grow in the intestine tract<br />
										indicated by <a href="#">clinical study</a><span class="link"></span>.
									</p>
								</li>
								<li style="top:30px;right:20px;text-align:right">
									<h4>
										WELL-DOCUMENTED RESEARCH<br />
										PAPERS AND PATENTS
									</h4>
									<p>
										· 26 patents<br />
										· More than 100 research papers <br />on lactiacid bacteria. 
									</p>
								</li>
								<li style="bottom:30px;left:20px">
									<h4>PROFESSION ON BIFIDUS</h4>
									<p>
										We are professional on the study and<br />
										cultivation of probiotics, especially for<br />
										anaerobic human-origin Bifidobacterium sp.
									</p>
								</li>
								<li style="bottom:30px;right:20px;text-align:right">
									<h4>PROFESSION ON BIFIDUS</h4>
									<p>
										· Without the worry of potential risk of<br />
										  unbeneficial DNA conjugation caused by animal.<br />
										· origin probiotics
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">See more details</span>
							<a href="/en/story">BIFIDUS STORY<span class="icon"></span></a>
						</div>
					</div>
					<!-- //product_con -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>DOCUMENT SERVICE <span>(RESEARCH PAPERS, PATENTS OR CERTI)</span></h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						BIFIDO has rich experiences on the study of lactic acid bacteria. We can provide.
					</div>
					<!-- //sub_title -->
					
					<!-- "service_con" -->
					<div class="service_con">
						<div class="service_list">
							<ul>
								<li class="blind">
									<h4>COMPANY</h4>
									<ul>
										<li>GMP certificate</li>
									</ul>
								</li>
								<li class="blind">
									<h4>STRAINS</h4>
									<ul>
										<li>Halal certi clinical</li>
										<li>Studies stability data</li>
										<li>Etc.</li>
									</ul>
								</li>
								<li class="blind">
									<h4>DOCUMENTS FOR REGISTRATION</h4>
									<ul>
										<li>Certificate of free sales</li>
										<li>Certificate of analysis</li>
										<li>Health certificate</li>
										<li>Certificate of origin</li>
										<li>Etc.</li>
									</ul>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">See more details</span>
							<a href="/en/about/download/brochure">DOWNLOAD<span class="icon"></span></a>
						</div>
					</div>
					<!-- //"service_con" -->
					
					
					
				</div>
				<!-- //probiotics -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->