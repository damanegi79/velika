
<script type="text/javascript">

$(function ()
{
	var linkAr = ["b_lactis_as60", "pai_probiotics", "gnl_probiotics"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx = $(e.target).index();
		location.href = "/ch/material/probiotics/gut_health?category="+linkAr[idx];
	});
	
});


</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">B.LACTIS AS60</a></li>
						<li><a href="javascript:">PAI 益生菌</a></li>
						<li><a href="javascript:">GNL 益生菌</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- main_title -->
				<div class="main_title">
					<label>益生菌</label>
					<h4>B. LACTIS AS60</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					<i>Bifidobacterium lactis</i> AS60
				</div>
				<!-- //sub_title -->
				<!-- probiotics_sub -->
				<div class="probiotics_sub">
				
					<!-- con_info -->
					<div class="con_info">
						
						<div class="top_img_con">
							<img class="m_img" src="/assets/images/raw_material/cut_health_top_b_laactis_as60.png" />
						</div>
						
						<h4 class="sub_title">论文</h4>
						
						<div class="sub_txt">
							<a href="#">Bifidobacterium animalis BF8(KFCC1150P) against pathogenic Enterobacter(Cronobacter) sakazaki and food domposition therefrom<span class="link"></span></a>
						</div>
						
						<h4 class="sub_title">阪崎肠杆菌</h4>
						
						<div class="sub_txt">
							阪崎肠杆菌（Enterobacter sakazaki)是一种革兰氏阴性杆状病原性菌， 而被婴儿奶粉中阪崎肠杆菌感染的儿童死亡率高达40%-80%。它是导致肠炎，脑膜炎，髓膜炎发病的一种高危菌种，一些菌株在干燥状态下可生存两年以上。
						</div>
						
						
						<div class="effect_con">
							<div class="img_con"><img class="m_img" src="/assets/images/raw_material/cut_health_b_laactis_as60_ch.png" /></div>
						</div>
						
					</div>
					<!-- //con_info -->	
				</div>
				<!-- //probiotics_sub -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->