
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content customer">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>BIFIDUS WEBTOON</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- top_search_con -->
				<div class="top_search_con">
					<form id="search_form" method="GET">
						<input id="search_txt" name="search" type="text">
						<button type="submit"><img src="/assets/images/common/search_icon.png" /><span class="ml10">SEARCH</span></button>
					</form>
				</div>
				<!-- //top_search_con -->
				<!-- webtoon -->
				<div class="webtoon">
					<div class="webtoon_list">

					</div>
				</div>
				<!-- //webtoon -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->