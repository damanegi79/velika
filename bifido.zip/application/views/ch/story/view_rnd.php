
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content story">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>核心技术</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- story_con -->
				<div class="story_con">
					<div class="core_con">
						<h3>核心技术</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set">
								<img class="m_img" src="/assets/images/bifidus_story/rnd_img1_ch.png" />
							</div>
						</div>
					</div>
				</div>
				<!-- //story_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->