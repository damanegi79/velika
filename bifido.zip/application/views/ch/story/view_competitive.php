<script type="text/javascript">

$(function ()
{
	

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx = $(e.target).index();
		$(".competitive_list .list_con").css({display:"none"});
		$(".competitive_list .list_con"+(idx+1)).css({display:"block"});
		$(window).resize();
	});

	setSlider($(".list_con1"));
	setSlider($(".list_con3"));
	
	

	$(window).resize(function ()
	{
		$(".list_con1 .list_target").css({height:$(".list_con1 .list_target .rol_li").height()});
		$(".list_con3 .list_target").css({height:$(".list_con3 .list_target .rol_li").height()});
		
	});
	$(window).resize();
	
});

function setSlider( target )
{
	var slider = new Slider(target.find(".list_target"), 
	{
		animationType:Slider.TRANSLATE_X, 
		changeFunc:sliderChange,
		autoSize:true,
		cycle:true
	});
	changePager(0);

	target.find(".arrow_con").find("a").bind("click", function ( e )
	{
		if($(e.currentTarget).is(".prev"))
		{
			slider.changePage(slider.currentNum-1);
		}
		else
		{
			slider.changePage(slider.currentNum+1);
		}
	});
	
	target.find(".pager_con").find("a").bind("click", function ( e )
	{
		sliderChange($(this).index());
		slider.changePage($(this).index());
	});

	function sliderChange( idx )
	{
		changePager(idx);
	}

	function changePager(idx)
	{
		target.find(".pager_con").find("a").removeClass("on");
		target.find(".pager_con").find("a").find(".on").css({"visibility":"hidden"});
		var on = target.find(".pager_con").find("a").find(".on").eq(idx);
		on.css({"visibility":"visible"});
		on.parent().addClass("on");
	}
}

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content story">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>竞争优势</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- story_con -->
				<div class="story_con">
					<div class="lis_con">
						<img class="m_img" src="/assets/images/bifidus_story/competitive_img1_ch.png" />
					</div>
					<div class="lis_con">
						<img class="m_img" src="/assets/images/bifidus_story/competitive_img2_ch.png" />
					</div>
					<div class="lis_con">
						<img class="m_img" src="/assets/images/bifidus_story/competitive_img3_ch.png" />
						<div class="competitive_list">
							<!-- tab_pannel -->
							<div class=tab_pannel>
								<ul>
									<li class="on"><a href="javascript:">BGN4</a></li>
									<li><a href="javascript:">BORI</a></li>
									<li><a href="javascript:">专利</a></li>
								</ul>
							</div>
							<!-- tab_pannel -->
							<!-- list_set -->
							<div class=list_set>
								
								<!-- list_con1 -->
								<div class="list_con list_con1">
									<div class="list_target">
										<div class="rol_target">
											<ul class="rol_ul">
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_bgn4_img1_ch.png" /></li>
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_bgn4_img2_ch.png" /></li>
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_bgn4_img3_ch.png" /></li>
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_bgn4_img4_ch.png" /></li>
											</ul>
										</div>
									</div>
									
									<div class="pager_con">
										<a href="javascript:"><span class="emt on">1</span></a>
										<a href="javascript:"><span class="emt on">2</span></a>
										<a href="javascript:"><span class="emt on">3</span></a>
										<a href="javascript:"><span class="emt on">4</span></a>
									</div>
									
									<div class="arrow_con">
										<a href="javascript:" class="prev emt">이전</a>
										<a href="javascript:" class="next emt">다음</a>
									</div>
									
								</div>
								<!-- //list_con1 -->
								
								<!-- list_con2 -->
								<div class="list_con list_con2" style="display:none">
									<img class="m_img" src="/assets/images/bifidus_story/comming_img.png" alt="comming soon!" />
								</div>
								<!-- //list_con2 -->
								
								<!-- list_con3 -->
								<div class="list_con list_con3" style="display:none">
									<div class="list_target">
										<div class="rol_target">
											<ul class="rol_ul">
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_patent_img1.png" /></li>
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_patent_img2.png" /></li>
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_patent_img3.png" /></li>
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_patent_img4.png" /></li>
												<li class="rol_li"><img class="m_img" src="/assets/images/bifidus_story/compe_patent_img5.png" /></li>
											</ul>
										</div>
									</div>
									
									<div class="pager_con">
										<a href="javascript:"><span class="emt on">1</span></a>
										<a href="javascript:"><span class="emt on">2</span></a>
										<a href="javascript:"><span class="emt on">3</span></a>
										<a href="javascript:"><span class="emt on">4</span></a>
										<a href="javascript:"><span class="emt on">5</span></a>
									</div>
									
									<div class="arrow_con">
										<a href="javascript:" class="prev emt">이전</a>
										<a href="javascript:" class="next emt">다음</a>
									</div>
								</div>
								<!-- //list_con3 -->
								
							</div>
							<!-- list_set -->
						</div>
					</div>
					<div class="lis_con">
						<img class="m_img" src="/assets/images/bifidus_story/competitive_img4_ch.png" />
					</div>
				</div>
				<!-- //story_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->