
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content story">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>益生菌&双歧杆菌</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- story_con -->
				<div class="story_con">
					<div class="probio_con">
						<h3>关于益生菌</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set">
								<div class="blind">
									<h4>Benefits of Probiotics</h4>
									<ul>
										<li>Inhibit bad bacteria and Increase good bacteria</li>
										<li>Boost immune system</li>
										<li>Help with constipation</li>
									</ul>
								</div>
								<img class="m_img" src="/assets/images/bifidus_story/probiotic_img2_ch.png" />
							</div>
						</div>
					</div>
				</div>
				<div class="story_con">
					<div class="probio_con">
						<h3>为了肠道健康，摄取双岐杆菌</h3>
						<div class="list_con2">
							<div class="list_set">
								<div class="blind">
									<h4>BRISTOL STOOL CHART</h4>
									<ul>
										<li>Type 1.  Separate hard lumps, like nuts </li>
										<li>Type 2.  Sausage-shaped but lumpy</li>
										<li>Type 3.  Like sausage but with cracks on the surface</li>
										<li>Type 4.  Like a sausage or snake smooth and soft</li>
										<li>Type 5.  Soft blobs with clear-cut edges</li>
										<li>Type 6.  Fluffy pieces with ragged edges, a mushy stool</li>
										<li>Type 7.  Watery, no solid pieces Entirely Liquid</li>
	
									</ul>
								</div>
								<img class="m_img" src="/assets/images/bifidus_story/probiotic_img3_ch.png" />
							</div>
						</div>
					</div>
				</div>
				<div class="story_con no_mobile">
					<div class="probio_con">
						<h3>教育视频</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set">
								<img src="/assets/images/bifidus_story/comming_img2.png" />
							</div>
						</div>
					</div>
					<!-- 
					<div class="probio_con">
						<iframe allowfullscreen="" data-thumbnail-src="https://i.ytimg.com/s_vi/xC7hSuKVyYI/default.jpg?sqp=S3sdRv5G8Do&amp;rs=AOn4CLBcYa3LJ6wYcHfnnK8TeeduQFuNUg" frameborder="0" width="100%" height="660px" src="https://www.youtube.com/embed/S3sdRv5G8Do?feature=player_embedded&amp;wmode=opaque" ></iframe>
					</div>
					 -->
				</div>
				<!-- //story_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->