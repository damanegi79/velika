<?php
	$gnb = getMainTitle();
	$all_menu = getSubTitle();
	$titleAr = lang('gnb');
	$titleAr2 = lang('menu_all');
	$title1 = str_replace(' ', '_', strtolower($gnb[$depth1]['title']));
	$title2 = strtoupper($all_menu[$depth1][$depth2][0]['title']);
	$title3 = strtoupper($all_menu[$depth1][$depth2][$depth3+1]['title']);
	$tit1 = str_replace(' ', '_', strtolower($titleAr[$depth1]['title']));
	$tit2 = strtoupper($titleAr2[$depth1][$depth2][0]['title']);
	$tit3 = strtoupper($titleAr2[$depth1][$depth2][$depth3+1]['title']);

?>

<script type="text/javascript">

$(function ()
{
	var tabIdx = $(".tab_menu_con li.on").index();
	var timer;
	
	
	
	TweenMax.to($(".tab_menu_con li .over"), 0, {opacity:0});
	TweenMax.to($(".tab_menu_con li.on .over"), 0.6, {opacity:1});


	$(".sub_header .btn_con a").css({opacity:0.6});
	$(".sub_header .btn_con a").bind("mouseover", function ( e )
	{
		var tar = $(e.currentTarget);
		TweenMax.to(tar, 0.2, {opacity:1});
	});

	$(".sub_header .btn_con a").bind("mouseout", function ( e )
	{
		var tar = $(e.currentTarget);
		TweenMax.to(tar, 0.2, {opacity:0.6});
	});
	
	$(".tab_menu_con li").bind("mouseenter", function ( e )
	{
		$(".tab_menu_con li a").css({"color":"#7f8489"});
		$(this).find("a").css({"color":"#fff"});
		TweenMax.to($(".tab_menu_con li .over"), 0, {opacity:0});	
		TweenMax.to($(this).find(".over"), 0.6, {opacity:1});
		clearTimeout(timer);
	});

	$(".tab_menu_con li").bind("mouseleave", function ( e )
	{
		timer = setTimeout(function ()
		{
			$(".tab_menu_con li a").css({"color":"#7f8489"});
			$(".tab_menu_con li.on a").css({"color":"#fff"});
			TweenMax.to($(".tab_menu_con li .over"), 0.6, {opacity:0});	
			TweenMax.to($(".tab_menu_con li.on .over"), 0.6, {opacity:1});
		}, 300);
	});

	$(window).resize( function ( e )
	{
		if(!isMobile)
		{
			var ww = $(window).width();
			if(ww<1000) ww = 1000;
			$(".sub_header .bg_con img").css({left:0, width:ww, height:"auto"});
			if($(".sub_header .bg_con img").height()<$(".sub_header .bg_con").height())
			{
				$(".sub_header .bg_con img").css({width:"auto", height:$(".sub_header .bg_con").height()});
				$(".sub_header .bg_con img").css({left:-($(".sub_header .bg_con img").width()-$(window).width())/2});
			}
			$(".sub_header").css({height:""});
			
			if($(".sub_header .title_con h2").find("span").html())
			{
				$(".sub_header .title_con h2").css({"line-height":"40px"});
			}
			
			$(".sub_header .title_con h2").css({"margin-top":-$(".sub_header .title_con h2").height()/2});
		}
		else
		{
			$(".sub_header .bg_con img").css({left:0, width:"", height:""});
			$(".sub_header").css({height:$(".sub_header .bg_con img").height()+50});
			if($(".sub_header .title_con h2").find("span").html())
			{
				$(".sub_header .title_con h2").css({"line-height":"25px"});
			}
			
			$(".sub_header .title_con h2").css({"margin-top":-($(".sub_header .title_con h2").height()/2)});
			
		}

		Utils.tabSizing($(".tab_menu_con li"), $(".tab_menu_con").width(), 0);
		
	});
	
	$(window).resize();

	$(window).load(function ( e )
	{
		$(window).resize();
	});

	$(".sub_header .bg_con img").bind("load", function ( e )
	{
		$(window).resize();
	});

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$("body").unmousewheel(mouseweelFn);
		}
		else
		{
			$("body").mousewheel(mouseweelFn);
		}
		windowScroll();
	});

	

	
});

</script>
		
<!-- sub_header -->
<section class="sub_header <?= $title1 ?>">
	
	<!-- bg_con -->
	<div class="bg_con">
		<img class="m_img" src="/assets/images/<?= $title1 ?>/<?= str_replace(" ", "_", strtolower($title2)) ?>/top_bg_<?= $depth3 ?>.png" />
	</div>
	<!-- //bg_con -->
	<!-- sub_header_con -->
	<div class="sub_header_con">
	
		<!-- title_con -->
		<div class="title_con">
			<h2>
				<?php
					if($this->languege == "en")
					{
						if(strtolower($title1) == "raw_material")
						{
							if(strtolower($title3) == "raw material")       echo 'PROBIOTICS<br /> RAW MATERIALS';
							else if(strtolower($title3) == "immunity")      echo $title3.' HEALTH<br /><span>Begins With ACTIVE 5</span>';
							else if(strtolower($title3) == "gut health")    echo $title3.'<br /><span>Begins With ZIGUNUK BIFIDUS</span>';
							else if(strtolower($title3) == "woman health")  echo $title3.'<br /><span>Begins With Woman-specific Probiotics</span>';
							else if(strtolower($title3) == "ginseng story") echo 'FERMENTED<br />'.$title3;
							else if(strtolower($title3) == "active g5")     echo $title3.'<br /><span>Fermetned Ginseng raw materials</span>';
						}
						else if(strtolower($title1) == "product")
						{
							if(strtolower($title2) == "probiotics")         echo $title2.' '.strtoupper($title1);
							if(strtolower($title2) == "fermented ginseng")         echo $title2.'<br />'.strtoupper($title1);
						}
						else 
						{
							echo $tit2;
						}
					}
					else if($this->languege == "ch")
					{
						if(strtolower($title1) == "raw_material")
						{
							if(strtolower($title3) == "raw material")       echo '益生菌原料';
							else if(strtolower($title3) == "immunity")      echo '免疫健康<br /><span>由五种活性人参皂苷开启</span>';
							else if(strtolower($title3) == "gut health")    echo '肠道健康<br /><span>由池根亿双歧杆菌开启</span>';
							else if(strtolower($title3) == "woman health")  echo '女性健康<br /><span>由女性专用益生菌开启</span>';
							else if(strtolower($title3) == "ginseng story") echo '发酵人参的故事';
							else if(strtolower($title3) == "active g5")     echo $title3;
						}
						else if(strtolower($title1) == "product")
						{
							if(strtolower($title2) == "probiotics")         echo '益生菌产品';
							if(strtolower($title2) == "fermented ginseng")  echo '发酵红参产品';
						}
						else 
						{
							echo $tit1;
						}
					}
					else if($this->languege == "kr")
					{
						if(strtolower($title1) == "raw_material")
						{
							if(strtolower($title3) == "raw material")       echo '원료';
							else if(strtolower($title3) == "immunity")      echo $title3.' HEALTH<br /><span>Begins With ACTIVE 5</span>';
							else if(strtolower($title3) == "gut health")    echo $title3.'<br /><span>Begins With ZIGUNUK BIFIDUS</span>';
							else if(strtolower($title3) == "woman health")  echo $title3.'<br /><span>Probiotics Woman</span>';
							else if(strtolower($title3) == "ginseng story") echo '발효인삼 이야기';
							else if(strtolower($title3) == "active g5")     echo $title3.'<br /><span>Fermetned Ginseng raw materials</span>';
						}
						else if(strtolower($title1) == "product")
						{
							if(strtolower($title2) == "probiotics")         echo '프로바이오틱스 제품';
							if(strtolower($title2) == "fermented ginseng")  echo '발효 인삼 제품';
						}
						else 
						{
							echo $tit2;
						}
					}
					else if($this->languege == "vn")
					{
						if(strtolower($title1) == "raw_material")
						{
							if(strtolower($title3) == "raw material")       echo 'NGUYÊN LIỆU THÔ';
							else if(strtolower($title3) == "immunity")      echo 'Sức khỏe hệ miễn dịch<br /><span>bắt đầu bằng active 5</span>';
							else if(strtolower($title3) == "gut health")    echo 'SỨC KHỎE CỦA RUỘT<br /><span>Sức khỏe đường ruột bắt đầu bằng ZIGUNUK bifidus</span>';
							else if(strtolower($title3) == "woman health")  echo 'SỨC KHỎE PHỤ NỮ<br /><span>Probiotics Woman</span>';
							else if(strtolower($title3) == "ginseng story") echo 'CÂU CHUYỆN CỦA NHÂN SÂM';
							else if(strtolower($title3) == "active g5")     echo $title3.'<br /><span>Bắt đầu Bằng Probiotics Dành riêng cho Phụ nữ</span>';
						}
						else if(strtolower($title1) == "product")
						{
							if(strtolower($title2) == "probiotics")         echo 'SẢN PHẨM PROBIOTICS';
							if(strtolower($title2) == "fermented ginseng")  echo 'NHÂN SÂM LÊN MEN';
						}
						else 
						{
							echo $tit2;
						}
					}
				?>
			</h2>
		</div>
		<!-- /title_con -->
		
		<!-- tab_menu_con -->
		<div class="tab_menu_con">
			<ul>
				<?php 

					$menu_all = lang('menu_all');
					$menuList = $menu_all[$depth1];

					for($i=0; $i<count($menuList); $i++)
					{
						$lists = $menuList[$i];
						for($j=1; $j<count($lists); $j++)
						{
							$tit = strtoupper($lists[$j]['title']);
							$link = $lists[$j]['link'];
							
							if($i == $depth2)
							{	
								if($lists[0]['title'] == $title3)
								{
									$idx1 = $i;
									$idx2 = -1;
									echo '<li><span class="over"></span><a href="'.$link.'">'.$tit.'</a></li>';
								}
								else 
								{
									if($tit == $tit3)
									{
										$idx1 = $i;
										$idx2 = $j;
										if(strpos($link, 'www') !== false)
										{
											echo '<li class="on"><span class="over"></span><a href="'.$link.'" target="_blank">'.$tit.'</a></li>';
										}
										else 
										{
											echo '<li class="on"><span class="over"></span><a href="'.$link.'">'.$tit.'</a></li>';
										}
									}
									else
									{
										if(strpos($link, 'www') !== false)
										{
											echo '<li><span class="over"></span><a href="'.$link.'" target="_blank">'.$tit.'</a></li>';
										}
										else 
										{
											echo '<li><span class="over"></span><a href="'.$link.'">'.$tit.'</a></li>';
										}
									}
								}
							}
							
						}
					}

					
					$len1 = count($menuList);
					$len2 = count($menuList[$idx1])-1;
					$next = isset($menuList[$idx1][$idx2+1]['link']) ? $menuList[$idx1][$idx2+1]['link'] : ""; 
					$prev = isset($menuList[$idx1][$idx2-1]['link']) ? $menuList[$idx1][$idx2-1]['link'] : "";
					
					if($idx1 == $len1-1)
					{
						if($len1 == 1)
						{
							if($idx2 == $len2)  $next = "";
							else if($idx2 == 1)	$prev = "";
						}
						else 
						{
							if($idx2 == $len2)  $next = "";
							else if($idx2 == 1)	$prev = $menuList[$idx1-1][count($menuList[$idx1-1])-1]['link'];
						}
						
					}
					else if($idx1 == 0)
					{
						if($len1 == 1)
						{
							if($idx2 == $len2)	$next = "";
							else if($idx2 == 1)	$prev = "";
						}
						else 
						{
							if($idx2 == $len2)	$next = $menuList[$idx1+1][1]['link'];
							else if($idx2 == 1)	$prev = "";
						}
					}
					else 
					{
						if($idx2 == $len2)	$next = $menuList[$idx1+1][1]['link'];
						else if($idx2 == 1)	$prev = $menuList[$idx1-1][count($menuList[$idx1-1])-1]['link'];
					}
				?>
				
			</ul>
		</div>	
		<!-- //tab_menu_con -->
		
		<!-- btn_con -->
		<div class="btn_con">
			<a class="prev emt" href="<?Php if($prev != ""){ echo $prev.'"'; } else {echo '" style="display:none';}?>" <?php if(strpos($next, 'www') !== false){ echo 'target="_blank"';}?>>이전</a>
			<a class="next emt" href="<?Php if($next != ""){ echo $next.'"'; } else {echo '" style="display:none';}?>" <?php if(strpos($next, 'www') !== false){ echo 'target="_blank"';}?>>다음</a>
		</div>
		<!-- /btn_con -->
		
	</div>
	<!-- //sub_header_con -->
</section>
<!-- //sub_header -->





