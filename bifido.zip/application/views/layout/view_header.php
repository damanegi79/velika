<!DOCTYPE html>
<html lang="<?Php if($this->languege =="kr"){ echo'ko'; }else if($this->languege =="ch"){ echo 'zh-hans'; }else if($this->languege =="vn"){ echo 'vi'; }else{ echo $this->languege;} ?>">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<META name="Description" content="프로바이오틱스(비피더스, 유산균), BGN4, BORI, 발효홍삼, 화장품, 비타민과 무기질 제품 소개">
<META name="Keywords" content="프로바이오틱스(비피더스, 유산균), BGN4, BORI, 발효홍삼, 화장품, 비타민과 무기질 제품 소개, 비피도, 프로지, 유산균과 먹이, BGN4, BORI, 지근억, 한국인맞춤유산균, 발효홍삼, 지근억비피더스, 프로g">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<meta name="naver-site-verification" content="c0d3b9e31d8b70966ebd039b5d02c4f8b5b1d315"/>
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/bifido.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
<script type="text/javascript">
var rootPath = "<?= base_url(); ?>";
</script>
</head>
<body>

<!-- header -->
<header id="header" <?Php if(!$this->uri->segment(2)){ echo 'class="fixed"';}?>>
	<!-- header_blind -->
	<div class="header_blind"></div>
	<!-- header_blind -->
	<!-- header_con -->
	<div class="header_con">
		<div class="main_menu">
			<div class="logo">
				<a href="/<?= $this->languege?>"><h1 class="blind"><?=lang('logo')?></h1></a>
			</div>
			<div class="gnb">
				<ul>
					<?php foreach (lang('gnb') as $list): ?>
					<li><a href="<?=$list['link']?>"><?= $list['title'] ?></a></li>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<div class="all_menu_con">
			<div class="menu_set">
				<?php foreach (lang('menu_all') as $depth1): ?>
				<div class="menu_con">
				<?php foreach ($depth1 as $depth2): ?>
				<ul>
				<?php $count = 0; ?>
				<?php foreach ($depth2 as $depth3): ?>
				
				<?php if($count == 0):?>
					<li><span><?=$depth3['title']?></span></li>
				<?php else:?>
					<li><a href="<?=$depth3['link']?>"><?=$depth3['title']?></a></li>
				<?php endif;?>
				
				<?php $count++; ?>
				
				<?php endforeach; ?>
				</ul>
				<?php endforeach; ?>
				</div>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
	
	<!-- header_con -->
	<!-- mobile_header -->
	<div class="mobile_header">
		<div class="menu_btn">
			<a href="javascript:"><img src="/assets/images/layout/m_menu.png" /></a>
		</div>
		<div class="logo">
			<a href="/<?= $this->languege?>"><img src="/assets/images/layout/m_logo.png" /></a>
		</div>
		<div class="lang_btn">
			<span>
				<?php
					if($this->uri->segment(1) == "en") echo 'EN';
					if($this->uri->segment(1) == "kr") echo 'KO';
					if($this->uri->segment(1) == "ch") echo 'CH';
					if($this->uri->segment(1) == "vn") echo 'VN';
				?>
			</span>
			<select id="lang_slt">
				<option value="en" <?Php if($this->uri->segment(1) == "en"){ echo 'selected'; }?>>EN</option>
				<option value="kr" <?Php if($this->uri->segment(1) == "kr"){ echo 'selected'; }?>>KO</option>
				<option value="ch" <?Php if($this->uri->segment(1) == "ch"){ echo 'selected'; }?>>CH</option>
				<option value="vn" <?Php if($this->uri->segment(1) == "vn"){ echo 'selected'; }?>>VN</option>
			</select>
		</div>
	</div>
	<!-- mobile_header -->
</header>
<!-- //header -->





