
<!-- footer -->
<footer id="footer">
	<!-- footer_con -->
	<div class="footer_con">
		
		<!-- footer_logo -->	
		<div class="footer_logo">
			<img src="/assets/images/layout/footer_logo.png">
		</div>
		<!-- //foot_logo -->
		
		<!-- copyright -->	
		<div class="copyright">
			<?Php if($this->languege == "en"):?>
			<address>
				<p><strong>BIFIDO Co. Ltd. </strong> 23-16 Nonggongdanji-gil, Hongcheon-eup, Hongcheon-gun, Gangwon-do 250-920, Republic of Korea</p>
				<p>
					<span>TEL : <a href="tel://82-33-435-4962">82-33-435-4962</a></span>
					<span>FAX : 82-33-435-4963</span>
					<span>E-mail :<a href="mailTo://bifidodata@gmail.com">bifidodata@gmail.com</a></span>
				</p>
				<p>Copyright ⓒ BIFIDO Co. Ltd. All right reserved.</p>
			</address>
			<?Php elseIf($this->languege == "ch"):?>
			<address>
				<p><strong>BIFIDO Co., Ltd. </strong> 韩国 江原道 洪川郡 洪川邑 农工团地路 23-16</p>
				<p>
					<span>电话 : <a href="tel://82-33-435-4962">82-33-435-4962</a></span>
					<span>传真 : 82-33-435-4963</span>
					<span>邮箱 :<a href="mailTo://bifidodata@gmail.com">bifidodata@gmail.com</a></span>
				</p>
				<p>Copyright ⓒ BIFIDO Co. Ltd. All right reserved.</p>
			</address>
			<?Php elseIf($this->languege == "kr"):?>
			<address>
				<p><strong>㈜비피도. </strong> 강원도 홍천군 홍천읍 농공단지길 23-16</p>
				<p>
					<span>TEL : <a href="tel://82-33-435-4962">82-33-435-4962</a></span>
					<span>FAX : 82-33-435-4963</span>
					<span>이메일 :<a href="mailTo://bifidodata@gmail.com">bifidodata@gmail.com</a></span>
				</p>
				<p>Copyright ⓒ BIFIDO Co. Ltd. All right reserved.</p>
			</address>	
			<?Php elseIf($this->languege == "vn"):?>
			<address>
				<p><strong>CÔNG TY TNHH BIFIDO. </strong> 23-16 Nonggongdanji-gil, Hongcheon-eup, Hongcheon-gun, Gangwon-do 250-920,<br /> Cộng hòa Hàn Quốc</p>
				<p>
					<span>SỐ ĐIỆN THOẠI : <a href="tel://82-33-435-4962">82-33-435-4962</a></span>
					<span>FAX : 82-33-435-4963</span>
					<span>E-mail :<a href="mailTo://bifidodata@gmail.com">bifidodata@gmail.com</a></span>
				</p>
				<p>Copyright ⓒ BIFIDO Co. Ltd. All right reserved.</p>
			</address>	
			<?Php endIf;?>
		</div>
		<!-- //copyright -->
		
		<!-- leng_menu -->	
		<div class="leng_menu">
			<ul>
				<li<?Php if($this->languege == "en"){ echo ' class="on"';}?>><a href="/en">EN</a></li>
				<li<?Php if($this->languege == "kr"){ echo ' class="on"';}?>><a href="/kr">KO</a></li>
				<li<?Php if($this->languege == "ch"){ echo ' class="on"';}?>><a href="/ch">CH</a></li>
				<li<?Php if($this->languege == "vn"){ echo ' class="on"';}?>><a href="/vn">VN</a></li>
			</ul>
		</div>
		<!-- //leng_menu -->
		
	</div>
	<!-- //footer_con -->
</footer>
<!-- //footer -->


<!-- blind_con -->
<div class="blind_con"></div>
<!-- //blind_con -->

<!-- loading_con -->
<div class="loading_con">
	<img src="/assets/images/common/loading.gif" />
</div>
<!-- //loading_con -->

<!-- modalPopup -->
<div class="modalPopupContainer">
	<div class="popupCon"></div>
</div>
<!-- //modalPopup -->

<!-- alert_mesage -->
<div class="alert_mesage">
	<div class="alert_mesage"></div>
</div>
<!-- //alert_mesage -->

<!-- datepicker -->
<div class="datepicker"></div>
<!-- //datepicker -->

<!-- mobile_gnb -->
<div class="mobile_gnb">
	<div class="gnb_wrap">
		<div class="gnb_title">
			<a class="logo" href="/<?= $this->languege?>"><img src="/assets/images/layout/m_gnb_logo.png" /></a>
			<a class="close" href="javascript:"><img src="/assets/images/layout/m_gnb_close.png" /></a>
		</div>
		<div class="gnb_menu">
			<div class="gnb_scroll" id="gnb_scroll">
				<ul class="main_ul">
					<?php $count = 0; ?>
					<?php foreach (lang('gnb') as $list): ?>
					<li class="main_li">
						<a class="main_btn" href="javascript:"><?= $list['title'] ?></a>
						<span class="arrow"><img src="/assets/images/layout/m_arrow.png" /></span>
						<div class="sub_con">
						<ul>
							<?php foreach (lang('menu_all')[$count] as $depth1): ?>
							<li><a href="<?= $depth1[0]['link'] ?>"><?=$depth1[0]['title']?></a></li>
							<?php endforeach; ?>	
						</ul>
						</div>
					</li>
					<?php $count++; ?>
					<?php endforeach; ?>
				</ul>
			</div>
		</div>
		<div class="gnb_bottom">
				<ul>
					<li<?Php if($this->languege == "en"){ echo ' class="on"';}?>><a href="/en">EN</a></li>
					<li<?Php if($this->languege == "kr"){ echo ' class="on"';}?>><a href="/kr">KO</a></li>
					<li<?Php if($this->languege == "ch"){ echo ' class="on"';}?>><a href="/ch">CH</a></li>
					<li<?Php if($this->languege == "vn"){ echo ' class="on"';}?>><a href="/vn">VN</a></li>
				</ul>
			</div>
	</div>
</div>
<!-- //mobile_gnb -->


</body>
</html>