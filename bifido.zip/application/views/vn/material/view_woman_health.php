<script type="text/javascript">


$(function ()

{
	
	$(".intro_list").each(function ( i )

	{
		
		var left = $(".probiotics").width()*i;
		$(this).css({left:left});
	
	});


	$(".tab_pannel").bind("tabchange", function ( e )
	
	{
		
			var idx =e.target.index();
		
			var left = -$(".probiotics").width()*idx;
		
			TweenMax.to($(".intro_con .list_set"), 1, {x:left, ease:Expo.easeInOut});
	
	});

});


</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					
					<label>Probiotics</label>
					<h4>Lactobacillus fermentum</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics_sub -->
				<div class="probiotics_sub">
				
					<!-- con_info -->
					
					<div class="con_info">
						
						
						<div class="top_txt_con">
							
							<p>
								
							<i>Lactobacillus fermentum</i> is a probiotic species of bacteria which inhabit the gastrointestinal tract, mouth and vagina of mammals, including humans. Its probiotic properties are reported to include the promotion of good digestive activity, reduction in respiratory illnesses and as a treatment for urogenital infection in females.
							
							</p>
						
						</div>
						
						
						<h4 class="sub_title">TÁC DỤNG</h4>
						
						
						<div class="effect_con">
							
							<div class="img_con"><img class="m_img" src="/assets/images/raw_material/woman_health_vn.png" /></div>
						
						</div>
						
					
					</div>
					
					<!-- //con_info -->	
					
				</div>
				<!-- //probiotics_sub -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->