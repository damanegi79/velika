<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/vn/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">THỬ NGHIỆM LÂM SÀNG</a></li>
						<li><a href="javascript:">RH1</a></li>
						<li class="on"><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li><a href="javascript:">Hợp chất K</a></li>
						<?Php else: ?>
							<li><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				<!-- main_title -->
				<div class="main_title">
					<label>Fermented Ginseng</label>
					<h4>RH2</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="active_g5_list">
						
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/raw_material/rh2_img.png" />
							</div>
							<div class="list_set">
								<h4>Hiệu quả của ginsenoside Rh2</h4>
								<ol>
									<li><span class="num">01</span><span class="txt">Ngăn ngừa phát triển và biệt hóa tế bào khối u</span></li>
									<li><span class="num">02</span><span class="txt">Tác dụng chống viêm</span></li>
									<li><span class="num">03</span><span class="txt">Tác dụng chống dị ứng</span></li>
									<li><span class="num">04</span><span class="txt">Cải thiện bài tiết insulin và độ nhạy của insulin</span></li>
								</ol>
							</div>
						</div>
						
						<div class="list_bottom">
							<h4>Bằng sáng chế: Phương pháp Sản xuất Ginsenoside Hoạt tính từ Nhân sâm</h4>
							<p>
								Phát minh này được coi là phương pháp sản xuất ginsenoside hoạt tính từ nhân sâm và chi tiết hơn, một phương pháp sản xuất ginsenoside hoạt tính Rh2, Rg 2 và F2, các sản phẩm trao đổi chất bằng nhân sâm, bằng việc tạo ra chiết xuất nhân sâm và vi sinh vật bên trong Leuconostoc phản ứng với nhau
							</p>						
						</div>
						
						<div class="page_bottom">
							<h4>GIẤY CHỨNG NHẬN</h4>
							<ol>
								<li>
									<span>1.</span>
									<span class="txt">
										Suppression of the Formation of Sister Chromatid Exchanges by Low. Concentrations of Ginsenoside Rh2 in Human Blood Lymphocytes. CANCER RESEARCH 55, 1221-1223, March 15, 1995
									</span>
								</li>
								<li>
									<span>2.</span>
									<span class="txt">
										Ginsenoside-Rh1 and Rh2 inhibit the induction of nitric oxide synthesis in murine peritoneal macrophages. Biochem Mol Biol Int. 1996 Nov; 40(4):751-7.
									</span>
								</li>
								<li>
									<span>3.</span>
									<span class="txt">
										Modulation of protein kinase C activity in NIH 3T3 cells by plant glycosides from Panax ginseng. Planta Med. 1997; 63:389-392.
									</span>
								</li>
								<li>
									<span>4.</span>
									<span class="txt">
										Ginsenoside Rh2 and Rh3 induce differentiation of HL-60 cells into granulocytes: modulation of protein kinase C isoforms during differentiation by ginsenoside Rh2. The International Journal of Biochemistry & Cell Biology Vol. Issue 3, 1 March 1998, 327-338
									</span>
								</li>
								<li>
									<span>5.</span>
									<span class="txt">
										Anti-invasive activity of ginsenoside Rh1 and Rh2 in the HT 1080 cells. J. Ginseng Res., 22, 216-221 (1998).
									</span>
								</li>
								<li>
									<span>6.</span>
									<span class="txt">
										Ginsenoside-Rh2 significantly inhibited MCF-7 cells growth in a concentration-dependent manner, which affect was reversible, and induced a G1 arrest in cell cycle progression. Int J Oncol. 1999 May; 14(5):869-75 
									</span>
								</li>
								<li>
									<span>7.</span>
									<span class="txt">
										Anti-proliferating effects of ginsenoside Rh2 on MCF-7 human breast cancer cells. Int J Oncol. 1999 May; 14(5):869-75. 
									</span>
								</li>
								<li>
									<span>8.</span>
									<span class="txt">
										Ginsenoside Rh2 induces apoptosis independently of Bcl-2, Bcl-xL, or Bax in C6Bu-1 cells. Arch Pharm Res. 1999 Oct; 22(5):448-53. 
									</span>
								</li>
								<li>
									<span>9.</span>
									<span class="txt">
										Differential expression of protein kinase C subtypes during ginsenoside Rh2-lnduced apoptosis in SK-N-BE(2) and C6Bu-1 cells. Arch Pharm Res. 2000 Oct; 23(5):518-24. 
									</span>
								</li>
								<li>
									<span>10.</span>
									<span class="txt">
										Anticarcinogenic effect of Panax ginseng C.A. Meyer and identification of active compounds. J Korean Med Sci. 2001 Dec; 16 Suppl:S6-18. 
									</span>
								</li>
								<li>
									<span>11.</span>
									<span class="txt">
										Cytotoxicity of Compound K (IH-901) and Ginsenoside Rh2, Main Biotransformants of Ginseng Saponins by Bifidobacteria, against Some Tumor Cells. J. Ginseng Res.Vol. 27, No. 3, 129-134(2003) 
									</span>
								</li>
								<li>
									<span>12.</span>
									<span class="txt">
										Antiallergic activity of ginsenoside Rh2. Biol Pharm Bull. 2003 Nov; 26(11):1581-4. 
									</span>
								</li>
								<li>
									<span>13.</span>
									<span class="txt">
										Ginsenoside Rh2 Reduces Ischemic Brain Injury in Rats. Biol Pharm Bull. 2004 Mar; 27(3):433-6 
									</span>
								</li>
								<li>
									<span>14.</span>
									<span class="txt">
										Gensenoside-Rh2 inhibited cell growth by GI arrest at low concentrations and induced apoptosis at high con-centrations in a variety of tumor cell lines. Rh2 can act either additively or synergistically with chemotherapy drugs (paclitaxel) on cancer cells. Can J Physiol Pharmacol. 82:431-437 (2004)  
									</span>
								</li>
								<li>
									<span>15.</span>
									<span class="txt">
										Ginsenosides 20(S)-protopanaxadiol and Rh2 reduce cell proliferation and increase sub-G1 cells in two cultured intestinal cell lines, Int-407 and Caco-2. Can J Physiol Pharmacol. 2004 Mar; 82(3):183-90.  
									</span>
								</li>
								<li>
									<span>16.</span>
									<span class="txt">
										Ginsenoside Rh2 induces apoptosis via activation of caspase-1 and -3 and up-regulation of Bax in human neuroblastoma. Arch Pharm Res. 2004 Aug; 27(8):834-9.  
									</span>
								</li>
								<li>
									<span>17.</span>
									<span class="txt">
										Uptake and Metabolism of Ginsenoside Rh2 and Its Aglycon Protopanaxadiol by Caco-2 Cells. Biological & Pharmaceutical Bulletin Vol. 28 (2005) , No. 2 383  
									</span>
								</li>
								<li>
									<span>18.</span>
									<span class="txt">
										Ginsenoside-Rh2-Induced Mitochondrial Depolarization and Apoptosis Are Associated with Reactive Oxygen Species- and Ca2+-Mediated c-Jun NH2-Terminal Kinase 1 Activation in HeLa Cells. J Pharmacol Exp Ther. 2006 Dec; 319(3):1276-85. Epub 2006 Sep 14.  
									</span>
								</li>
								<li>
									<span>19.</span>
									<span class="txt">
										Among ginsenosides, metabolites PPD, Rh2 and PPT were inhibitors of BCRP (ABC transporters : overex-pression is shown to confer resistance against various clinically relevant compounds). Biochemical and Biophysical Research Communications, 345 (2006) 1308-1314  
									</span>
								</li>
								<li>
									<span>20.</span>
									<span class="txt">
										Increase of insulin secretion by ginsenoside Rh2 to lower plasma glucose in Wistar rats. Clin Exp Pharmacol Physiol. 2006 Jan-Feb;33(1-2):27-32  
									</span>
								</li>
								<li>
									<span>21.</span>
									<span class="txt">
										Inhibitory effects of Korean red ginseng and its genuine constituents ginsenosides Rg3, Rf, and Rh2 in mouse passive cutaneous anaphylaxis reaction and contact dermatitis models. Biol Pharm Bull. 2006 Sep;29(9):1862-7.  
									</span>
								</li>
								<li>
									<span>22.</span>
									<span class="txt">
										Anti-obesity effects of ginsenoside Rh2 are associated with the activation of AMPK signaling pathway in 3T3-L1 adipocyte. Biochemical and Biophysical Research Communications 364 (2007) 1002-1008  
									</span>
								</li>
								<li>
									<span>23.</span>
									<span class="txt">
										Ginsenoside Rh2 is one of the active principles of Panax ginseng root to improve insulin sensitivity in fructose-rich chow-fed rats. Horm Metab Res. 2007 May;39(5):347-54.  
									</span>
								</li>
							</ol>						
						</div>
						
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->