<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/vn/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1_on.png" /></div>
								<h4>NHÂN SÂM LÊN MEN</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4 style="line-height:24px">KHẢ NĂNG CẠNH TRANH<br />CỦA BIFIDO</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>NGHIÊN CỨU</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				

					
					<div class="fermented_list">
						<div class="research_list">
							<ul>
								<li>
									<h4>BẰNG SÁNG CHẾ 10-0811295</h4>
									<div class="img_con">
										<img src="/assets/images/raw_material/research_img1.png" />
									</div>
									<p>Phương pháp sản xuất ginsenoside hoạt tính từ nhân sâm</p>
								</li>
								<li>
									<h4>BẰNG SÁNG CHẾ 10-1101294</h4>
									<div class="img_con">
										<img src="/assets/images/raw_material/research_img2.png" />
									</div>
									<p>Phương pháp sản xuất liên tục hợp chất ginsenoside K bằng beta-glycosidase cố định</p>
								</li>
								<li>
									<h4>BẰNG SÁNG CHẾ 10-1181524</h4>
									<div class="img_con">
										<img src="/assets/images/raw_material/research_img3.png" />
									</div>
									<p>Thành phần có tác dụng điều trị viêm mũi dị ứng bằng hồng sâm lên men</p>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->