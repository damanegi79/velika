<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/vn/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1_on.png" /></div>
								<h4>NHÂN SÂM LÊN MEN</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4 style="line-height:24px">KHẢ NĂNG CẠNH TRANH<br />CỦA BIFIDO</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>NGHIÊN CỨU</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<p class="list">Chức năng có ích với sức khỏe đã được chứng nhận  </p>
						<p class="list">Nồng độ cao ginsenoside kích thước nhỏ</p>
					</div>
					
					<div class="fermented_list">
						<div class="list_page">
							<h3>BIFIDO ACTIVE G5</h3>
							
							<div class="line2"></div>
							
							<div class="g5_list">
								<ul class="blind">
									<li>HỖ TRỢ HỆ MIỄN DỊCH</li>
									<li>CẢI THIỆN THỂ CHẤT</li>
									<li>SỨC BỀN VÀ CHỐNG MỆT MỎI</li>
									<li>HỖ TRỢ TĂNG TRÍ NHỚ</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img1_vn.png" />
							</div>

							<div class="g5_list_2">
								<ul class="blind">
									<li>NHÂN SÂM</li>
									<li>NHÂN SÂM LÊN MEN</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img2_vn.png" /><br /><br />
								<p>
									Bằng việc lên men nhân sâm, glycoside ginsenoside được chuyển thành ginsenoside không có glycoside. Nói cách khác, glucose cùng với saponin được chuyển hóa bởi <i>Bifidobacterium</i> thành ginsenoside kích cỡ nhỏ hơn.
									<br /><br />
									Nhân sâm lên men chứa nồng độ cao Hợp chất K, Rh1, Rh2, Rg1 và Rg2 với khả năng cải thiện hoạt động sinh học.
								</p><br />
								<h4>So sánh nhân sâm lên men ACTIVE G5 và chiết xuất nhân sâm.</h4><br />
								<img class="m_img" src="/assets/images/raw_material/g5_img3.png" /> 
							</div>
							
							<div class="line2 mt40"></div>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->