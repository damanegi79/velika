<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/vn/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});
		
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".tab_pannel li.ck a").text("C.K");
		}
		else
		{
			$(".tab_pannel li.ck a").text("COMPOUND K");
		}
	});		
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">THỬ NGHIỆM LÂM SÀNG</a></li>
						<li><a href="javascript:">RH1</a></li>
						<li><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li><a href="javascript:">Hợp chất K</a></li>
						<?Php else: ?>
							<li><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li class="on"><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				<!-- main_title -->
				<div class="main_title">
					<label>Fermented Ginseng</label>
					<h4>RK1</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="active_g5_list">
						
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/raw_material/rk1_img.png" />
							</div>
							<div class="list_set">
								<h4>Hiệu quả của gisenoside Rk1</h4>
								<ol>
									<li><span class="num">01</span><span class="txt">Hoạt động chống khối u</span></li>
								</ol>
							</div>
						</div>
						
						<div class="page_bottom">
							<h4>GIẤY CHỨNG NHẬN</h4>
							<ol>
								<li>
									<span>1.</span>
									<span class="txt">
										 Anti-tumor activity of the ginsenoside Rk1 in human hepatocellular carcinoma cells through inhibition of telomerase activity and induction of apoptosis.Biol Pharm Bull. Vol. 31a Issue 5 Pg. 826-30 (May 2008) ISSN: 0918-6158 Japan
									</span>
								</li>
							</ol>						
						</div>
						
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->