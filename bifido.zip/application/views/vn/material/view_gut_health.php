
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- choose_cate_con -->
			<div class="choose_cate_con">
				<div class="choose_cate">
					<h4>Choose category</h4>
					<ul>
						<li><a href="/vn/material/probiotics/gut_health?category=b_lactis_as60">B.LACTIS AS60</a></li>
						<li><a href="/vn/material/probiotics/gut_health?category=pai_probiotics">PAI PROBIOTICS</a></li>
						<li><a href="/vn/material/probiotics/gut_health?category=gnl_probiotics">GNL PROBIOTICS</a></li>
					</ul>
				</div>
			</div>
			<!-- //choose_cate_con -->
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>ALL STRAINS <span>(Lactobacillus and Bifidobacterium)</span></h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics_sub -->
				<div class="probiotics_sub">
					<div class="con_main">
						<ul>
							<li>Mechanism of immunity enhancement effect</li>
							<li>Specification </li>
							<li>Stability</li>
							<li>Related research and patent</li>
						</ul>
					</div>
					<div class="bottom_btn">
						<a href="/vn/story/probiotics_bifidus">PROBIOTICS<span class="icon"></span></a>
					</div>
				</div>
				<!-- //probiotics_sub -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->