<script type="text/javascript">

$(function ()
{
	var selectNum = 0;
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/vn/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});

	$(".activ_list li").each(function ( i )
	{
		$(this).find("a").bind("click", function ( e )
		{
			changeActiv5($(this).parent().index());
		});
	});

	changeActiv5(0);

	function changeActiv5( idx )
	{
		$(".activ_list li").each(function ( i )
		{
			if(idx == i)
			{
				$(this).css({opacity:1});
			}
			else
			{
				$(this).css({opacity:0});
			}
		});
		$(".activ_info .info_con").css({display:"none"});
		$(".activ_info .info_con").eq(idx).css({display:"block"});
		
		selectNum = idx;
	}

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".activ_info .info_con").css({display:"block"});
		}
		else
		{
			changeActiv5(selectNum);
		}
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1_on.png" /></div>
								<h4>NHÂN SÂM LÊN MEN</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4 style="line-height:24px">KHẢ NĂNG CẠNH TRANH<br />CỦA BIFIDO</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>NGHIÊN CỨU</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<p>
							Bằng việc lên men nhân sâm, glycoside ginsenoside được chuyển thành ginsenoside không có glycoside. Nói cách khác, đường cùng với ginsenoside được chuyển hóa bởi <i>Bifidobacterium</i> thành aglycone ginsenoside kích cỡ nhỏ hơn.
							<br /><br />
							Nhân sâm lên men chứa nồng độ cao Hợp chất K, Rh1, Rh2, Rg5, Rk1, PPD, PPT và ginsenoside với nhiều tác dụng khác nhau. Tỷ lệ hấp thụ cao vào cơ thể sẽ tối đa tác dụng của nó về mặt dược học.
						</p>	
					</div>
					
					<div class="fermented_list">
						<div class="list_page">
							<h3>TÁC DỤNG Y HỌC CỦA GINSENOSIDE</h3>
							<div class="line2"></div>
							<div class="activ_list">
								<h4 class="blind">ginsenosides</h4>
								<div class="menu_con">
									<ul>
										<li style="top:-154px;left:-78px"><a href="javascript:">RG1</a></li>
										<li style="top:-154px;left:86px"><a href="javascript:">RG2</a></li>
										<li style="top:-32px;left:149px"><a href="javascript:">RG3</a></li>
										<li style="top:90px;left:85px"><a href="javascript:">C.K</a></li>
										<li style="top:90px;left:-77px"><a href="javascript:">RH1</a></li>
										<li style="top:-32px;left:-141px"><a href="javascript:">RH2</a></li>
									</ul>
								</div>
							</div>
							<div class="activ_info">
								<div class="info_con">
									<h2>RG1</h2>
									<div class="list_set">
										<ul>
											<li>Cải thiện miễn dịch</li>
											<li>Ngăn ngừa đông tiểu cầu máu</li>
											<li>Tăng trí nhớ</li>
										</ul>
										<ul>
											<li>Giảm mệt mỏi và căng thẳng</li>
											<li>Kích thích hệ thần kinh</li>
											<li>Cải thiện phân bào và tổng hợp DNS</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RG2</h2>
									<div class="list_set">
										<ul>
											<li>Ngăn ngừa đông tiểu cầu máu</li>
											<li>Tăng trí nhớ</li>
											<li>Điều tiết dòng canxi nội bào</li>
										</ul>
										<ul>
											<li>Ức chế bài tiết acetylcholine</li>
											<li>Ức chế sản xuất thừa catechcholamine</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RG3</h2>
									<div class="list_set">
										<ul>
											<li>Ức chế sự phát triển của tế bào ung thư</li>
											<li>Ức chế đông máu trong mạch máu</li>
											<li>Làm thuốc chống ung thư</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>Hợp chất K</h2>
									<div class="list_set">
										<ul>
											<li>Ngăn sự phát triển tế bào khối u và viêm</li>
											<li>Có tác dụng gây độc cho nhiều thành tế bào ung thư</li>
											<li>Tác dụng chống ung thư</li>
											<li>Tác dụng chống dị ứng</li>
										</ul>
										<ul>
											<li>Giảm triệu chứng của bệnh Alzheimer</li>
											<li>Chống đái tháo đường và oxy hóa</li>
											<li>Cải thiện bài tiết insulin</li>
											<li>Tác dụng bảo vệ gan và da</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RH1</h2>
									<div class="list_set">
										<ul>
											<li>Tác dụng chống dị ứng</li>
											<li>Tác dụng chống viêm</li>
											<li>Có tác dụng gây độc cho nhiều thành tế bào ung thư</li>
										</ul>
										<ul>
											<li>Ngăn ngừa phát triển và biệt hóa tế bào khối u</li>
											<li>Ức chế sự phát triển của bệnh phổi</li>
											<li>Ngăn ngừa đông tiểu cầu máu</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RH2</h2>
									<div class="list_set">
										<ul>
											<li>Ngăn ngừa phát triển và biệt hóa tế bào khối u</li>
											<li>Tác dụng chống viêm</li>
										</ul>
										<ul>
											<li>Tác dụng chống dị ứng</li>
											<li>Cải thiện bài tiết insulin và độ nhạy của insulin</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="line2 mt40"></div>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->