<script type="text/javascript">

$(function ()
{
	var linkAr = ["b_lactis_as60", "pai_probiotics", "gnl_probiotics"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx = $(e.target).index();
		location.href = "/vn/material/probiotics/gut_health?category="+linkAr[idx];
	});
	
});


</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">B.LACTIS AS60</a></li>
						<li><a href="javascript:">PROBIOTICS PAI</a></li>
						<li class="on"><a href="javascript:">PROBIOTICS GNL</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- main_title -->
				<div class="main_title">
					<label>Probiotics</label>
					<h4>PROBIOTICS GNL</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					Probiotics GNL
				</div>
				<!-- //sub_title -->
				<!-- probiotics_sub -->
				<div class="probiotics_sub">
				
					<!-- con_info -->
					<div class="con_info">
						
						<div class="top_img_con">
							<img class="m_img" src="/assets/images/raw_material/cut_health_top_gnl_probiotices.png" />
						</div>
						
						<h4 class="sub_title">GIẤY CHỨNG NHẬN</h4>
						
						<div class="sub_txt">
							<a href="#">Effect of Probiotics on Symptoms in Korean Adults with Irritable Bowel Syndrome <span class="link"></span></a>
						</div>
						
						<h4 class="sub_title">TÁC DỤNG</h4>
						
						<div class="effect_con">
							<div class="img_con"><img class="m_img" src="/assets/images/raw_material/cut_health_gnl_probiotices_vn.png" /></div>
						</div>
						
					</div>
					<!-- //con_info -->	
				</div>
				<!-- //probiotics_sub -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->