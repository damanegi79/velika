<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/vn/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1_on.png" /></div>
								<h4>NHÂN SÂM LÊN MEN</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4 style="line-height:24px">KHẢ NĂNG CẠNH TRANH<br />CỦA BIFIDO</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>NGHIÊN CỨU</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<h4>NHÂN SÂM LÊN MEN</h4>
						<p class="mt10">
							Ngày nay, hơn 30 loại Ginsenoside, là từ ghép của Nhân sâm và Glycoside, đã được chiết xuất từ Nhân sâm Hàn Quốc. Đặc tính về cấu trúc được chia thành Diol, Triol và Oleanane và chúng tôi công nhận rằng tác dụng y học của từng phân loại là khác nhau. Ginsenoside là một nguyên tố hữu dụng với các hạt lớn nhất trong nhân sâm, không thể được hấp thụ vào cơ thể trước khi nó được phân hủy thành các Ginsenoside có kích cỡ nhỏ hơn bởi vi sinh vật hoặc enzyme trong cơ quan con người.
							<br />
							<br />
							Chúng tôi đã xây dựng quy trình lên men ginsenoside bằng vi sinh vật cấp thực phẩm để tăng tốc độ hấp thụ ginsenoside và được gói là “Nhân sâm Lên men”.
						</p>	
					</div>
					
					<div class="fermented_list">
						<div class="ginseng_list">
							<ol class="blind">
								<li>
									<h4>NHÂN SÂM</h4>
									<p>Trước khi Hồng sâm xuất hiện, nhân sâm thường là loại tốt nhất.</p>
								</li>
								<li>
									<h4>HỒNG SÂM</h4>
									<p>Trước khi chúng tôi phát hiện ra Chiết xuất Nhân sâm Lên men, Hồng Sâm là loại tốt nhất.</p>
								</li>
								<li>
									<h4>CHIẾT XUẤT NHÂN SÂM LÊN MEN</h4>
									<p>Nhưng bây giờ là thời đại của Chiết xuất Nhân sâm Lên men. Nó tạo ra nhiều thành phần có lợi về mặt y học.</p>
								</li>
							</ol>
							<img class="m_img" src="/assets/images/raw_material/permented_img1_vn.png" />
						</div>	
					</div>
					
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->