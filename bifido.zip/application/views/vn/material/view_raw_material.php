<script type="text/javascript">

$(function ()
{
	$(".intro_list").each(function ( i )
	{
		var left = $(".probiotics").width()*i;
		$(this).css({left:left});
	});

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		var left = -1000*idx;
		TweenMax.to($(".intro_con .list_set"), 1, {x:left, ease:Expo.easeInOut});
		$(".intro_con_m .intro_list").css({display:"none"});
		$(".intro_con_m .intro_list").eq(idx).css({display:"block"});
	});

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".service_list li").removeClass("blind");
		}
		else
		{
			$(".service_list li").addClass("blind");
		}
	});

});



</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>PROBITICS CHÚNG TÔI SẢN XUẤT</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics -->
				<div class="probiotics">
				
					<!-- "produce_con" -->
					<div class="produce_con">
						<ul>
							<li class="l">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img1.png" /></div>
								<p class="title">B.bifidum <strong>BGN4</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img2.png" /></div>
								<p class="title">B.longum <strong>BORI</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img3.png" /></div>
								<p class="title">B.lactis <strong>AD011</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img4.png" /></div>
								<p class="title">B.lactis <strong>AS60</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img5.png" /></div>
								<p class="title">B.infantis <strong>BH07</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img6.png" /></div>
								<p class="title">L.acidophilus <strong>AD031</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img7.png" /></div>
								<p class="title">L.paracasei <strong>BH08</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img8.png" /></div>
								<p class="title">L.plantarum <strong>BH02</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img9.png" /></div>
								<p class="title">L.casei <strong>IBS041</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img10.png" /></div>
								<p class="title">L.fermentum <strong>BH03</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img11.png" /></div>
								<p class="title">L.rhamnosus <strong>BH09</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img12.png" /></div>
								<p class="title">L.bulgaricus <strong>BH04</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img13.png" /></div>
								<p class="title">L.lactis <strong>BH10</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img14.png" /></div>
								<p class="title">S.thermophilus <strong>BH05</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img15.png" /></div>
								<p class="title">E.faecium <strong>BH06</strong></p>
							</li>
						</ul>
					</div>
					<!-- //"produce_con" -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>DỊCH VỤ CỦA CHÚNG TÔI</h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						<strong>Chúng tôi có thể cung cấp sản phẩm với nhiều hình thức và nồng độ.</strong>
						BIFIDO cung cấp nhiều sản phẩm dạng bột, gói, viên nang, viên nén theo yêu cầu của khách hàng. Mỗi dạng có thể được đóng gói như nguyên liệu thô, viên nang và viên nén bằng công nghệ đóng gói PTP và thành phẩm bằng đóng gói dạng chai hoặc hộp.
					</div>
					<!-- //sub_title -->
					
					<!-- tab_pannel -->
					<div class=tab_pannel>
						<ul>
							<li class="on"><a href="javascript:">BỘT</a></li>
							<li><a href="javascript:">GÓI</a></li>
							<li><a href="javascript:">VIÊN NANG</a></li>
							<li><a href="javascript:">VIÊN NÉN</a></li>
						</ul>
					</div>
					<!-- //tab_pannel -->
					
					<!-- intro_con" -->
					<div class="intro_con">
						<!-- list_set" -->
						<div class="list_set">
							<!-- powder" -->
							<div class="intro_list powder">
								<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img_vn.png" /></div>
								<div class="txt_con">
									<h4>DẠNG BỘT</h4>
									<p>
										Thông qua quy trình sấy khô, đông cứng và ly tâm<br />, 
										sự ổn định của việc nuôi cấy probiotics sẽ được tăng lên.<br />
										Bằng việc pha loãng bột ban đầu bằng tá dược đặc biệt,<br />
										sự ổn định của bột probiotics cũng sẽ được tăng lên.
									</p>
									<p>
										Hệ thống đảm bảo chất lượng đóng vai trò quan trọng<br /> 
										trong việc duy trì chất lượng cao cho sản phẩm dạng<br /> 
										bột của BIFIDO. Hình thức, độ ẩm, hoạt độ nước, tá dược,<br />
										màu sắc, hương vị v.v được theo dõi chặt chẽ bởi Nhóm <br />
										Kiểm soát Chất lượng BIFIDO để đảm bảo chất lượng tốt <br />
										nhất của sản phẩm.

									</p>
									<p>
										Lượng bột probiotics lớn có thể được sử dụng để sản xuất thành phẩm<br /> 
										cùng với các thành phần khác như prebiotics theo yêu cầu của khách hàng.
									</p>
								</div>
							</div>
							<!-- //powder -->
							<!-- stick" -->
							<div class="intro_list stick">
								<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img_vn.png" /></div>
								<div class="txt_con">
									<h4>Dạng Gói</h4>
									<p>
										Chúng tôi cung cấp dịch vụ đóng gói bằng việc bơm khí ni <br />
										tơ để giữ sự ổn định của probiotics trong sản phẩm. Bằng <br />
										dây chuyền sản xuất tự động, chúng tôi có thể tạo ra kích<br />
										cỡ khác nhau của sản phẩm probiotics dạng gói. <br />
										Trong lớp bao bì thứ hai, chúng tôi bổ sung chất hút ẩm<br />
										để tăng gấp đôi khả năng bảo vệ sản phẩm khỏi các yếu <br />
										tố gây hại của môi trường.
									</p>
									<p>
										Để giảm ảnh hưởng của nhiệt trong quá trình hàn gói,<br /> 
										chúng tôi sử dụng hệ thống làm mát để hàn kín gói.
									</p>
								</div>
							</div>
							<!-- //stick" -->
							<!-- capsule" -->
							<div class="intro_list capsule">
								<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img_vn.png" /></div>
								<div class="txt_con">
									<h4>Dạng Viên nang</h4>
									<p>
										Dạng viên nang có thể bảo vệ probiotics khỏi oxy <br />
										để tăng sự ổn định. Kỹ <a href="javascript:openPopup('/vn/popup/material_enteral');">thuật phủ trong ruột<span class="link"></span></a> của BIFIDO<br />
										làm tăng tỷ lệ sống sót của probiotics trong hệ tiêu hóa.
									</p>
									<div class="list">
										<dl>
											<dt style="width:110px">· <strong>Ưu điểm  :</strong></dt>
											<dd>Dễ vận chuyển và uống.</dd>
										</dl>
										<dl>
											<dt style="width:110px">· <strong>Nhược điểm :</strong></dt>
											<dd>
												Lượng probiotics được bổ sung trong <br />
												một viên nang bị hạn chế. Cần prebiotics<br />
												hoạt động như một yếu tố tăng trưởng của<br /> 
												probiotics.
											</dd>
										</dl>
									</div>
									<div class="list">
										<dl>
											<dt style="width:160px">· Nguyên liệu viên nang :</dt>
											<dd>Gelatin, HPMC, HPMCP</dd>
										</dl>
										<dl>
											<dt style="width:160px">· Kích cỡ viên nang :</dt>
											<dd>0 / 1</dd>
										</dl>
									</div>
								</div>
							</div>
							<!-- //capsule -->
							<!-- tablet" -->
							<div class="intro_list tablet">
								<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img_vn.png" /></div>
								<div class="txt_con">
									<h4>Dạng Viên nén</h4>
									<p>
										Công nghệ <a href="javascript:openPopup('/vn/popup/material_tablet');">viên nén nhỏ</a><span class="link"></span> của BIFIDO không chỉ duy trì hoạt động của <br />
										probiotics mà còn giảm số lượng chất kết dính. <br />
										<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2_vn.png" />
									</p>
								</div>
							</div>
							<!-- //tablet -->
						</div>
						<!-- //list_set" -->
					</div>
					<!-- //intro_con" -->
					
					<!-- intro_con_m" -->
					<div class="intro_con_m">
						<!-- powder" -->
						<div class="intro_list powder">
							<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img_vn_m.png" /></div>
							<div class="txt_con">
								<h4>DẠNG BỘT</h4>
								<p>
									Thông qua quy trình sấy khô, đông cứng và ly tâm sự ổn định của việc nuôi cấy probiotics sẽ được tăng lên.<br />
									Bằng việc pha loãng bột ban đầu bằng tá dược đặc biệt, sự ổn định của bột probiotics cũng sẽ được tăng lên.
								</p>
								<p>
									Hệ thống đảm bảo chất lượng đóng vai trò quan trọng trong việc duy trì chất lượng cao cho sản phẩm dạng bột của BIFIDO. 
									Hình thức, độ ẩm, hoạt độ nước, tá dược, màu sắc, hương vị v.v được theo dõi chặt chẽ bởi Nhóm Kiểm soát Chất lượng BIFIDO để đảm bảo chất lượng tốt nhất của sản phẩm.
								</p>
								<p>
									Lượng bột probiotics lớn có thể được sử dụng để sản xuất thành phẩm cùng với các thành phần khác như prebiotics theo yêu cầu của khách hàng.
								</p>
							</div>
						</div>
						<!-- //powder -->
						<!-- stick" -->
						<div class="intro_list stick">
							<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img_vn_m.png" /></div>
							<div class="txt_con">
								<h4>Dạng Gói</h4>
								<p>
									Chúng tôi cung cấp dịch vụ đóng gói bằng việc bơm khí ni tơ để giữ sự ổn định của probiotics trong sản phẩm.<br />
									Bằng dây chuyền sản xuất tự động, chúng tôi có thể tạo ra kích cỡ khác nhau của sản phẩm probiotics dạng gói. <br />
									Trong lớp bao bì thứ hai, chúng tôi bổ sung chất hút ẩm để tăng gấp đôi khả năng bảo vệ sản phẩm khỏi các yếu tố gây hại của môi trường.
								</p>
								<p>
									Để giảm ảnh hưởng của nhiệt trong quá trình hàn gói, chúng tôi sử dụng hệ thống làm mát để hàn kín gói.
								</p>
							</div>
						</div>
						<!-- //stick" -->
						<!-- capsule" -->
						<div class="intro_list capsule">
							<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img_vn_m.png" /></div>
							<div class="txt_con">
								<h4>Dạng Viên nang</h4>
								<p>
									Dạng viên nang có thể bảo vệ probiotics khỏi oxy để tăng sự ổn định.<br />  
									Kỹ <a href="javascript:openPopup('/vn/popup/material_enteral');">thuật phủ trong ruột<span class="link"></span></a> của BIFIDO làm tăng tỷ lệ sống sót của probiotics trong hệ tiêu hóa.<br />
									<br />
									· <strong>Ưu điểm :</strong>Dễ vận chuyển và uống.<br />
									· <strong>Nhược điểm :</strong>Lượng probiotics được bổ sung trong một viên nang bị hạn chế. Cần prebiotics hoạt động như một yếu tố tăng trưởng của probiotics.<br />
									<br />
									· Nguyên liệu viên nang : Gelatin, HPMC, HPMCP<br />
									· Kích cỡ viên nang : G0 / 1<br />
								</p>
							</div>
						</div>
						<!-- //capsule -->
						<!-- tablet" -->
						<div class="intro_list tablet">
							<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img_vn_m.png" /></div>
							<div class="txt_con">
								<h4>Dạng Viên nén</h4>
								<p>
									Công nghệ<a href="javascript:openPopup('/vn/popup/material_tablet');">viên nén nhỏ</a><span class="link"></span> của BIFIDO không chỉ duy trì hoạt động của probiotics mà còn giảm số lượng chất kết dính. <br />
									<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2_vn_m.png" />
								</p>
							</div>
						</div>
						<!-- //tablet -->
					</div>
					<!-- //intro_con_m" -->
					
					<!-- main_title -->
					<div class="main_title">
						<p>KHẢ NĂNG CẠNH TRANH CHÍNH CỦA SẢN PHẨM CỦA CHÚNG TÔI</p>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- product_con -->
					<div class="product_con">
						<div class="product_list">
							<ul>
								<li style="top:30px;left:20px">
									<h4>Có nguồn gốc từ con người</h4>
									<p>
										Probiotics có nguồn gốc từ con người dễ liên <br />
										kết với nhung mao và phát triển trong đường<br />
										ruột đã được chứng minh trong một số <a href="#">nghiên<br />
										cứu lâm sàng</a><span class="link"></span>.
										<!--
										Human-origin probiotics is much easier to adhere <br />
										to the villi and grow in the intestine tract <br />
										according to <a href="#">clinical study</a><span class="link"></span>.
										-->
									</p>
								</li>
								<li class="r" style="top:30px;right:20px">
									<h4>
										Giấy chứng nhận nghiên cứu và bằng sáng chế
									</h4>
									<p>
										· 26 bằng sáng chế<br />
										· Hơn 100 giấy chứng nhận nghiên<br /> 
										cứu về vi khuẩn axit lactic
									</p>
								</li>
								<li style="bottom:30px;left:20px">
									<h4>BIFIDO là một chuyên gia về BIFIDUS</h4>
									<p>
										Chúng tôi là những chuyên gia về <br />
										nghiên cứu và nuôi cấy probiotics,  <br />
										đặc biệt đối với <i>Bifidobacterium</i> sp. <br />
										kỵ khí có nguồn gốc từ con người.
									</p>
								</li>
								<li class="r" style="bottom:30px;right:20px">
									<h4>Ít rủi ro hơn</h4>
									<p>
										· Bạn không cần lo lắng về rủi ro tiếp<br />
										hợp DNA không có lợi do probiotics có<br />
										nguồn gốc từ động vật.
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">Xem thêm chi tiết</span>
							<a href="/vn/story" style="width:215px">Câu chuyện của Bifidus<span class="icon"></span></a>
						</div>
					</div>
					<!-- //product_con -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>HỒ SƠ <span>(GIẤY CHỨNG NHẬN NGHIÊN CỨU, BẰNG SÁNG CHẾ, GIẤY CHỨNG NHẬN)</span></h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						BIFIDO có nhiều kinh nghiệm trong việc nghiên cứu và sản xuất vi khuẩn axit lactic.
					</div>
					<!-- //sub_title -->
					
					<!-- "service_con" -->
					<div class="service_con vn">
						<div class="service_list">
							<ul>
								<li class="blind">
									<h4>CÔNG TY</h4>
									<p>
										· Giấy chứng nhận GMP
									</p>
								</li>
								<li class="blind">
									<h4>CHUỖI</h4>
									<p>
										· Giấy chứng nhận Halal<br />
										· Nghiên cứu Lâm sàng<br />
										· Dữ liệu Ổn định<br />
										· Phương pháp Phân tích (MOA) <br />
										· Bảng Dữ liệu An toàn Hóa chất (MSDS) <br />
										· ETX
									</p>
								</li>
								<li class="blind">
									<h4>HỒ SƠ ĐĂNG KÝ</h4>
									<p>
										· Giấy chứng nhận Lưu hành Tự do<br />
										· Giấy chứng nhận Phân tích<br />
										· Giấy chứng nhận Y tế<br />
										· Giấy chứng nhận Xuất xứ<br />
										· Etc.
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">Xem thêm chi tiết</span>
							<a href="/vn/about/download/brochure">Tải xuống<span class="icon"></span></a>
						</div>
					</div>
					<!-- //"service_con" -->
					
					
					
				</div>
				<!-- //probiotics -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->