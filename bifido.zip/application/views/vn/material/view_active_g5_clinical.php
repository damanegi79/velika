<script type="text/javascript">

$(function ()
{
	
	$(".tab_pannel.tab1").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/vn/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});	

	$(".tab_pannel.tab2").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		$(".list_page p").css({display:"none"});
		$(".list_page .list"+(idx+1)).css({display:"block"});
	});		
	
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel tab1" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">THỬ NGHIỆM LÂM SÀNG</a></li>
						<li><a href="javascript:">RH1</a></li>
						<li><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li><a href="javascript:">Hợp chất K</a></li>
						<?Php else: ?>
							<li><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				
				<!-- main_title -->
				<div class="main_title">
					<h4>ACTIVE G5</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="clinical_list">
						<div class="clinical_img">
							<img src="/assets/images/raw_material/clinical_img.png" />
						</div>
						<p class="title">
							Bằng việc lên men nhân sâm, glycoside ginsenoside được chuyển thành ginsenoside không có glycoside. Nói cách khác, glucose cùng với saponin được chuyển hóa bởi <i>Bifidobacterium</i> thành ginsenoside kích cỡ nhỏ hơn. Nhân sâm lên men chứa nồng độ cao Hợp chất K, Rh1, Rh2, Rg1 và Rg2 với khả năng cải thiện hoạt động sinh học.
						</p>	
						<!-- tab_pannel -->
						<div class="tab_pannel tab2">
							<ul>
								<li class="on"><a href="javascript:">MỤC ĐÍCH</a></li>
								<li><a href="javascript:">PHƯƠNG PHÁP</a></li>
								<li><a href="javascript:">KẾT QUẢ</a></li>
								<li><a href="javascript:">KẾT LUẬN</a></li>
							</ul>
						</div>
						<!-- tab_pannel -->
						
						<!-- list_page -->
						<div class="list_page">
							<p class="list1">
								Viêm mũi dị ứng được định nghĩ lâm sàng là sự rối loạn của mũi do viêm trung gian IgE sau khi gây dị ứng niêm mạc mũi. Một số báo cáo đã chỉ ra rằng nhân sâm Panax và hồng sâm lên men có tác dụng chống viêm, đặc biệt là chống viêm loại Th2. Nghiên cứu này đã được thực hiện để đánh giá hiệu quả điều trị viêm mũi dị ứng bằng hồng sâm lên men.
							</p>
							<p class="list2" style="display:none">
								Trong bốn tuần trong nghiên cứu kín kép và đối chứng, 59 bệnh nhân mắc viêm mũi dị ứng lâu năm đã được chia ngẫu nhiên thành hai nhóm: một nhóm uống viên nén hồng sâm lên men (nhóm thí nghiệm) và một nhóm uống giả dược (nhóm đối chứng). Sự thay đổi về hiệu quả sơ cấp là tổng điểm triệu chứng ở mũi (TNSS: sổ mũi, hắt hơi, ngứa mũi và ngạt mũi). Sự thay đổi về hiệu quả thứ cấp là điểm chất lượng cuộc sống khi mắc viêm mũi (RQoL) và khả năng phản ứng của da với dị ứng hô hấp, được xác định bằng thử nghiệm chích da.
							</p>
							<p class="list3" style="display:none">
								Không có sự khác biệt đáng kể giữa điểm TNSS và điểm thời gian TNSS giữa nhóm thí nghiệm và nhóm đối chứng trong tuần 1, 2, 3 hoặc 4. Đối với ngạt mũi, hồng sâm lên men có hiệu quả đáng kể (P<0,005) trong khi giả dược không tạo ra thay đổi. Hoạt động và tình hình của RQoL đã cải thiện đáng kể khi được điều trị bằng hồng sâm lên men (P<0,05) trong khi giả dược không tạo ra thay đổi. Thêm vào đó, hồng sâm lên men làm giảm khả năng phản ứng của da đối với dị ứng lâu năm (P<0,05). Hồng sâm lên men có tác dụng tốt.
							</p>
							<p class="list4" style="display:none">
								Hồng sâm lên men cải thiện triệu chứng ngạt mũi và RQoL trong bệnh nhân mắc viêm mũi dị ứng lâu năm.
							</p>
						</div>
						<!-- list_page -->
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->