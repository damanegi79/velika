<script type="text/javascript">

$(function ()
{
	
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		if(idx == 0)
		{
			$(".partners1").css({display:"block"});
			$(".partners2").css({display:"none"});
		}
		else
		{
			$(".partners1").css({display:"none"});
			$(".partners2").css({display:"block"});
		}
		
	});			
});

</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">			
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>PARTNER’S BRAND</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- tab_pannel
					<div class="tab_pannel">
						<ul>
							<li class="on"><a href="javascript:">ODM PROCESS</a></li>
							<li><a href="javascript:">PRODUCT</a></li>
						</ul>
					</div>
					 -->
					
					<div class="partners1">
						<div class="blind">
							<h2>ODM PROCESS</h2>
							<h2>QUY TRÌNH ODM</h2>
							<ol>
								<li>
									<h4>NHU CẦU CỦA KHÁCH HÀNG</h4>
								</li>
								<li>
									<h4>TƯ VẤN KINH DOANH</h4>
									<p>(Phòng Kinh doanh và Viện Nghiên cứu Trung tâm)</p>
								</li>
								<li>
									<h4>Ký kết Hợp đồng</h4>
									<p>Phòng Kinh doanh</p>
								</li>
								<li>
									<h4>Phát triển chế phẩm và Quyết định mẫu xét nghiệm</h4>
									<p>Phòng kế hoạch và Viện nghiên cứu trung tâm</p>
								</li>
								<li>
									<h4>Phát triển thiết kế và Quyết định mẫu xét nghiệm </h4>
									<p>Phòng kế hoạch và Viện nghiên cứu trung tâm</p>
								</li>
								<li>
									<h4>Sản xuất</h4>
									<p>Phòng hỗ trợ sản xuất</p>
								</li>
								<li>
									<h4>Giao hàng</h4>
									<p>Phòng hỗ trợ sản xuất</p>
								</li>
							</ol>
						</div>
						<div class="img_con">
							<img src="/assets/images/product/odm_img_vn.png" />
						</div>
					</div>
					
					
					<div class="partners2" style="display:none">
						
						<ul>
							<li class="l">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="l t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
						</ul>
						
					</div>
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->