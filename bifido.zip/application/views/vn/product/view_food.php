<script type="text/javascript">


</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>Dành cho TẤT CẢ MỌI NGƯỜI <span>(Tự làm bữa sáng bằng probiotics)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bifidus_meal_img.png" />
							</div>
							<div class="txt_con">
								<h4>BIFIDUS MEAL</h4>
								<p>
									Bifidus meal chứa nồng độ cao <i>Bifidobacterium</i> sp đã được cấp bằng sáng chế, đặc biệt dành cho trẻ em. Là sữa chua dạng kem kiểu Hy Lạp, hãy chăm sóc cho đường ruột của trẻ.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/vn/popup/product_meal');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->