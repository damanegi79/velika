<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["zigunuk", "partners"];
		var idx =e.target.index();
		location.href = "/vn/product/probiotics/health?category="+linkAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">NHÃN HIỆU ZIGUNUK</a></li>
						<li><a href="javascript:">PARTNER'S BRAND</a></li>
					</ul>
				</div>
				<!-- //tab_pannel -->
				<div class="box mt50"></div>
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>CHO TRẺ <span>(3 - 36 Tháng)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bifiduc_baby_img.png" />
							</div>
							<div class="txt_con">
								<h4>ZIGUNUK BIFIDUS BABY</h4>
								<p>
									Đây là một sản phẩm dinh dưỡng cung cấp bifidus và có lợi cho đường ruột của trẻ từ 3 đến 36 tháng sau khi chào đời, được phát triển bởi nhóm nghiên cứu của Giáo sư Ji, Geun Eog tại Khoa Thực phẩm và Dinh dưỡng, Trường Đại học Quốc gia Seoul sử dụng Bifidobacterium sp. (BGN4, BORI) và <i>Lactobacillus acidophilus</i> được tách ra từ một trẻ sơ sinh khỏe mạnh.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/vn/popup/product_baby');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->

					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>Dành cho Phụ nữ <span>(Ăn kiêng và Có lợi cho đường ruột)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/slim_yogurtics_img.png" />
							</div>
							<div class="txt_con">
								<h4>SLIM YOGURTICS</h4>
								<p>
									Sự kết hợp hoàn hảo của Sữa chua và Probiotics. Tự tạo ra bữa sáng cho riêng mình bằng công thức phong phú và tươi ngon với sữa chua probiotics để có một đường ruột khỏe mạnh và vóc dáng thon thả.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/vn/popup/product_slim');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>DÀNH CHO NGƯỜI LỚN</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_bifidus_img.png" />
							</div>
							<div class="txt_con">
								<h4>ZIGUNUK BIFIDUS</h4>
								<p>
									Sản phẩm này có lợi cho đường ruột của người lớn, sản phẩm chứa probiotics được tách ra từ đường ruột của một trẻ sơ sinh khỏe mạnh như <i>Bifidobacterium</i> sp. (BGN4, BORI), Lactobacillus acidophilus và galacto-oligosaccharide (GOS), một yếu tố tăng trưởng của <i>Bifidobacterum</i> sp. Nó được phát triển bởi nhóm nghiên cứu của Giáo sư Ji, Geun Eog tại Khoa Thực phẩm và Dinh dưỡng, Trường Đại học Quốc gia Seoul.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/vn/popup/product_zigunuk');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_prog_img_en.png" />
							</div>
							<div class="txt_con">
								<h4>PRO G SYNBIOTICS</h4>
								<p>
									Sản phẩm này có lợi cho đường ruột của cả gia đình, sản phẩm có chứa probiotics được tách ra từ đường ruột của một trẻ sơ sinh khỏe mạnh như  <i>Bifidobacterium</i> sp. (BGN4, BORI) và <i>Lactobacillus acidophilus</i>. Ngoài ra, nó còn chứa hơn 3000 mg fructo-oligosaccharides (FOS)/khẩu phần ăn. Thực phẩm chức năng kép này được phát triển bởi nhóm nghiên cứu của Giáo sư Ji, Geun Eog tại Khoa Thực phẩm và Dinh dưỡng, Trường Đại học Quốc gia Seoul.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/vn/popup/product_prog');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->