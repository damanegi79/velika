<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});
	$(window).resize();
			
			
	function resizeImg( e )
	{
				
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>NHÃN HIỆU ZIGUNUK</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_fermented_ginseng_img.png" />
							</div>
							<div class="txt_con">
								<h4>NHÂN SÂM LÊN MEN ZIGUNUK</h4>
								<p>
									Hồng sâm lên men của BIFIDO được làm từ hồng sâm lên men bằng <i>Bifidobacterium</i>, chứa nhiều ginsenoside có hoạt tính sinh học như Rh1, Rh2 và hợp chất K.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/vivido_premium_img.png" />
							</div>
							<div class="txt_con">
								<h4>
									VIVIDO PREMIUM  VIVIDO PREMIUM<br />
									<span>Với bằng sáng chế sản phẩm ginsenoside có khả năng hấp thụ cao như Hợp chất K, Rh1, Rh2, Rg2 và Rg3.</span>
								</h4>
								<p>
									Sau nhiều năm nghiên cứu khoa học và phát triển sản phẩm tại Hàn Quốc, chúng tôi đã được cấp bằng sáng chế quy trình tự nhiên chiết xuất và sản xuất ginsenoside có khả năng hấp thụ cao - Hợp chất K, Rh1, Rh2, Rg2 và Rg3 từ chiết xuất rễ nhân sâm. VIVIDO chỉ là một chất cô đặc nhân sâm hoạt tính chứa các ginsenoside có khả năng hấp thụ cao này. Sản phẩm nên được sử dụng cho những người có hệ tiêu hóa yếu do tuổi già, ốm đau, căng thẳng hoặc chế độ ăn mất cân bằng.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->