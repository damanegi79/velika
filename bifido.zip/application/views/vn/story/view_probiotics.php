
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content story">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>PROBIOTICS & BIFIDUS</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- story_con -->
				
				<div class="story_con">
					<div class="probio_con">
						<h3>VỀ PROBIOTICS</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set">
								<img class="m_img" src="/assets/images/bifidus_story/probiotic_img2_vn.png" />
							</div>
						</div>
					</div>
				</div>
				<div class="story_con">
					<div class="probio_con">
						<h3>UỐNG BIFIDUS ĐỂ BẢO VỆ ĐƯỜNG RUỘT</h3>
						<div class="list_con2">
							<div class="list_set">
								<img class="m_img" src="/assets/images/bifidus_story/probiotic_img3_vn.png" />
							</div>
						</div>
					</div>
				</div>
				<div class="story_con no_mobile">
					<div class="probio_con">
						<h3>GIÁO DỤC VOD</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set">
								<img src="/assets/images/bifidus_story/comming_img2.png" />
							</div>
						</div>
					</div>
					<!-- 
					<div class="probio_con">
						<iframe allowfullscreen="" data-thumbnail-src="https://i.ytimg.com/s_vi/xC7hSuKVyYI/default.jpg?sqp=S3sdRv5G8Do&amp;rs=AOn4CLBcYa3LJ6wYcHfnnK8TeeduQFuNUg" frameborder="0" width="100%" height="660px" src="https://www.youtube.com/embed/S3sdRv5G8Do?feature=player_embedded&amp;wmode=opaque" ></iframe>
					</div>
					 -->
				</div>
				<!-- //story_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->