<script type="text/javascript">
$(function ()
{
	$(".history_set .current img").css({"position":"relative"});
	$(".history_set .old img").css({"position":"relative"});
	
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		TweenMax.to($(".history_set"), 0.8, {y:-$(".history_content").height()*idx, ease:Expo.easeInOut});
		TweenMax.to($(".history_top .top_set"), 0.6, {y:-$(".history_top").height()*idx, ease:Expo.easeInOut});
		if(idx == 1)
		{
			$(".history_top").css({})
			TweenMax.to($(".history_set .current img"), 0, {y:$(".history_content").height()/2});
			TweenMax.to($(".history_set .current img"), 1.2, {y:0, ease:Expo.easeInOut});
			$(".history_mobile .current").css({display:"block"});
			$(".history_mobile .old").css({display:"none"});
			
		}
		else
		{
			
			TweenMax.to($(".history_set .old img"), 0, {y:-$(".history_content").height()/2});
			TweenMax.to($(".history_set .old img"), 1.2, {y:0, ease:Expo.easeInOut});
			$(".history_mobile .current").css({display:"none"});
			$(".history_mobile .old").css({display:"block"});
		}
	});

});

</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			$this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>LỊCH SỬ CỦA BIFIDO</h4>
					<span class="line"></span>
				</div>
				
				<!-- tab_pannel -->
				<div class=tab_pannel>
					<ul>
						<li class="on"><a href="javascript:">1988 ~ 2003</a></li>
						<li><a href="javascript:">2004 ~ Hiện nay</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
					
				<!-- //main_title -->
				<!-- history -->
				<div class="history">
					
					<!-- history_con -->
					<div class="history_top">
						<div class="top_set">
							<div class="history_old">
								<div class="blind">
									<h4>1988~2003</h4>
									<p>the quickening period</p>
								</div>
								<img src="/assets/images/about_bifido/history_en_top_old.png" />
							</div>
							
							<div class="history_current">
								<div class="blind">
									<h4>2004~CURRENT</h4>
									<p>time of development</p>
								</div>
								<img src="/assets/images/about_bifido/history_en_top_current.png" />
							</div>
						</div>
					</div>
					<!-- //history_top -->
					
					<!-- history_content -->
					<div class="history_content">
						<div class="history_set">
							<div class="history_con old">
								<span class="line"></span>
								<ol class="blind">
									<li>
										<h4>1988</h4>
										<p>1988 Nghiên cứu độc lập về bifidus của Giáo sư Ji</p>
									</li>
									<li>
										<h4>1988 ~ Current</h4>
										<p>1989~nay Chúng tôi đã thực hiện nghiên cứu về bifidus trong 27 năm.</p>
									</li>
									<li>
										<h4>1999.10</h4>
										<p>Tháng 10, 1999, Công ty TNHH BIFIDUS được thành lập. (Seoul)</p>
									</li>
									<li>
										<h4>2001.06</h4>
										<p>Tháng 06, 2001, “Zigunuk Bifidus” được giới thiệu ra thị trường.</p>
									</li>
									<li>
										<h4>2002.12</h4>
										<p>Tháng 12, 2002, “Zigunuk Bifidus Baby’ được giới thiệu ra thị trường.</p>
									</li>
									<li>
										<h4>2003.03</h4>
										<p>Tháng 03, 2003, Phòng Nghiên cứu Quốc gia về probiotics được thành lập.</p>
									</li>
									<li>
										<h4>2003.09</h4>
										<p>Tháng 09, 2003, Nhà máy đầu tiên được thành lập.</p>
									</li>
								</ol>
								<img src="/assets/images/about_bifido/history_vn_old.png" />
							</div>
							
							<div class="history_con current">
								<span class="line"></span>
								<ol class="blind">
									<li>
										<h4>2006.03</h4>
										<p>Tháng 03, 2006, Được công nhận là cơ sở đạt chuẩn GMP của FDA Hàn Quốc.</p>
									</li>
									<li>
										<h4>2011.08</h4>
										<p>Tháng 08, 2011, Đạt chứng nhận Halal (L.acidophilus, L.paracasei, L.casei, L.fermentum, L.plantarum).Nghiên cứu cấp quốc tế và nghiên cứu lâm sàng được công bố.</p>
									</li>
									<li>
										<h4>2011.08</h4>
										<p>Tháng 08, 2011, Văn phòng tại Thượng Hải, Trung Quốc được mở cửa.</p>
									</li>
									<li>
										<h4>2013.03</h4>
										<p>Tháng 03, 2013, Nhà máy thứ hai được mở rộng.</p>
									</li>
									<li>
										<h4>2015.03</h4>
										<p>Thàng 03, 2015, Giấy chứng nhận Halal (B. bifidum BGN4, B.longum BORI, B.lactis AD011)</p>
									</li>
								</ol>
								<img src="/assets/images/about_bifido/history_vn_current.png" />
							</div>
						</div>
						<!-- //history_set -->
						<!-- history_mobile -->
						<div class="history_mobile">
							<div class="history_con old">
								<img src="/assets/images/about_bifido/history_vn_old_m.png" />
							</div>
							<div class="history_con current">
								<img src="/assets/images/about_bifido/history_vn_current_m.png" />
							</div>
						</div>
						<!-- //history_mobile -->
					</div>
					<!-- //history_content -->
					
				</div>
				<!-- //profile -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->