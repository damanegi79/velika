<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?v=3.exp&sensor=true"></script>
<script type="text/javascript">

var mapLoc = [{title:"BIFIDO", lat:37.6572383, lng:127.8254289}, 
              {title:"BIFIDO HANAM", lat:37.5534149, lng:127.1948418}, 
              {title:"BIFIDO SHANGHAI", lat:39.9532595, lng:116.4641173}];
var addrAr = ['<h4>Trụ sở</h4>\
              <p class="addr">23-16, Nonggongdanji-gil. Hongcheon-eup, Hongcheon-gun, Gangwon-do, Hàn Quốc.</p>\
              <p class="tel">SỐ ĐIỆN THOẠI : <a href="tel://+82-33-435-4962">+82-33-435-4962</a></p>\
              <p class="fax">FAX : +82-33-435-4963</p>', 
              '<h4>Văn phòng tại Hanam</h4>\
              <p class="addr">918 iTECO 150, Jojeong-daero, Hanam-si, Gyeonggi-do, Hàn Quốc.</p>\
              <p class="tel">SỐ ĐIỆN THOẠI : <a href="tel://+82-31-8027-8941">+82-31-8027-8941</a></p>\
              <p class="fax">FAX : +82-31-8027-8944</p>',
              '<h4>Văn phòng tại Thượng Hải</h4>\
              <p class="addr">A-2125 Oriental International Plaza, 85 Đường LouShanGuan, Quận Trường Ninh, Thượng Hải, Trung Quốc.</p>\
              <p class="tel">SỐ ĐIỆN THOẠI : 86-21-6278-2288 (225)</p>'];


$(function ()
{
	google.maps.event.addDomListener(window, 'load', initialiseMap);
	 
	$(window).resize(function ( e )
	{
		var len = $(".contact_con input[type='text']").length;
		$(".contact_con input[type='text']").each(function ( i )
		{
			if(i <len-1)
			{
				if(isMobile)
				{
					$(this).css({width:($(".contact_con").width())-38});
				}
				else
				{
					$(this).css({width:($(".contact_con").width()/2)-42});
				}
			}	
			else 
			{
				$(this).css({width:$(".contact_con").width()-198});
			}
		});
		$(".contact_con textarea").css({width:$(".contact_con").width()-38});
	});
	
	$("#mail_file").bind("change", function ( e )
	{
		$("#mail_file_addr").val($(this).val());
	});
	$(window).resize();

	$(".send_btn button").bind("click", function ( e )
	{
		if($("#mail_name").val() == "")
		{
			alert("Tên của bạn( bắt buộc )");
			$("#mail_name").focus();
			return;
		}

		if($("#mail_addr").val() == "")
		{
			alert("Địa chỉ email của bạn ( bắt buộc)");
			$("#mail_addr").focus();
			return;
		}
		
		if($("#mail_phone").val() == "")
		{
			alert("Số điện thoại di động ( bắt buộc ).");
			$("#mail_phone").focus();
			return;
		}
		
		if($("#mail_content").val() == "")
		{
			alert("Vui lòng nhập nội dung.");
			$("#mail_content").focus();
			return;
		}
		showLoading();

		if($("#mail_file").val())
		{
			$('#upload_form').append($("#mail_file"));	
			$('#upload_form').ajaxForm({success: function(data)
			{
			     if(data)
			     {
			    	 $("#upload_path").val(data);
			    	 sendMail();
			    	 
			   	 }
			     else 
			     {
			    	 alert("Tập tin đã vượt quá dung lượng.");
			    	 hideLoading();
			     }
			     
			     $('.file_con').append($("#mail_file"));
			     
			}});
			
			$('#upload_form').submit();
		}
		else 
		{
			sendMail();	
		}
		
	});

	
	
});

function resetInput()
{
	$("#mail_name").val("");
    $("#mail_addr").val("");
    $("#mail_company").val("");
    $("#mail_phone").val("");
    $("#mail_file_addr").val("");
    $("#mail_file").val("");
    $("#userfile").val("");
    $("#mail_content").val("");
    $("#upload_path").val("");
}

function sendMail()
{
	$('#mail_form').ajaxForm({success: function(data)
	{
	     if(data == "success")
	     {
	    	 alert("Chuyển thư hoàn thành.");
	   	 }
	     else 
	     {
	    	 alert("Chuyển thư thất bại.");
	     }
	     
	     hideLoading();
	     resetInput(); 
	     
	     $('.file_con').append($("#mail_file"));
		     
	}});
	
	$('#mail_form').submit();
}

function initialiseMap()
{
	
	var mapOptions = {
			zoom: 15, 
			minZoom: 6,
			maxZoom: 20,
			zoomControl:true,
			zoomControlOptions: {
				style:google.maps.ZoomControlStyle.DEFAULT
			},
			center: new google.maps.LatLng(mapLoc[0].lat, mapLoc[0].lng),
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			scrollwheel: true,
	}
	var map = new google.maps.Map(document.getElementById("g_map"), mapOptions);
	var infoAr = new Array();
	var markerAr = new Array();
	
	for(var i=0; i<$(mapLoc).length; i++)
	{
			var infowindow = new google.maps.InfoWindow( 
			{ 
				     content: addrAr[i], 
				     maxWidth: 320 
			});
			 
			infoAr.push(infowindow);

	}
	
	for(var i=0; i<$(mapLoc).length; i++)
	{
		var marker = new google.maps.Marker({ 
            position: new google.maps.LatLng(mapLoc[i].lat, mapLoc[i].lng), 
            map: map, 
            title: mapLoc[i].title,
            id:i
		});

		google.maps.event.addListener(marker, 'click', function( ) 
		{
			infoAr[this.id].open(map, this); 
		});
		
		markerAr.push(marker);
	};
	
	infoAr[0].open(map, markerAr[0]);
	
	
	
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		map.setCenter(new google.maps.LatLng(mapLoc[idx].lat+0.003, mapLoc[idx].lng));
		map.setZoom(15);	
		$(".addr_con").html(addrAr[idx]);		
		infoAr[idx].open(map, markerAr[idx]);
	});
}

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			$this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class=tab_pannel>
					<ul>
						<li class="on"><a href="javascript:">Trụ sở</a></li>
						<li><a href="javascript:">Văn phòng tại Hanam</a></li>
						<li><a href="javascript:">Văn phòng tại Thượng Hải</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
					
				<!-- //main_title -->
				<!-- contact_us -->
				<div class="contact_us">
					
					<!-- map_con -->
					<div class="map_con">
						<div id="g_map" class="g_map">
							
						</div>
						<div class="addr_con">
							<h4>Trụ sở</h4>
							<p class="addr">23-16, Nonggongdanji-gil. Hongcheon-eup, Hongcheon-gun, Gangwon-do, Hàn Quốc.</p>
							<p class="tel">SỐ ĐIỆN THOẠI : <a href="tel://+82-33-435-4962">+82-33-435-4962</a></p>
							<p class="fax">FAX : +82-33-435-4963</p>
						</div>
					</div>
					<!-- map_con -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>LIÊN HỆ VỚI CHÚNG TÔI</h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- "contact_con" -->
					<div class="contact_con">
						<form id="mail_form" name="send_mail" action="/sendmail" method="post">
						<fieldset>
						<legend>send mail form</legend>
							<div class="block">
								<span>
									<input id="mail_name" name="mail_name" type="text" placeholder="Mùa đông *">
								</span>
								<span class="ml15">
									<input id="mail_addr" name="mail_addr" type="text" placeholder="Email *">
								</span>
							</div>
							<div class="block">
								<span>
									<input id="mail_company" name="mail_company" type="text" placeholder="Công ty">
								</span>
								<span class="ml15">
									<input id="mail_phone" name="mail_phone" type="text" placeholder="Số điện thoại *">
								</span>
							</div>
							
							<div class="block">
								<span class="file">
									<input id="mail_file_addr" type="text" placeholder="Tài liệu đính kèm " disabled style="width:700px;background-color:#fff">
								</span>
								<span class="file">
									<span class="file_con" style="width:160px">
										<a href="javascript:"><span class="plus"></span>Tài liệu bổ sung</a>
										<input id="mail_file" name="userfile" type="file"></input>
									</span>
								</span>
							</div>
						
							<div class="block">
								<span>
									<textarea id="mail_content" name="mail_content" placeholder="Tin nhắn *"></textarea>
								</span>
							</div>
							
							<div class="send_btn">
								<button type="button">Gửi</button>
							</div>
							<input type="hidden" name="upload_path" id="upload_path">
						</fieldset>
						</form>
						<form id="upload_form" action="/sendmail/mail_upload" method="post" accept-charset="utf-8" enctype="multipart/form-data" style="display:none"></form>
					</div>
					<!-- "contact_con" -->
					
				</div>
				<!-- //contact_us -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->