
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>CHÚNG TÔI LÀM GÌ</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					Với tinh thần không ngại khó khăn vì một công nghệ tốt nhất, BIFIDO đang nỗ lực trở thành công ty nghiên cứu và phát triển công nghệ thực phẩm tốt nhất thế giới dựa trên probiotics.
				</div>
				<!-- //sub_title -->
				<!-- profile -->
				<div class="profile">
					<!-- profile_list -->
					<div class="profile_list">
						<ul>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon1.png" alt="Professional on bifidus" />
									</div>
									<h4 class="titl">Chuyên gia về bifidus</h4>
								</div>
								<div class="txt_con">
									<p>
										Chúng tôi tập trung vào nghiên cứu căn bản và phát triển sản phẩm bằng probiotics. Trong số nhiều loại probiotics, <i>Bifidobacterium</i> được coi là lợi khuẩn tốt nhất để duy trì sự cân bằng của vi khuẩn trong đường ruột. Ngày nay, <i>Bifidobacterium</i> và các vi khuẩn axit lactic khác đang được sử dụng rộng rãi trong nhiều loại thực phẩm chức năng. Đặc biệt, chúng tôi là nhà tiên phong trong việc phát triển <i>Bifidobacterium</i> cải thiện sức khỏe con người. 
									</p>
								</div>
							</li>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon2.png" alt="Business area" />
									</div>
									<h4 class="titl">Lĩnh vực kinh doanh</h4>
								</div>
								<div class="txt_con">
									<p>
										Chúng tôi sản xuất các nguyên liệu thô của nhiều loại probiotics và nhân sâm lên men bằng công nghệ độc quyền cũng như sản xuất thành phẩm nhãn hiệu ZIGUNUK và các sản phẩm ODM/EDM. Để mở rộng ứng dụng của probiotics trong đời sống hàng ngày, chúng tôi luôn nỗ lực hết sức để trở thành nhà tiên phong trong lĩnh vực thực phẩm có lợi cho sức khỏe dựa trên probiotics.
									</p>
								</div>
							</li>
							<li class="end">
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon3.png" alt="Research & Development" />
									</div>
									<h4 class="titl">Nghiên cứu và Phát triển</h4>
								</div>
								<div class="txt_con">
									<p>
										Ji, Geun Eog, CEO của Công ty TNHH BIFIDO, là một giáo sư khoa Thực phẩm và Dinh dưỡng tại Trường Đại học Quốc gia Seoul. Ông đã thực hiện các nghiên cứu về probiotics trong hơn 30 năm kể từ khóa học tiến sỹ tại Trường Đại học Bang Lousiana và sau tiến sỹ tại Trường Đại học Stanford. Hiện nay, ông là nhà nghiên cứu nổi tiếng thế giới về lĩnh vực vi sinh vật đường ruột và <span class="it">Bifidobacteria</span>. Phòng nghiên cứu của ông tại Trường Đại học Quốc gia Seoul được coi là Phòng Nghiên cứu Quốc gia trong lĩnh vực probiotics. Phòng Nghiên cứu Quốc gia này được thiết kế cho một nhóm nghiên cứu sở hữu công nghệ với lợi thế cạnh tranh quốc tế và được tài trợ bởi Bộ Khoa học và Công nghệ để thực hiện các dự án quan trọng của quốc gia trong 10 năm qua.
									</p>
								</div>
							</li>
						</ul>
					</div>
					<!-- //profile_list -->
				</div>
				<!-- //profile -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->