<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	
	$(".popup_frame .tab_pannel li a").bind("click", function ( e )
	{
		$(".popup_frame .tab_pannel li").removeClass("on");
		$(this).parent().addClass("on");
		
		var idx = $(this).parent().index();
		
		$(".popup_frame .tab_content li").css({display:"none"});
		$(".popup_frame .tab_content li").eq(idx).css({display:"block"});
	});
	resizeWindow();

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>ZIGUNUK BIFIDUS</h2>
		<div class="info_con">
			<div class="pop_list" style="overflow:hidden">
				<div style="float:left">
					<h4 class="title">THÀNH PHẦN</h4>
					<p class="tit">Probiotics</p>
					<div class="list_con">
						<ul>
							<li>2 triệu <i>Bifidobacterium bifidum</i> BGN4 :  1gói</li>
							<li>2 triệu <i>Bifidobacterium longum</i> BORI :  1gói</li>
							<li>400 triệu <i>Lactobacillus acidophilus</i> :  1gói</li>
						</ul>
					</div>
					<p class="tit mt20">Prebiotics</p>
					<div class="list_con">
						<ul>
							<li>Galacto-Oligosaccharide</li>
							<li>Fructo-Oligosaccharide</li>
						</ul>
					</div>
				</div>
				<!-- 
				<div class="video_con" style="float:right">
					<h4 class="title">RELEVANT VIDEO</h4>
					<div class="movie_con">
						<iframe allowfullscreen="" class="YOUTUBE-iframe-video" data-thumbnail-src="https://i.ytimg.com/s_vi/xC7hSuKVyYI/default.jpg?sqp=4CVLFiH7DQU&amp;rs=AOn4CLBcYa3LJ6wYcHfnnK8TeeduQFuNUg" frameborder="0" width="235" height="168" src="https://www.youtube.com/embed/4CVLFiH7DQU?feature=player_embedded&amp;wmode=opaque" ></iframe>
					</div>
				</div>
				-->
			</div>
			<div class="pop_list">
				<h4 class="title">THÀNH PHẦN DINH DƯỠNG (1 Khẩu phần ăn)</h4>
				<div class="list_con">
					<ul>
						<li>Calories :  10kcal</li>
						<li>Carbohydrate :  2g</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">HƯỚNG DẪN UỐNG</h4>
				<div class="intake_con zigunuk">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_zigunuk_img1_vn_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_zigunuk_img1_vn.png" />
						<?php endIf;?>
					</div> 
					<div class="blind">
						<ol>
							<li>Một gói/ngày khi bạn đang ở nhà hay ở nơi làm việc.</li>
							<li>2g/ngày trộn với nước hoặc chất lỏng khác.</li>
						</ol>
					</div>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">In</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">BẢO QUẢN</h4>
				<div class="stroage_con">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_zigunuk_img2_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_zigunuk_img2.png" />
						<?php endIf;?>
						
					</div>
					<p>
						Bảo quản sản phẩm này ở nơi lạnh và tối<br />, 
						tránh nhiệt độ cao và ánh nắng trực tiếp.<br />
						Nên bảo quản trong tủ lạnh để duy trì vi khuẩn sống.
					</p>
				</div>
				
			</div>
			<div class="pop_list">
				<h4 class="title">ĐẶC TÍNH</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">Sử dụng probiotics được cấp bằng sáng chế có nguồn gốc từ con người</span></li>
					<li><span class="num">02</span><span class="txt">Sự kết hợp hoàn hảo của bifidus và chủng lactobacillus</span></li>
					<li><span class="num">03</span><span class="txt">Kết hợp với prebiotics oligosaccharides</span></li>
					<li><span class="num">04</span><span class="txt">cải thiện sức khỏe đường ruột do lối sống không lành mạnh.</span></li>
				</ol>
				<div class="ac">
					
					<img class="charact_img" src="/assets/images/popup/product_zigunuk_img3_vn.png" />
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">NOTES</h4>
				
				<div class=tab_pannel>
					<ul>
						<li class="on"><a href="javascript:">NGƯỜI SỬ DỤNG</a></li>
						<li><a href="javascript:">CÁCH SỬ DỤNG</a></li>
						<li><a href="javascript:">HẠN SỬ DỤNG</a></li>
						<li><a href="javascript:">TẠI SAO CẦN SỬ DỤNG</a></li>
					</ul>
				</div>
				
				<div class=tab_content>
					<ul>
						<li>
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab1_vn_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab1_vn.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab2_vn_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab2_vn.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab3_vn_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab3_vn.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab4_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab4.png" />
							<?php endIf;?>
							<div class="story_btn">
								<span class="txt">Xem thêm chi tiết</span>
								<a href="/vn/story" style="width:210px">CÂU CHUYỆN CỦA BIFIDUS<span class="arrow"></span></a>
							</div>
						</li>
					</ul>
				</div>
				
			</div>
			<div class="pop_list last note_con">
				<h4 class="title">CHỨC NĂNG</h4>
				
				<div class="ac">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_zigunuk_img4_vn_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_zigunuk_img4_vn.png" />
					<?php endIf;?>
				</div>
			</div>
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>