<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>BIFIDUS MEAL</h2>
		<div class="info_con">
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left"'; ?>>
					<h4 class="title">THÀNH PHẦN</h4>
					<p class="tit">Probiotics</p>

					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium bifidum</i> BGN4</li>
							<li><i>Bifidobacterium longum</i> BORI</li>
							<li><i>Lactobacillus acidophilus</i> AD031</li>
						</ul>
					
					</div>
				</div>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:180px;padding-top:20px"'; ?>>
					<p class="tit mt20">Prebiotics</p>
					<div class="list_con">
						<ul>
							<li>Sợi rau diếp</li>
							<li>Resistant maltodextrin</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="pop_list">
				<div class="infi_slim">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_meal_img7_vn_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_meal_img7_vn.png" />
					<?php endIf;?>
				</div>
			</div>
			<div class="pop_list" style="overflow:hidden">
				<h4 class="title">THÀNH PHẦN DINH DƯỠNG (1 Khẩu phần ăn)</h4>
				
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;"'; ?>>
					<ul>
						
						<li>Calories: 55 kcal</li>
						<li>Carbohydrate: 16g</li>
						<li>Protein: 2g </li>
					
					</ul>
				
				</div>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:200px"'; ?>>
					<ul>
						<li>Chất béo: 1.5g</li>
						<li>Cholesterol:: :ít hơn 10mg</li>
						<li>Natri: 20mg</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">HƯỚNG DẪN UỐNG</h4>
				<div class="intake_con meal">
					<ul>
						<li>
							<div class="blind">
								<h4>SỮA CHUA HY LẠP</h4>
								<p>Bột 20g<br />Sữa 100ml</p>
								<div>
									<strong>HƯỚNG DẪN</strong>
									<ol>
										<li>Để tạo cảm giác có nhiều kem trong miệng, khuấy sữa bằng bột bifidus meal</li>
										<li>Bổ sung trái cây tươi, ngũ cốc, hạt hoặc trái cây khô, bạn sẽ có món bifidus meal giàu dinh dưỡng hơn!</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img1_vn.png" />
						</li>
						<li>
							<div class="blind">
								<h4>BÁNH PHÔ MAI</h4>
								<p>Bột 20g<br />Sữa 100ml</p>
								<div>
									<strong>HƯỚNG DẪN</strong>
									<ol>
										<li>Để hỗn hợp trong tủ lạnh từ 2-3 tiếng.</li>
										<li>Rắc trái cây hoặc mứt.</li>
										<li>Bánh phô mai bifidus meal cần được bảo quản ở nơi lạnh.</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img2_vn.png" />
						</li>
						<li>
							<div class="blind">
								<h4>KEM SỮA CHUA</h4>
								<p>Bột 20g<br />Sữa 100ml</p>
								<div>
									<strong>HƯỚNG DẪN</strong>
									<ol>
										<li>Thử thay sữa bằng Half & Half để làm kem probiotics ngon hơn.</li>
										<li>Bổ sung thêm trái cây hoặc hương vị bạn thích như dâu tây, chuối, socola, cà phê, trà xanh v.v.</li>
										<li>Rắc trái cây tươi hoặc hạt</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img3_vn.png" />
						</li>
						<li>
							<div class="blind">
								<h4>KEM SỮA CHUA</h4>
								<p>Bột 20g<br />Sữa 100ml</p>
								<div>
									<strong>HƯỚNG DẪN</strong>
									<ol>
										<li>Ít ngọt hơn. Có thể được sử dụng đối với nhiều loại bánh quy, bánh mì hoặc bánh ngọt.</li>
										<li>Bữa sáng dinh dưỡng, ngon miệng và dễ làm cho học sinh và người đi làm.</li>
										<li>Bữa ăn kiêng tốt và ngon cho phụ nữ.</li>
										<li>Thực phẩm có lợi cho người già.</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img4_vn.png" />
						</li>
					</ul>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">In</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">BẢO QUẢN</h4>
				<div class="stroage_con">
					<div class="img_con">
						<img src="/assets/images/popup/product_meal_img5.png" />
					</div>
					<p class="mt15">
						Tránh nơi có nhiệt độ cao và ánh nắng trực tiếp, bảo quản <br />
						sản phẩm này ở nơi lạnh hoặc trong tủ lạnh.
					</p>
				</div>
				
			</div>
			<div class="pop_list last">
				<h4 class="title">ĐẶC TÍNH</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">Bữa sáng tốt cho sức khỏe, lựa chọn tuyệt ngon.</span></li>
					<li><span class="num">02</span><span class="txt">Sữa chua giàu dinh dưỡng cho đường ruột.</span></li>
					<li><span class="num">03</span><span class="txt">Khỏe hơn. Ít ngọt hơn.</span></li>
					<li><span class="num">04</span><span class="txt">Chứa probiotics có nguồn gốc từ con người.</span></li>
					<li><span class="num">05</span><span class="txt">Bifidus meal khỏe mạnh với calorie thấp.</span></li>
				</ol>
				<div class="ac">
					<img class="charact_img" src="/assets/images/popup/product_meal_img6_vn.png" />
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>