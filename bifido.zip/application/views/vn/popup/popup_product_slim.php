<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>SLIM YOGURTICS</h2>
		<div class="info_con">
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left"'; ?>>
					<h4 class="title">THÀNH PHẦN</h4>
					<p class="tit">Probiotics</p>
					
					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium lactis</i> AD011</li>
							<li><i>Lactobacillus fermentum</i> BH03</li>
							<li><i>Lactobacillus acidophilus</i> AD031</li>
						</ul>
					
					</div>
					<p class="tit mt20">Slim yogurtics</p>
					
					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium bifidum</i> BGN4 powder</li>
							<li><i>Bifidobacterium longum</i> BORI powder</li>
							<li><i>Bifidobacterium lactis</i> AD011 powder</li>
							<li><i>Lactobacillus acidophilus</i> AD031 powder</li>
							<li><i>Lactobacillus fermentum</i> BH03 powder</li>
							<li><i>Enterococcus faecium</i> BH06 powder</li>
						</ul>
					
					</div>
				</div>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:180px;padding-top:20px"'; ?>>
					<p class="tit mt20">Dietary fiber & Oligosaccharide</p>
					<div class="list_con">
						<ul>
							<li>Indigestible maltodextrin (Souble fiber)</li>
							<li>Chicory fiber(Inulin)</li>
							<li>Galacto-oligosaccharide</li>
							<li>Fructo-oligosaccharide</li>
							<li>Xylo-oligosaccharide</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">Chiết xuất cây bứa</h4>
				
				<div class="list_con">
					<ul>
						
						<li>HCA(60%) :  840mg</li>
					
					</ul>
				
				</div>
			</div>
			<div class="pop_list">
				<div class="infi_slim">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_slim_img1_vn_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_slim_img1_vn.png" />
					<?php endIf;?>
					
				</div>
			</div>
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<h4 class="title">THÀNH PHẦN DINH DƯỠNG (1 khẩu phần ăn)</h4>
				
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;"'; ?>>
					<ul>
						<li>Calories :  20kcal</li>
						<li>Carbohydrates :  18g</li>
						<li>Protein :  0mg</li>	
					</ul>
				
				</div>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:200px"'; ?>>
					<ul>
						<li>Fat : 0mg</li>
						<li>Natri : 20mg</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">HƯỚNG DẪN UỐNG</h4>
				<div class="intake_con slim">
					<ul>
						<li>
							<div class="blind">
								<h4>SINH TỐ DÂU</h4>
								<div>
									<ol>
										<li>DÂU TÂY 2 PHẦN</li>
										<li>DÂU XANH 5 PHẦN</li>
										<li>SỮA 100ML</li>
										<li>BỘT SLIM YOGURTICS 20G (MỘT GÓI)</li>
										<li>2 CỤC ĐÁ</li>
									</ol>
								</div>
								<p>
									<strong>Hướng dẫn Sử dụng</strong><br />
									Đặt thành phần vào máy xay sinh tố và xay cho đến khi trở thành sinh tố.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img2_vn.png" />
						</li>
						<li>
							<div class="blind">
								<h4>SINH TỐ XANH</h4>
								<div>
									<strong>HƯỚNG DẪN</strong>
									<ol>
										<li>Bắp cải 1/8 cái</li>
										<li>Táo 1/2 quả, Bông cải xanh 25G</li>
										<li>Sữa 100ML</li>
										<li>Bột Slim yogurtics 20G (một gói)</li>
										<li>2 CỤC ĐÁ</li>
									</ol>
								</div>
								<p>
									<strong>Hướng dẫn Sử dụng</strong><br />
									Đặt thành phần vào máy xay sinh tố và xay cho đến khi trở thành sinh tố.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img3_vn.png" />
						</li>
						<li>
							<div class="blind">
								<h4>SINH TỐ NGŨ CỐC</h4>
								<div>
									<ol>
										<li>DIÊM MẠCH 25g</li>
										<li>GẠO LỨT 15G</li>
										<li>Black soybean 10g</li>
										<li>SỮA 100ML</li>
										<li>BỘT SLIM YOGURTICS 20G (MỘT GÓI)</li>
										<li>2 CỤC ĐÁ</li>
									</ol>
								</div>
								<p>
									<strong>Hướng dẫn Sử dụng</strong><br />
									Đặt thành phần vào máy xay sinh tố và xay cho đến khi trở thành sinh tố.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img4_vn.png" />
						</li>
						<li>
							<div class="blind">
								<h4>SINH TỐ HẠT</h4>
								<div>
									<strong>HƯỚNG DẪN</strong>
									<ol>
										<li>Hạnh nhân 3 phần</li>
										<li>Quả óc chó 3 phần</li>
										<li>Nho khô 3 phần</li>
										<li>Sữa 100ML</li>
										<li>Bột Slim yogurtics 20G (một gói)</li>
										<li>3 CỤC ĐÁ</li>
									</ol>
								</div>
								<p>
									<strong>Hướng dẫn Sử dụng</strong><br />
									Đặt thành phần vào máy xay sinh tố và xay cho đến khi trở thành sinh tố.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img5_vn.png" />
						</li>
					</ul>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">In</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">BẢO QUẢN</h4>
				<div class="stroage_con">
					<div class="img_con">
						<img src="/assets/images/popup/product_slim_img6.png" />
					</div>
					<p class="mt15">
						Tránh nơi có nhiệt độ cao và ánh nắng trực tiếp, <br />
						bảo quản sản phẩm này ở nơi lạnh hoặc trong tủ lạnh.
					</p>
				</div>
			</div>
			<div class="pop_list last">
				<h4 class="title">ĐẶC TÍNH</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">Sử dụng probiotics được cấp bằng sáng chế có nguồn gốc từ con người</span></li>
					<li><span class="num">02</span><span class="txt">Thức ăn dinh dưỡng dành cho ăn kiêng mà không cần lo lắng về calorie.</span></li>
					<li><span class="num">03</span><span class="txt">Thực phẩm chức năng tác động kép (ăn kiêng và có lợi cho đường ruột)</span></li>
					<li><span class="num">04</span><span class="txt">Chứa HCA 840mg.</span></li>
					<li><span class="num">05</span><span class="txt">Chứa 100 triệu probiotics.</span></li>
					<li><span class="num">06</span><span class="txt">Nhiều công thức có hương vị ngon để cải thiện vóc dáng.</span></li>
				</ol>
				<div class="ac">
					<img class="charact_img" src="/assets/images/popup/product_slim_img7_vn.png" />
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>