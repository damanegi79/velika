<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	
	$(".popup_frame .tab_pannel li a").bind("click", function ( e )
	{
		$(".popup_frame .tab_pannel li").removeClass("on");
		$(this).parent().addClass("on");
		
		var idx = $(this).parent().index();
		
		$(".popup_frame .tab_content li").css({display:"none"});
		$(".popup_frame .tab_content li").eq(idx).css({display:"block"});
	});
	resizeWindow();

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>ZIGUNUK BIFIDUS BABY</h2>
		<div class="info_con">
			<div class="pop_list" style="overflow:hidden">
				<div style="float:left">
					<h4 class="title">INGREDIENTS</h4>
					<p class="tit">Probiotics</p>
					<div class="list_con">
						<ul>
							<li>2 billion <i>Bifidobacterium bifidum</i> BGN4 :  1pack</li>
							<li>2 billion <i>Bifidobacterium longum</i> BORI :  1pack</li>
							<li>400 million <i>Lactobacillus acidophilus</i> :  1pack</li>
						</ul>
					</div>
					<p class="tit mt20">Prebiotics</p>
					<div class="list_con">
					<ul>
						<li>Galacto-Oligosaccaride</li>
						<li>Fructo-Oligosaccharide </li>
					</ul>
				</div>
				</div>
				<!-- 비디오 저작권 문제로 임시 주석처리 2015.09.21
				<div style="float:right" class="video_con">
					<h4 class="title">RELEVANT VIDEO</h4>
					<div class="movie_con">
						<iframe allowfullscreen="" class="YOUTUBE-iframe-video" data-thumbnail-src="https://i.ytimg.com/s_vi/xC7hSuKVyYI/default.jpg?sqp=4CVLFiH7DQU&amp;rs=AOn4CLBcYa3LJ6wYcHfnnK8TeeduQFuNUg" frameborder="0" width="235" height="168" src="https://www.youtube.com/embed/kbcHTgRMuOk?feature=player_embedded&amp;wmode=opaque" ></iframe>
					</div>
				</div>
				-->
			</div>
			<div class="pop_list">
				<h4 class="title">NUTRITION FACTS (1 Serving)</h4>
				<div class="list_con">
					<ul>
						<li>Calories :  5kcal</li>
						<li>Carbohydrate :  2g</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">INTAKE DIRECTIONS</h4>
				<div class="intake_con baby">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_baby_img1_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_baby_img1.png" />
						<?php endIf;?>
					</div>
					<div class="blind">
						<ol>
							<li>Mix 2g sachet with baby’s food such as water or other liquid and feed. </li>
						</ol>
					</div>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">PRINT</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">STORAGE</h4>
				<div class="stroage_con">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_baby_img2_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_baby_img2.png" />
						<?php endIf;?>
					</div>
					<p>
						Keep this product in a cold and dark place, avoiding high<br /> 
						temperature and direct sun light. It will be much better to <br />
						store in the refrigerator for maintaining live bacteria.
					</p>
				</div>
				
			</div>
			<div class="pop_list">
				<h4 class="title">CHARACTERISTICS</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">Use patented probiotics</span></li>
					<li><span class="num">02</span><span class="txt">Human-origin-High adherence activity</span></li>
					<li><span class="num">03</span><span class="txt">Combined with prebiotics oligosaccharides</span></li>
					<li><span class="num">04</span><span class="txt">Contain various vitamins</span></li>
				</ol>
				<div class="ac">
					<img class="charact_img" src="/assets/images/popup/product_baby_img3.png" />
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">NOTES</h4>
				
				<div class=tab_pannel>
					<ul>
						<li class="on"><a href="javascript:">WHO</a></li>
						<li><a href="javascript:">HOW</a></li>
						<li><a href="javascript:">HOW LONG</a></li>
						<li><a href="javascript:">WHY</a></li>
					</ul>
				</div>
				
				<div class=tab_content>
					<ul>
						<li>
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_baby_tab1_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_baby_tab1.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_baby_tab2_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_baby_tab2.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_baby_tab3_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_baby_tab3.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_baby_tab4_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_baby_tab4.png" />
							<?php endIf;?>
							<div class="story_btn">
								<span class="txt">see more details</span>
								<a href="/en/story">BIFIDUS STORY<span class="arrow"></span></a>
							</div>
						</li>
					</ul>
				</div>
				
			</div>
			<div class="pop_list last note_con">
				<h4 class="title">FUNCTION</h4>
				
				<div class="ac">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_baby_img4_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_baby_img4.png" />
					<?php endIf;?>
				</div>
			</div>
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>