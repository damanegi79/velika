<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>SLIM YOGURTICS</h2>
		<div class="info_con">
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left"'; ?>>
					<h4 class="title">INGREDIENTS</h4>
					<p class="tit">Probiotics</p>
					
					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium lactis</i> AD011</li>
							<li><i>Lactobacillus fermentum</i> BH03</li>
							<li><i>Lactobacillus acidophilus</i> AD031</li>
						</ul>
					
					</div>
					<p class="tit mt20">Slim yogurtics</p>
					
					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium bifidum</i> BGN4 powder</li>
							<li><i>Bifidobacterium longum</i> BORI powder</li>
							<li><i>Bifidobacterium lactis</i> AD011 powder</li>
							<li><i>Lactobacillus acidophilus</i> AD031 powder</li>
							<li><i>Lactobacillus fermentum</i> BH03 powder</li>
							<li><i>Enterococcus faecium</i> BH06 powder</li>
						</ul>
					
					</div>
				</div>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:180px;padding-top:20px"'; ?>>
					<p class="tit mt20">Dietary fiber & Oligosaccharide</p>
					<div class="list_con">
						<ul>
							<li>Indigestible maltodextrin (Souble fiber)</li>
							<li>Chicory fiber(Inulin)</li>
							<li>Galacto-oligosaccharide</li>
							<li>Fructo-oligosaccharide</li>
							<li>Xylo-oligosaccharide</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">Garcinia cambogia extract</h4>
				<div class="list_con">
					<ul>
						<li>HCA(60%) :  840mg</li>
					</ul>
				</div>
			</div>
			<div class="pop_list">
				<div class="infi_slim">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_slim_img1_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_slim_img1.png" />
					<?php endIf;?>
					
				</div>
			</div>
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<h4 class="title">NUTRITION FACTS (1 Serving)</h4>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;"'; ?>>
					<ul>
						<li>Calories :  20kcal</li>
						<li>Carbohydrates :  18g</li>
						<li>Protein :  0mg</li>					</ul>
				</div>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:200px"'; ?>>
					<ul>
						<li>Fat : 0mg</li>
						<li>Sodium : 20mg</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">INTAKE DIRECTIONS</h4>
				<div class="intake_con slim">
					<ul>
						<li>
							<div class="blind">
								<h4>BERRY SMOOTHIES</h4>
								<div>
									<ol>
										<li>Strawberry 2ea</li>
										<li>Blueberry 5ea</li>
										<li>Milk 100ml</li>
										<li>Slim yogurticspowder 20g(one stick)</li>
										<li>Ice 2pcs</li>
									</ol>
								</div>
								<p>
									<strong>DIRECTIONS</strong><br />
									Put ingredients into a blender and blend until it becomes smoothies.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img2.png" />
						</li>
						<li>
							<div class="blind">
								<h4>GREEN SMOOTHIES</h4>
								<div>
									<strong>tips</strong>
									<ol>
										<li>Cabbage 1/8ea</li>
										<li>Apple 1/2ea</li>
										<li>Broccoli 25g</li>
										<li>Milk 100ml</li>
										<li>Slim yogurtics powder 20g (one stick)</li>
										<li>Ice 2pcs</li>
									</ol>
								</div>
								<p>
									<strong>DIRECTIONS</strong><br />
									Put ingredients into a blender and blend until it becomes smoothies.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img3.png" />
						</li>
						<li>
							<div class="blind">
								<h4>GRAIN SMOOTHIES</h4>
								<div>
									<ol>
										<li>Quinoa 25g</li>
										<li>Brown rice 15g</li>
										<li>Black soybean 10g</li>
										<li>Milk 100ml</li>
										<li>Slim yogurtics powder 20g (one stick)</li>
										<li>Ice 2pcs</li>
									</ol>
								</div>
								<p>
									<strong>DIRECTIONS</strong><br />
									Put ingredients into a blender and blend until it becomes smoothies.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img4.png" />
						</li>
						<li>
							<div class="blind">
								<h4>NUTS SMOOTHIES</h4>
								<div>
									<strong>tips</strong>
									<ol>
										<li>Almond 3ea</li>
										<li>Walnut 3ea</li>
										<li>Dried grape 3ea</li>
										<li>Milk 100ml</li>
										<li>Slim yogurtics powder 20g (one stick)</li>
										<li>Ice 3pcs</li>
									</ol>
								</div>
								<p>
									<strong>DIRECTIONS</strong><br />
									Put ingredients into a blender and blend until it becomes smoothies.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img5.png" />
						</li>
					</ul>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">PRINT</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">STORAGE</h4>
				<div class="stroage_con">
					<div class="img_con">
						<img src="/assets/images/popup/product_slim_img6.png" />
					</div>
					<p class="mt15">
						Avoid a place under the high temperature and direct sunlight<br />
						to keep this product in a cold place or refrigerator.
					</p>
				</div>
			</div>
			<div class="pop_list last">
				<h4 class="title">CHARACTERISTICS</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">Use patented probiotics origin from human</span></li>
					<li><span class="num">02</span><span class="txt">Diet nutritional snack without worry about calorie.</span></li>
					<li><span class="num">03</span><span class="txt">Double-funtional health food (diet and gut health)</span></li>
					<li><span class="num">04</span><span class="txt">Contain HCA 840mg</span></li>
					<li><span class="num">05</span><span class="txt">Contain 100million probiotic</span></li>
					<li><span class="num">06</span><span class="txt">Various slim recipes with good taste.</span></li>
				</ol>
				<div class="ac">
					<img class="charact_img" src="/assets/images/popup/product_slim_img7.png" />
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>