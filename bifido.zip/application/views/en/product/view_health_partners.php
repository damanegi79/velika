<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["zigunuk", "partners"];
		var idx =e.target.index();
		location.href = "/en/product/probiotics/health?category="+linkAr[idx];
	});			
});

</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">ZIGUNUK BRAND</a></li>
						<li class="on"><a href="javascript:">PARTNER'S BRAND</a></li>
					</ul>
				</div>
				<!-- //tab_pannel -->
				<div class="box mt50"></div>
				<!-- main_title -->
				<div class="main_title first" >
					<h4>PARTNER’S BRAND</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				
				<!-- product_con -->
				<div class="product_con">
					<div class="partners1">
						<div class="blind">
							<h2>ODM PROCESS</h2>
							<ol>
								<li>
									<h4>Demand by customer</h4>
								</li>
								<li>
									<h4>Consult about business</h4>
									<p>Sales department & central institute of research</p>
								</li>
								<li>
									<h4>Conclude the contract</h4>
									<p>Sales department</p>
								</li>
								<li>
									<h4>Develop preparations & Decide on specimen</h4>
									<p>Planning department & central institute of research</p>
								</li>
								<li>
									<h4>Develop design & Decide on specimen</h4>
									<p>Production department & central institute of research</p>
								</li>
								<li>
									<h4>Produce</h4>
									<p>Production department & central institute of research</p>
								</li>
								<li>
									<h4>Deliver</h4>
									<p>Production support department</p>
								</li>
							</ol>
						</div>
						<div class="img_con">
							<img src="/assets/images/product/odm_img.png" />
						</div>
					</div>
					
					
					<div class="partners2" style="display:none">
						
						<ul>
							<li class="l">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="l t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
						</ul>
						
					</div>
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->