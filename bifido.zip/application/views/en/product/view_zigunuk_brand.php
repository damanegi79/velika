<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});
	$(window).resize();
			
			
	function resizeImg( e )
	{
				
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>ZIGUNUK BRAND</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_fermented_ginseng_img.png" />
							</div>
							<div class="txt_con">
								<h4>ZIGUNUK FERMENTED GINSENGM</h4>
								<p>
									BIFIDO’s fermented red ginseng is made of fermented red ginseng by <i>Bifidobacterium</i>, which contains high level of bioactive ginsenosides such as Rh1, Rh2 and compound K.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/vivido_premium_img.png" />
							</div>
							<div class="txt_con">
								<h4>
									VIVIDO PREMIUM<br />
									<span>With the patent of producing highly absorbable ginsenoside Compound K, Rh1, Rh2, Rg2 and Rg3.</span>
								</h4>
								<p>
									After many years of scientific research and product development in Korea, we have patented a natural<br />
									process to extract and produce the highly absorbable ginsenosides – Compound K, Rh1 & Rh2 , Rg2 &Rg3<br />
									from Panax ginseng root extract. Vivido is the only activated ginseng concentrate containing these highly<br />
									absorbable ginsenosides. It is highly recommended for those with a weak digestion system due to old<br />
									age, sickness, stress, and unbalanced diet.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->