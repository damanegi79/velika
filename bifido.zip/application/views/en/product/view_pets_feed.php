<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});

	$(window).resize();
	
	

	function resizeImg( e )
	{
		
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>PET’S PROBIOTICS</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/real_bifidus_img.png" />
							</div>
							<div class="txt_con">
								<h4>REAL BIFIDUS (FOR PET)</h4>
								<p>
									We recommend Real BIFIDUS since it is a pet-specific formula (it was manufactured and formulated specifically for pets, which is important).  This probiotics supplement contains strains, species, and CFU amounts of live probiotics which are good for your pet health. With BIFIDO unique small tablet technique, feed you lovely pets easier!
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/real_bifidus_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->


						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/cat_img.png" />
							</div>
							<div class="txt_con">
								<h4>REAL BIFIDUS CAT</h4>
								<p>
									REAL BIFIDUS CAT is a full strength combination of essential nutrients with probiotics in a tasty chewable tablet for your cat. This probiotics supplement was formulated specifically for cats by adding taurine and <br />
									L-lysine which are essential amino acids to cats. 
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/cat_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->						
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/cd7_img.png" />
							</div>
							<div class="txt_con">
								<h4>CD7 (FOR CHICKEN)</h4>
								<p>
									CD7 contains 4 kinds of plant source (kimchi) <i>lactobacilli</i> and 3 kinds of <i>bifidobacterium</i>, which can increase the good bacteria and decrease the bad bacteria in chickens’ gastrointestinal tracts.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/cd7_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/k9_img.png" />
							</div>
							<div class="txt_con">
								<h4>K9 (FOR COW)</h4>
								<p>
									K9 contains three kinds of <i>bifidobacteria</i> and two kinds of <i>lactobacilli</i> which are formulated to modulate the balance and activities of the gastrointestinal microbiota of cows.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/k9_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/mr6_img.png" />
							</div>
							<div class="txt_con">
								<h4>MR.6 (FOR FISH)</h4>
								<p>
									MR. 6 contains three kinds of plant sources <i>lactobacilli</i> and three kinds of <i>bifidobacteria</i> which are formulated to modulate the balance and activities of the gastrointestinal microbiota of fish.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/mr6_info.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->