<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});
	$(window).resize();
			
			
	function resizeImg( e )
	{
				
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>COSMETICS</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bori_detox_cream_img.png" />
							</div>
							<div class="txt_con">
								<h4>BORI DETOX CREAM</h4>
								<p>
									Revitalized skin with the perfect combination of bifida ferment lysate, fermented ginseng and fermented skullcap.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bori_detox_serum_img.png" />
							</div>
							<div class="txt_con">
								<h4>BORI DETOX SERUM</h4>
								<p>
									Combine natural components probiotics and fermented plant extracts without alcohol, synthetic pigments. Closer to natural, healthier!
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/pbs_img.png" />
							</div>
							<div class="txt_con">
								<h4>PBS (PROBIOTICS BEAUTY SOLUTION)</h4>
								<p>
									Eatable cosmetics, healthier! To realize the inner and outer beauty by BORI AR81 PBS(Probiotics Beauty Solution).
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->