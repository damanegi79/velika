<script type="text/javascript">


</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>FOR ALL <span>(DIY Probiotics breakfast)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bifidus_meal_img.png" />
							</div>
							<div class="txt_con">
								<h4>BIFIDUS MEAL</h4>
								<p>
									Bifidus meal contains a high concentration of patented <i>Bifidobacterium</i> sp, specially for baby. As a creamy greek style yogurt, take care of baby's gut health. 
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/en/popup/product_meal');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->