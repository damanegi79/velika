<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["zigunuk", "partners"];
		var idx =e.target.index();
		location.href = "/en/product/probiotics/health?category="+linkAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">ZIGUNUK BRAND</a></li>
						<li><a href="javascript:">PARTNER'S BRAND</a></li>
					</ul>
				</div>
				<!-- //tab_pannel -->
				<div class="box mt50"></div>
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>FOR BABIES <span>(3 - 36 Months)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bifiduc_baby_img.png" />
							</div>
							<div class="txt_con">
								<h4>ZIGUNUK BIFIDUS BABY</h4>
								<p>
									This is a bifidus nutrient and intestinal regulation product for a baby who is three months to 36 months old after born, which was developed by the research team of Professor Ji, Geun Eog at the Food and Nutrition Department of Seoul National University by using the <i>Bifidobacterium</i> sp. (BGN4, BORI) and <i>Lactobacillus acidophilus</i> isolated from a healthy infant.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/en/popup/product_baby');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->

					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>FOR WOMAN <span>(Diet & Gut health)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/slim_yogurtics_img.png" />
							</div>
							<div class="txt_con">
								<h4>SLIM YOGURTICS</h4>
								<p>
									The prefect combination of Yogurt and Probiotics. DIY your own style breakfast with various delicious recipes by yogurtics to realize healthy gut and slender figure at the same time!
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/en/popup/product_slim');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>FOR ADULTS</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_bifidus_img.png" />
							</div>
							<div class="txt_con">
								<h4>ZIGUNUK BIFIDUS</h4>
								<p>
									This product is for intestinal health of adults containing probiotics isolated from a healthy infant intestine such as <i>Bifidobacterium sp. (BGN4, BORI), Lactobacillus acidophilus</i> and galacto-oligosaccharide (GOS), a growth factor of <i>Bifidobacterium</i> sp. It was developed by the research team of Professor Ji, Geun Eog at the Department of Food & Nutrition, Seoul National University. 
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/en/popup/product_zigunuk');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_prog_img_en.png" />
							</div>
							<div class="txt_con">
								<h4>PRO G SYNBIOTICS</h4>
								<p>
									This probiotics product is for intestinal health of the whole family containing probiotics isolated from a healthy infant such as <i>Bifidobacterium</i> sp. (BGN4, BORI) and <i>Lactobacillus acidophilus</i>. Apart from that, it contains more than 3000 mg fructo-oligosaccharides (FOS) per serving. This double functional health food was developed by the research team of Professor Ji, Geun Eog at the Department of Food & Nutrition, Seoul National University.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/en/popup/product_prog');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->