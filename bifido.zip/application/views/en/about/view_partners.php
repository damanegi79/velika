
<script type="text/javascript">
var pointAr = [{top:209, left:758}, 
            	  {top:253, left:752}, 
            	  {top:206, left:712}, 
            	  {top:247, left:723}, 
            	  {top:277, left:719}, 
            	  {top:304, left:702}, 
            	  {top:236, left:560}, 
            	  {top:205, left:554}, 
            	  {top:146, left:543}, 
            	  {top:173, left:525}, 
            	  {top:173, left:496}, 
            	  {top:190, left:244}];

var mapAr = [{top:209, left:758}, 
             {top:253, left:752}, 
             {top:193, left:647}, 
             {top:234, left:612}, 
             {top:265, left:633}, 
             {top:304, left:596}, 
             {top:236, left:480}, 
             {top:205, left:465}, 
             {top:131, left:543}, 
             {top:173, left:525}, 
             {top:173, left:404}, 
             {top:190, left:197}];

$(function()
{
	
	for(var i = 0; i<pointAr.length;i++)
	{
		$(".map_pointer").append("<a class='map_point_"+i+"' href='javascript:' style='left:"+pointAr[i].left+"px;top:"+pointAr[i].top+"px'></a>");
	}

	for(var i=0; i<mapAr.length; i++)
	{
		$(".map_pointer").append("<img class='map_img_"+i+"' src='/assets/images/about_bifido/partner_map"+i+".png' style='left:"+mapAr[i].left+"px;top:"+mapAr[i].top+"px'></img>");
	}
	
	$(".map_pointer a").bind("mouseover", function ()
	{
		var img = $(".map_pointer .map_img_"+$(this).index());
		img.css({visibility:"visible"});
		TweenMax.to(img, 0.4, {opacity:1});	
	});

	$(".map_pointer img").bind("mouseout", function ()
	{
		var img = $(this);
		img.css( {visibility:"hidden", opacity:0});
	});
});
</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			$this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>INTERNATIONAL PARTNERS</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				
				<!-- partners -->
				<div class="partners">
					<!-- map_con -->
					<div class="map_con">
						<div class="map_img">
							<img class="m_img" src="/assets/images/about_bifido/map_bg.png" />
						</div>
						<div class="map_pointer">
							
						</div>
					</div>
					<!-- //map_con -->
					
					<!-- "txt_con" -->
					<p class="txt_con">
						BIFIDO is providing high-quality products and raw materials, which are being sold in more than 10 countries all over the world. With our excellent quality and technical skills, BIFIDO is steadily expanding markets into Southeast Asia, America and Europe as well.
					</p>
					<!-- //"txt_con" -->
					
					<div class="country_con">
						<ul>
							<li><img src="/assets/images/flags/flag_korea.png" /><span>KOREA</span></li>
							<li><img src="/assets/images/flags/flag_china.png" /><span>CHINA</span></li>
							<li><img src="/assets/images/flags/flag_hongkong.png" /><span>HONG KONG</span></li>
						</ul>
						<ul>	
							<li><img src="/assets/images/flags/flag_vietnam.png" /><span>VIETNAM</span></li>
							<li><img src="/assets/images/flags/flag_singapore.png" /><span>SINGAPORE</span></li>
							<li><img src="/assets/images/flags/flag_jordan.png" /><span>JORDAN</span></li>
		                 </ul>   
		                 <ul>   
		                 	<li><img src="/assets/images/flags/flag_lituania.png" /><span>LITUANIA</span></li>
							<li><img src="/assets/images/flags/flag_poland.png" /><span>POLAND</span></li>
							<li><img src="/assets/images/flags/flag_germany.png" /><span>GERMANY</span></li>   
						</ul>
						<ul>
							<li><img src="/assets/images/flags/flag_taiwan.png" /><span>Taiwan</span></li>
							<li><img src="/assets/images/flags/flag_turkey.png" /><span>Turkey</span></li>
							<li><img src="/assets/images/flags/flag_usa.png" /><span>USA</span></li>
		                </ul>
					</div>
					
				</div>
				<!-- //partners -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->