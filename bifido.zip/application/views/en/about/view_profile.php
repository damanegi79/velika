
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>WHAT WE DO</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					With the challenging spirit for the best technology of Biotech, BIFIDO is trying to be the world best in probiotics based food technology.
				</div>
				<!-- //sub_title -->
				<!-- profile -->
				<div class="profile">
					<!-- profile_list -->
					<div class="profile_list">
						<ul>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon1.png" alt="Professional on bifidus" />
									</div>
									<h4 class="titl">Professional on bifidus</h4>
								</div>
								<div class="txt_con">
									<p>
										We focus on basic research and product development using probiotics. Among various probiotics, <i>Bifidobacterium</i> is considered to be the most beneficial microorganism for the maintenance of microbial balance in the intestinal tract. Nowadays <i>Bifidobacterium</i> and other lactic acid bacteria are being applied widely in functional foods. Especially, we are at the leading edge in the development of human-health promoting <i>Bifidobacterium</i>.
									</p>
								</div>
							</li>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon2.png" alt="Business area" />
									</div>
									<h4 class="titl">Business area</h4>
								</div>
								<div class="txt_con">
									<p>
										We produce raw materials of various probiotics and fermented ginseng by our own technology, and manufacture finished product of ZIGUNUK brand and OEM/ODM products. To extend the application of probiotics into our daily life, we are always trying our best to be the leading edge on probiotics health food area.
									</p>
								</div>
							</li>
							<li class="end">
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon3.png" alt="Research & Development" />
									</div>
									<h4 class="titl">Research & Development</h4>
								</div>
								<div class="txt_con">
									<p>
										Ji, Geun Eog CEO of BIFIDO Co. Ltd. is a professor of Food and Nutrition at Seoul National University. He performed researches on probiotics over 30 years ever since his PhD course at Louisiana State University and Post Doc at Stanford University. Currently, he is a world-renowned researcher concentrating in the area of intestinal microorganisms and <span class="it">Bifidobacteria</span>. His lab at Seoul National University was designated as the National Research Lab in the area of probiotics. National Research Laboratory is designated to a research team possessing technology with an international competitive edge and sponsored by the Ministry of Science and Technology to perform major national projects for 10 years.
									</p>
								</div>
							</li>
						</ul>
					</div>
					<!-- //profile_list -->
				</div>
				<!-- //profile -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->