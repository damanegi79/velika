
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>HONOR</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- download -->
				<div class="download">
					<!-- sub_title -->
					<h4 class="sub_title">HONOR</h4>
					<!-- //sub_title -->
					
					<!-- down_list -->
					<div class="down_list">
						<ul>
							<?php $count=0; ?>
							<?php foreach($pdf_list as $list): ?>
							<?php if($list->usedEn == TRUE):?>
							<li class="<?php if($count%2=="0"){echo 'l';}?> <?php if($count>1){ echo 't';}?>">
								<div class="tit_con">
									<span class="pdf emt">pdf</span>
									<span class="title"><?=$list->titleEn?></span>
								</div>
								<div class="btn_con">
									<a href="<?=$list->filePath?>" target="_blank"><span>DOWNLOAD</span></a>
								</div>
							</li>
							<?php $count++; ?>
							<?php endif;?>
							<?php endforeach;?>
						</ul>
					</div>
					<!-- //down_list -->
										
				</div>
				<!-- //download -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->