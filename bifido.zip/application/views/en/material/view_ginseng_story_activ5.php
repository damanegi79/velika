<script type="text/javascript">

$(function ()
{
	var selectNum = 0;
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/en/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});

	$(".activ_list li").each(function ( i )
	{
		$(this).find("a").bind("click", function ( e )
		{
			changeActiv5($(this).parent().index());
		});
	});

	changeActiv5(0);

	function changeActiv5( idx )
	{
		$(".activ_list li").each(function ( i )
		{
			if(idx == i)
			{
				$(this).css({opacity:1});
			}
			else
			{
				$(this).css({opacity:0});
			}
		});
		$(".activ_info .info_con").css({display:"none"});
		$(".activ_info .info_con").eq(idx).css({display:"block"});
		
		selectNum = idx;
	}

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".activ_info .info_con").css({display:"block"});
		}
		else
		{
			changeActiv5(selectNum);
		}
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1.png" /></div>
								<h4>FERMENTED GINSENG</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2_on.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4>BIFIDO COMPETITIVE</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>RESEARCH STUDY</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<p>
							By fermenting ginseng, glycoside ginsenoside, is converted into non glycoside ginsenoside. In other words, sugars, attached to ginsenoside, are metabolized by <i>Bifidobacterium</i> and converted into small sized ginsenoside aglycone.
The fermented ginseng contains high concentration of Compound K, Rh1, Rh2, Rg5, Rk1, PPD, PPT and ginsenosides with various effects. Their high ratio of body absorption maximize each efficiency in pharmacology.
							<br /><br />
							The fermented ginseng contains high concentration of Compound K, PPD, PPT and ginsenoside with efficient effects, such as Rh1, Rh2, Rg5, Rk1, so its body taking ratio is high and it is expected to maximize its efficiency in pharmacology
						</p>	
					</div>
					
					<div class="fermented_list">
						<div class="list_page">
							<h3>MEDICAL EFFECTS OF GINSENOSIDES</h3>
							<div class="line2"></div>
							<div class="activ_list">
								<h4 class="blind">ginsenosides</h4>
								<div class="menu_con">
									<ul>
										<li style="top:-154px;left:-78px"><a href="javascript:">RG1</a></li>
										<li style="top:-154px;left:86px"><a href="javascript:">RG2</a></li>
										<li style="top:-32px;left:149px"><a href="javascript:">RG3</a></li>
										<li style="top:90px;left:85px"><a href="javascript:">C.K</a></li>
										<li style="top:90px;left:-77px"><a href="javascript:">RH1</a></li>
										<li style="top:-32px;left:-141px"><a href="javascript:">RH2</a></li>
									</ul>
								</div>
							</div>
							<div class="activ_info">
								<div class="info_con">
									<h2>RG1</h2>
									<div class="list_set">
										<ul>
											<li>Enhance immunity</li>
											<li>Prevent blood platelets coagulation</li>
											<li>Increase memory power</li>
										</ul>
										<ul>
											<li>Relieve from fatigue and stress</li>
											<li>Stimulate nervous system</li>
											<li>Promote cell division and DNS synthesis</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RG2</h2>
									<div class="list_set">
										<ul>
											<li>Prevent blood platelet coagulation</li>
											<li>Increase memory power</li>
											<li>Modulate intracellular calcium influx</li>
										</ul>
										<ul>
											<li>Induce acetylcholine secretion</li>
											<li>Inhibit excess catecholamine production</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RG3</h2>
									<div class="list_set">
										<ul>
											<li>Inhibition of cancer cell  proliferation</li>
											<li>Inhibition of intravascular blood coagulation</li>
											<li>Act as a anti-cancer medicine</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>Compound K</h2>
									<div class="list_set">
										<ul>
											<li>Suppression of tumor cell proliferation and<br />inflammation</li>
											<li>Cytotoxicity against some tumor cells</li>
											<li>Anti-carcinogenic and anti-cancer effects</li>
											<li>Anti-allergy effects</li>
										</ul>
										<ul>
											<li>Alleviation of Alzheimer’s disease</li>
											<li>Anti-diabetic and anti-oxidant factors</li>
											<li>Promotion of insulin secretion</li>
											<li>Hepato-protective and skin-protective effect</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RH1</h2>
									<div class="list_set">
										<ul>
											<li>Anti-allergy effect</li>
											<li>Anti-inflammation effect</li>
											<li>Cytotoxic effects on various cancer cell lines</li>
										</ul>
										<ul>
											<li>Prevention of tumor cell proliferation<br />and differentiation</li>
											<li>Inhibition of liver disease promotion</li>
											<li>Prevention of blood platelet coagulation</li>
										</ul>
									</div>
								</div>
								<div class="info_con" style="display:none">
									<h2>RH2</h2>
									<div class="list_set">
										<ul>
											<li>Prevention of tumor cell proliferation and<br />differentitaion</li>
											<li>Anti-inflammatory effect</li>
										</ul>
										<ul>
											<li>Anti-allergy effect</li>
											<li>Promotion of insulin secretion and<br />improvement insulin sensitivity</li>
										</ul>
									</div>
								</div>
							</div>
							<div class="line2 mt40"></div>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->