<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/en/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1.png" /></div>
								<h4>FERMENTED GINSENG</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3_on.png" /></div>
								<h4>BIFIDO COMPETITIVE</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>RESEARCH STUDY</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<p class="list">Papered beneficial health functions</p>
						<p class="list">High concentration of small sized ginsenosides</p>
					</div>
					
					<div class="fermented_list">
						<div class="list_page">
							<h3>BIFIDO ACTIVE G5</h3>
							
							<div class="line2"></div>
							
							<div class="g5_list">
								<ul class="blind">
									<li>Support the Immune System</li>
									<li>Enhance Physical Energy</li>
									<li>Bodily Stamina and Fatigue Resistance</li>
									<li>Support Memory Functions</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img1.png" />
							</div>

							<div class="g5_list_2">
								<ul class="blind">
									<li>GINSENG</li>
									<li>FERMENTED GINSENG</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img2.png" /><br /><br />
								<p>
									By fermenting ginseng, glycoside ginsenoside is converted into non glycoside ginsenoside. In other words, glucose, attached into saponin, is metabolized by specific probiotic <i>Bifidobacterium</i> and converted into small sized ginsenoside.
									<br /><br />
									The fermented ginseng contains high concentration of compounds such as Compound K, Rh1, Rh2, Rg1 and Rg2 with enhanced biological activities.
								</p><br />
								<h4>Comparison of fermented ginseng ACTIVE G5 and ginseng extract</h4><br />
								<img class="m_img" src="/assets/images/raw_material/g5_img3.png" /> 
							</div>
							
							<div class="line2 mt40"></div>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->