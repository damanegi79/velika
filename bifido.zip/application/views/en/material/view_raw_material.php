<script type="text/javascript">

$(function ()
{
	$(".intro_list").each(function ( i )
	{
		var left = $(".probiotics").width()*i;
		$(this).css({left:left});
	});

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		var left = -1000*idx;
		TweenMax.to($(".intro_con .list_set"), 1, {x:left, ease:Expo.easeInOut});
		$(".intro_con_m .intro_list").css({display:"none"});
		$(".intro_con_m .intro_list").eq(idx).css({display:"block"});
	});

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".service_list li").removeClass("blind");
		}
		else
		{
			$(".service_list li").addClass("blind");
		}
	});

});



</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>PROBIOTICS WE PRODUCE</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics -->
				<div class="probiotics">
				
					<!-- "produce_con" -->
					<div class="produce_con">
						<ul>
							<li class="l">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img1.png" /></div>
								<p class="title">B.bifidum <strong>BGN4</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img2.png" /></div>
								<p class="title">B.longum <strong>BORI</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img3.png" /></div>
								<p class="title">B.lactis <strong>AD011</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img4.png" /></div>
								<p class="title">B.lactis <strong>AS60</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img5.png" /></div>
								<p class="title">B.infantis <strong>BH07</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img6.png" /></div>
								<p class="title">L.acidophilus <strong>AD031</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img7.png" /></div>
								<p class="title">L.paracasei <strong>BH08</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img8.png" /></div>
								<p class="title">L.plantarum <strong>BH02</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img9.png" /></div>
								<p class="title">L.casei <strong>IBS041</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img10.png" /></div>
								<p class="title">L.fermentum <strong>BH03</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img11.png" /></div>
								<p class="title">L.rhamnosus <strong>BH09</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img12.png" /></div>
								<p class="title">L.bulgaricus <strong>BH04</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img13.png" /></div>
								<p class="title">L.lactis <strong>BH10</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img14.png" /></div>
								<p class="title">S.thermophilus <strong>BH05</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img15.png" /></div>
								<p class="title">E.faecium <strong>BH06</strong></p>
							</li>
						</ul>
					</div>
					<!-- //"produce_con" -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>OUR SERVICES</h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						<strong>Various form and concentration of products we can provide.</strong>
						BIFIDO can offer various products of powder, sachet, capsule and tablet forms according to customer’s requirement. Each form can be packed as raw materials, bulk capsule and tablet with PTP packing and finished product with bottle or box packing.
					</div>
					<!-- //sub_title -->
					
					<!-- tab_pannel -->
					<div class=tab_pannel>
						<ul>
							<li class="on"><a href="javascript:">POWDER</a></li>
							<li><a href="javascript:">SACHET</a></li>
							<li><a href="javascript:">CAPSULE</a></li>
							<li><a href="javascript:">TABLET</a></li>
						</ul>
					</div>
					<!-- //tab_pannel -->
					
					<!-- intro_con" -->
					<div class="intro_con">
						<!-- list_set" -->
						<div class="list_set">
							<!-- powder" -->
							<div class="intro_list powder">
								<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img.png" /></div>
								<div class="txt_con">
									<h4>Powder Form</h4>
									<p>
										Through centrifuge and freeze-drying process, the<br />
										stability of probiotics culture was increased.<br />
										By diluting the original powder with special<br />
										excipient, stability of probiotics powder<br />
										is increased.
									</p>
									<p>
										Quality assurance system is important to keep the good <br />
										quality of BIFIDO powder form product. Appearance, moisture, <br />
										water activity, excipient, color, flavor etc. are monitored strictly<br />
										by BIFIDO Quality Control Team to insure the best quality of our products. 
									</p>
									<p>
										Bulk probiotics powder can be applied into the production of finished product<br />
										with other ingredients such as prebiotics according to customer’s requirement.
									</p>
								</div>
							</div>
							<!-- //powder -->
							<!-- stick" -->
							<div class="intro_list stick">
								<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img.png" /></div>
								<div class="txt_con">
									<h4>Sachet Form</h4>
									<p>
										We offer the service of sachet packing with injection of <br />
										nitrogen gas to keep the stability of probiotics contained<br />
										in the product. By our auto-production line, different <br />
										size of sachet probiotics products can be produced.<br /> 
										In secondary packing, we add desiccant to double <br />
										protect product from any environmental hazard factors.
									</p>
									<p>
										To decrease the heal effect during sealing the sachets, <br /> 
										we use cooling packing system to seal up the sachets.
									</p>
								</div>
							</div>
							<!-- //stick" -->
							<!-- capsule" -->
							<div class="intro_list capsule">
								<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img.png" /></div>
								<div class="txt_con">
									<h4>Capsule Form</h4>
									<p>
										Capsule form can keep probiotics away from oxygen<br />
										to increase the stability. BIFIDO’s  <a href="javascript:openPopup('/en/popup/material_enteral');">Enteric-coating<br />
										technique<span class="link"></span></a> will increase the survival rate of<br />
										probiotics in the digestive tract.
									</p>
									<div class="list">
										<dl>
											<dt style="width:110px">· <strong>Advantage  :</strong></dt>
											<dd>Easy to carry and take.</dd>
										</dl>
										<dl>
											<dt style="width:110px">· <strong>Disadvantage :</strong></dt>
											<dd>
												The amount of prebiotics added in a <br />
												capsule is limited. Prebiotics acts as <br />
												a growth factor of probiotics is needed.
											</dd>
										</dl>
									</div>
									<div class="list">
										<dl>
											<dt style="width:130px">· Capsule  Materials :</dt>
											<dd>Gelatin, HPMC, HPMCP</dd>
										</dl>
										<dl>
											<dt style="width:130px">· Capsule Size :</dt>
											<dd>0 / 1</dd>
										</dl>
									</div>
								</div>
							</div>
							<!-- //capsule -->
							<!-- tablet" -->
							<div class="intro_list tablet">
								<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img.png" /></div>
								<div class="txt_con">
									<h4>Tablet Form</h4>
									<p>
										BIFIDO’s <a href="javascript:openPopup('/en/popup/material_tablet');">small tablet technique</a><span class="link"></span> can not only keep the activity of probiotics,<br />
										but also decrease the quantities of binders.<br />
										<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2.png" />
									</p>
								</div>
							</div>
							<!-- //tablet -->
						</div>
						<!-- //list_set" -->
					</div>
					<!-- //intro_con" -->
					
					<!-- intro_con_m" -->
					<div class="intro_con_m">
						<!-- powder" -->
						<div class="intro_list powder">
							<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img_m.png" /></div>
							<div class="txt_con">
								<h4>Powder Form</h4>
								<p>
									Through centrifuge and freeze-drying process, the stability of probiotics culture was increased.<br />
									By diluting the original powder with special excipient, stability of probiotics powder is increased.
								</p>
								<p>
									Quality assurance system is important to keep the good quality of BIFIDO powder form product.<br /> 
									Appearance, moisture, water activity, excipient, color, flavor etc. <br />
									are monitored strictly by BIFIDO Quality Control Team to insure the best quality of our products. 

								</p>
								<p>
									Bulk probiotics powder can be applied into the production of finished product with other ingredients such as prebiotics according to customer’s requirement.
								</p>
							</div>
						</div>
						<!-- //powder -->
						<!-- stick" -->
						<div class="intro_list stick">
							<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img_m.png" /></div>
							<div class="txt_con">
								<h4>Sachet Form</h4>
								<p>
									We offer the service of sachet packing with injection of nitrogen gas to keep the stability of probiotics containedin the product.<br /> 
									By our auto-production line, different size of sachet probiotics products can be produced. <br />
									In secondary packing, we add desiccant to double protect product from any environmental hazard factors.
								</p>
								<p>
									To decrease the heat effect during sealing the sachet, we use a caulking gun and seal up sachet by sonication.
								</p>
							</div>
						</div>
						<!-- //stick" -->
						<!-- capsule" -->
						<div class="intro_list capsule">
							<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img_m.png" /></div>
							<div class="txt_con">
								<h4>Capsule Form</h4>
								<p>
									Capsule form can keep probiotics away from oxygen to increase the stability.<br /> 
									BIFIDO’s <a href="javascript:openPopup('/en/popup/material_enteral');">Enteric-coating technique<span class="link"></span></a> will increase the survival rate of probiotics in the digestive tract.<br />
									<br />
									· <strong>Advantage  :</strong>Easy to carry and take.<br />
									· <strong>Disadvantage :</strong>Prebiotics acts as a growth factor of probiotics is needed.<br />
									The amount of prebiotics added in a capsule is limited.
									<br />
									· Capsule  Materials : Gelatin, HPMC, HPMCP<br />
									· Capsule Size : G0 / 1<br />
								</p>
							</div>
						</div>
						<!-- //capsule -->
						<!-- tablet" -->
						<div class="intro_list tablet">
							<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img_m.png" /></div>
							<div class="txt_con">
								<h4>Tablet Form</h4>
								<p>
									BIFIDO’s <a href="javascript:openPopup('/en/popup/material_tablet');">small tablet technique</a><span class="link"></span> can not only keep the activity of probiotics, but also decrease the quantities of binders.<br />
									<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2_m.png" />
								</p>
							</div>
						</div>
						<!-- //tablet -->
					</div>
					<!-- //intro_con_m" -->
					
					<!-- main_title -->
					<div class="main_title">
						<p>MAIN COMPETITIVENESS OF OUR PRODUCTS</p>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- product_con -->
					<div class="product_con">
						<div class="product_list">
							<ul>
								<li style="top:30px;left:20px">
									<h4>HUMAN-ORIGIN</h4>
									<p>
										Human-origin probiotics is much easier to adhere <br />
										to the villi and grow in the intestine tract <br />
										according to <a href="#">clinical study</a><span class="link"></span>.
									</p>
								</li>
								<li class="r" style="top:30px;right:20px">
									<h4>
										WELL-DOCUMENTED RESEARCH<br />
										PAPERS AND PATENTS
									</h4>
									<p>
										· 26 patents<br />
										· More than 100 research papers <br />on lactic acid bacteria. 
									</p>
								</li>
								<li style="bottom:30px;left:20px">
									<h4>BIFIDO is an expert on BIFIDUS</h4>
									<p>
										We are professional on the study <br />
										and cultivation of probiotics, <br />
										especially for anaerobic human-<br />
										origin <i>Bifidobacterium</i> sp.

									</p>
								</li>
								<li class="r" style="bottom:30px;right:20px">
									<h4>LESS RISK</h4>
									<p>
										· Without the worry of potential risk of<br />
										  unbeneficial DNA conjugation caused<br />
										  by animal-origin probiotics.
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">See more details</span>
							<a href="/en/story">BIFIDUS STORY<span class="icon"></span></a>
						</div>
					</div>
					<!-- //product_con -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>DOCUMENT SERVICE <span>(RESEARCH PAPERS, PATENTS OR CERTIFICATE)</span></h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						BIFIDO has rich experiences on the study of lactic acid bacteria, which we can provide.
					</div>
					<!-- //sub_title -->
					
					<!-- "service_con" -->
					<div class="service_con">
						<div class="service_list">
							<ul>
								<li class="blind">
									<h4>COMPANY</h4>
									<p>
										· GMP certificate
									</p>
								</li>
								<li class="blind">
									<h4>STRAINS</h4>
									<p>
										· Halal certi clinical<br />
										· Studies stability data<br />
										· Etc.
									</p>
								</li>
								<li class="blind">
									<h4>DOCUMENTS FOR REGISTRATION</h4>
									<p>
										· Certificate of free sales<br />
										· Certificate of analysis<br />
										· Health certificate<br />
										· Certificate of origin<br />
										· Etc.
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">See more details</span>
							<a href="/en/about/download/brochure">DOWNLOAD<span class="icon"></span></a>
						</div>
					</div>
					<!-- //"service_con" -->
					
					
					
				</div>
				<!-- //probiotics -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->