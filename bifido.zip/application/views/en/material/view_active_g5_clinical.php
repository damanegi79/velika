<script type="text/javascript">

$(function ()
{
	
	$(".tab_pannel.tab1").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/en/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});	

	$(".tab_pannel.tab2").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		$(".list_page p").css({display:"none"});
		$(".list_page .list"+(idx+1)).css({display:"block"});
	});		
	
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel tab1" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">CLINICAL TRIAL</a></li>
						<li><a href="javascript:">RH1</a></li>
						<li><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li><a href="javascript:">COMPOUND K</a></li>
						<?Php else: ?>
							<li><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				
				<!-- main_title -->
				<div class="main_title">
					<h4>ACTIVE G5</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="clinical_list">
						<div class="clinical_img">
							<img src="/assets/images/raw_material/clinical_img.png" />
						</div>
						<p class="title">
							By fermenting ginseng, glycoside ginsenoside is converted into non glycoside ginsenoside. In other words, glucose, attached into saponin, is metabolized by specific probiotic <i>Bifidobacterium</i> and converted into small sized ginsenoside. The fermented ginseng contains high concentration of compounds such as Compound K, Rh1, Rh2, Rg1 and Rg2 with enhanced biological activities.
						</p>	
						<!-- tab_pannel -->
						<div class="tab_pannel tab2">
							<ul>
								<li class="on"><a href="javascript:">PURPOSE</a></li>
								<li><a href="javascript:">METHODS</a></li>
								<li><a href="javascript:">RESULTS</a></li>
								<li><a href="javascript:">CONCLUSIONS</a></li>
							</ul>
						</div>
						<!-- tab_pannel -->
						
						<!-- list_page -->
						<div class="list_page">
							<p class="list1">
								Allergic rhinitis is clinically defined as a disorder of the nose induced by IgE mediated inflammation after allergen exposure of the<br />
								nasal mucosa. Many reports have stated that Panax ginseng and fermented red ginseng have anti-inflammatory effects,<br />
								especially against Th2-type inflammation. This study was conducted to evaluate the therapeutic effects of fermented red ginseng<br />
								in allergic rhinitis.
							</p>
							<p class="list2" style="display:none">
								In this 4-week, double- blind, placebo-controlled study, 59 patients with persistent perennial allergic rhinitis were randomly divided<br />
								into two groups: those receiving fermented red ginseng tablets (experimental group) and those receiving placebo (control group).<br />
								The primary efficacy variable was the total nasal symptom score (TNSS; rhinorrhea, sneezing, itchy nose, and nasal congestion).<br />
								Secondary efficacy variables were the Rhinitis Quality of Life (RQoL) score and skin reactivity to inhalant allergens, as determined<br />
								by the skin prick test.
							</p>
							<p class="list3" style="display:none">
								There was no significant difference in the TNSS score and TNSS duration score between the experimental and placebo groups in<br />
								weeks 1, 2, 3, or 4. For nasal congestion, fermented red ginseng was significantly effective (P<0.005), while placebo caused no change.<br />
								The activity and emotion of RQoL improved markedly secondary to treatment with fermented red ginseng (P<0.05), while placebo<br />
								caused no change. Additionally, fermented red ginseng reduced skin reactivity to sensitized perennial allergens (P<0.05). Fermented<br />
								red ginseng was well tolerated.
							</p>
							<p class="list4" style="display:none">
								Fermented red ginseng improved nasal congestion symptoms and RQoL in patients with perennial allergic rhinitis.
							</p>
						</div>
						<!-- list_page -->
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->