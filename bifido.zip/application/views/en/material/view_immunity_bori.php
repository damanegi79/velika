
<script type="text/javascript">

$(function ()
{
	var linkAr = ["bgn4", "bori"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx = $(e.target).index();
		location.href = "/en/material/probiotics/immunity?category="+linkAr[idx];
	});
	
});


</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">BGN4</a></li>
						<li class="on"><a href="javascript:">BORI</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- main_title -->
				<div class="main_title">
					<label>Probiotics</label>
					<h4>BORI</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					Bifidobacterium longum BORI
				</div>
				<!-- //sub_title -->
				<!-- probiotics_sub -->
				<div class="probiotics_sub">
					<!-- con_info -->
					<div class="con_info">
						
						<div class="top_img_con">
							<img class="m_img" src="/assets/images/raw_material/immunity_top_bori.png" />
						</div>
						
						<div class="table_con">
							<table class="web">
								<caption>BGN4</caption>
								<colgroup>
									<col width="20%">
									<col width="20%">
									<col width="20%">
									<col width="">
								</colgroup>
								<thead>
									<tr>
										<th>short ID orientation</th>
										<th>Similarity score</th>
										<th>S_ab score</th>
										<th>Unique common oligomers and<br />sequence full name</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>S000497923</td>
										<td>Not calculated</td>
										<td>0.992</td>
										<td>1427. Bifidobacterium longum NCC2705; AE014295</td>
									</tr>
								</tbody>
							</table>
							<table class="mobile">
								<caption>BGN4</caption>
								<colgroup>
									<col width="40%">
									<col width="60%">
								</colgroup>
								<tbody>
									<tr>
										<td class="tit">short ID orientation</td>
										<td>S000497923</td>
									</tr>
									<tr>
										<td class="tit">Similarity score</td>
										<td>Not calculated</td>
									</tr>
									<tr>
										<td class="tit">S_ab score</td>
										<td>0.992</td>
									</tr>
									<tr>
										<td class="tit">Unique common oligomers and sequence full name</td>
										<td>1427. Bifidobacterium longum NCC2705; AE014295</td>
									</tr>
								</tbody>
							</table>
						</div>
						
						<h4 class="sub_title">EFFECTS</h4>
						
						<div class="effect_con">
							<div class="img_con"><img class="m_img" src="/assets/images/raw_material/immunity_bori.png" /></div>
						</div>
						
					</div>
					<!-- //con_info -->	
				</div>
				<!-- //probiotics_sub -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->