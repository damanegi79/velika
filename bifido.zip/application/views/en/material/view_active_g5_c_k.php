<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/en/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});	
		
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">CLINICAL TRIAL</a></li>
						<li><a href="javascript:">RH1</a></li>
						<li><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li class="on"><a href="javascript:">COMPOUND K</a></li>
						<?Php else: ?>
							<li class="on"><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				<!-- main_title -->
				<div class="main_title">
					<label>Fermented Ginseng</label>
					<h4>COMPOUND K</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="active_g5_list">
						
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/raw_material/c_k_img.png" />
							</div>
							<div class="list_set">
								<h4>Efficiency of Compound K</h4>
								<ol>
									<li><span class="num">01</span><span class="txt">Suppression of tumor cell proliferation and inflammation</span></li>
									<li><span class="num">02</span><span class="txt">Cytotoxicity against some tumor cells</span></li>
									<li><span class="num">03</span><span class="txt">Anti-carcinogenic and anti-cancer effects</span></li>
									<li><span class="num">04</span><span class="txt">Anti-allergy effects</span></li>
									<li><span class="num">05</span><span class="txt">Alleviation of Alzheimer`s disease</span></li>
									<li><span class="num">06</span><span class="txt">Anti-diabetic and anti-oxidant factors</span></li>
									<li><span class="num">07</span><span class="txt">Promotion of insulin secretion</span></li>
									<li><span class="num">08</span><span class="txt">Hepato-protective and skin-protective effect</span></li>
								</ol>
							</div>
						</div>
						
						<div class="page_bottom">
							<h4>PAPERS</h4>
							<ol>
								<li>
									<span>1.</span>
									<span class="txt">
										Induction of apoptosis by a novel intestinal metabolite of ginseng saponin via cytochrome c-mediated activation of caspase-3 protease. Biochem Pharmacol. 2000 Sep 1; 60(5):677-85. 
									</span>
								</li>
								<li>
									<span>2.</span>
									<span class="txt">
										Cytotoxicity of compound K (IH-901) and ginsenoside Rh2, main biotransformants of ginseng saponins by bifidobacteria, against some tumor cells. J. Ginseng Res. 27: 129-134 (2003) 
									</span>
								</li>
								<li>
									<span>3.</span>
									<span class="txt">
										Antiallergic activity of ginseng and its ginsenosides. Planta Med. 2003 69:518-22. 
									</span>
								</li>
								<li>
									<span>4.</span>
									<span class="txt">
										Protective effect of fermented red ginseng on a transient focal ischemic rats. Arch Pharm Res. 2004 27:1136-40. 
									</span>
								</li>
								<li>
									<span>5.</span>
									<span class="txt">
										Ab(25-35)-induced memory impairment, axonal atrophy, and synaptic loss are ameliorated by M1, A metabolite of protopanaxadiol-type saponins. Neuropsychopharmacology. 2004 29:860-8. 
									</span>
								</li>
								<li>
									<span>6.</span>
									<span class="txt">
										Antitumor promotional effects of a novel intestinal bacterial metabolite (IH-901) derived from the protopanaxadiol-type ginsenosides in mouse skin. Carcinogenesis. 2005 26:359-67.  
									</span>
								</li>
								<li>
									<span>7.</span>
									<span class="txt">
										Inhibitory effect of ginsenoside Rb1 and compound K on NO and prostaglandin E2 biosyntheses of RAW264.7 cells induced by lipopolysaccharide. Biol Pharm Bull. 2005 28:652-6.  
									</span>
								</li>
								<li>
									<span>8.</span>
									<span class="txt">
										Hepatoprotective effect of ginsenoside Rb1 and compound K on tert-butyl hydroperoxide-induced liver injury. Liver Int. 2005 25:1069-73.  
									</span>
								</li>
								<li>
									<span>9.</span>
									<span class="txt">
										Antipruritic effect of ginsenoside Rb1 and compound K in scratching behavior mouse models. J Pharmacol Sci. 2005 99:83-8.  
									</span>
								</li>
								<li>
									<span>10.</span>
									<span class="txt">
										Effect of ginsenoside Rb1 and compound K in chronic oxazolone-induced mouse dermatitis. Int Immunopharmacol. 2005 5:1183-91.
									</span>
								</li>
								<li>
									<span>11.</span>
									<span class="txt">
										Ginseng saponin metabolite suppresses phorbol ester-induced matrix metalloproteinase-9 expression through inhibition of activator protein-1 and mitogen-activated protein kinase signaling pathways in human astroglioma cells. Int J Cancer. 2006 118:490-7.
									</span>
								</li>
								<li>
									<span>12.</span>
									<span class="txt">
										A ginsenoside metabolite, 20-O-b-D-glucopyranosyl-20(S)-protopanaxadiol, triggers apoptosis in activated rat hepatic stellate cells via caspase-3 activation. Planta Med. 2006 72:1250-3.
									</span>
								</li>
								<li>
									<span>13.</span>
									<span class="txt">
										Effects of Compound K on Insulin Secretion and Carbohydrate Metabolism J. Ginseng Res. Vol. 31, No. 2, 79-85 (2007)
									</span>
								</li>
								<li>
									<span>14.</span>
									<span class="txt">
										Compound K (CK) Rich Fractions from Korean Red Ginseng Inhibit Toll-like Receptor (TLR) 4- or TLR9-mediated Mitogen-activated Protein Kinases Activation and Pro-inflammatory Responses in Murine Macrophages J. Ginseng Res.Vol. 31, No. 4, 181-190 (2007)
									</span>
								</li>
								<li>
									<span>15.</span>
									<span class="txt">
										Anti-diabetic effects of compound K versus metformin versus compound K-metformin combination therapy in diabetic db/db mice. Biol Pharm Bull. 2007 Nov;30(11):2196-200.
									</span>
								</li>
							</ol>						
						</div>
						
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->