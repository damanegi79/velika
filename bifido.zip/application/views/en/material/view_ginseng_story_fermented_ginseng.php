<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/en/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1_on.png" /></div>
								<h4>FERMENTED GINSENG</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4>BIFIDO COMPETITIVE</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>RESEARCH STUDY</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<h4>WHAT IS FERMENTED GINSENG?</h4>
						<p class="mt10">
							Until Now, more than thirty kinds of Ginsenoside, which is a compound word of Ginseng and Glycoside, has been derived from Korea Ginseng. The structural features are classified as Diol, Triol and Oleanane and we are recognized that the medical actions by each of those classifications are different. Ginsenoside, which is the efficient elements with the largest particles within ginseng, cannot be absorbed into our body before it is decomposed to small sized Ginsenoside by microorganism or enzymes in the organs.<br />
							<br />
							We have developed fermentation process of ginsenoside using food grade microorganism to increase absorption rate of ginsenoside, and it is called 'Fermented Ginseng'.
						</p>	
					</div>
					
					<div class="fermented_list">
						<div class="ginseng_list">
							<ol class="blind">
								<li>
									<h4>GINSENG</h4>
									<p>Before Red Ginseng made its mark,<br />common ginsengs were the best<br />in its own right.</p>
								</li>
								<li>
									<h4>RED GINSENG</h4>
									<p>Before we found out about<br />Fermented Ginseng Extract,<br />Red Ginseng was the best.</p>
								</li>
								<li>
									<h4>PERMENTED<br />GINSENG EXTRACT</h4>
									<p>But now the time belongs to<br />Fermented Ginseng Extracts.<br />It generates plenty of effective<br />medicinal ingredient.</p>
								</li>
							</ol>
							<img class="m_img" src="/assets/images/raw_material/permented_img1.png" />
						</div>	
					</div>
					
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->