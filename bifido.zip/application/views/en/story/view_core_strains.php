
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content story">
			<!-- content_set -->
			<div class="content_set">
				<!-- 
				<div class="main_title">
					<h4>STRAIN DEVELOPMENT STORY</h4>
					<span class="line"></span>
				</div>
				<div class="story_con no_mobile">
					<div class="core_con">
						<h3>BGN4, BORI DEVELOPMENT STORY</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set">
								<img src="/assets/images/bifidus_story/comming_img2.png" />
							</div>
						</div>
					</div>
				</div>
				<!-- main_title -->
				<div class="main_title">
					<h4>BGN4 PROFILE</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<div class="story_con">
					<div class="core_con">
						<div class="list_con">
							<div class="list_set" style="border:none">
								<img class="m_img" src="/assets/images/bifidus_story/core_img_1.png" />
							</div>
						</div>
					</div>
				</div>
				<!-- main_title -->
				<div class="main_title">
					<h4>BORI PROFILE</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<div class="story_con">
					<div class="core_con">
						<div class="list_con">
							<div class="list_set" style="border:none">
								<img class="m_img" src="/assets/images/bifidus_story/core_img_2.png" />
							</div>
						</div>
					</div>
				</div>
				<!-- //story_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->