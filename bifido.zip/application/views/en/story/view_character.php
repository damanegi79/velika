<script type="text/javascript">

$(function ()
{

	$("a[class*='view_btn']").each(function ( i )
	{
		$(this).bind("mouseover", function ( e )
		{
			$(this).find("img").eq(0).css({display:"none"});
			$(this).find("img").eq(1).css({display:"block"});
			$(".view_con"+(i+1)).css({display:"block"});
		});
		$(this).bind("mouseout", function ( e )
		{
			$(this).find("img").eq(0).css({display:"block"});
			$(this).find("img").eq(1).css({display:"none"});
			$(".view_con"+(i+1)).css({display:"none"});
		});
	});
});

</script>


<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content story">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>CHARACTER</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- story_con -->
				<div class="story_con">
					<div class="probio_con">
						<h3>STORY OF DR.G</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set">
								<img class="m_img" src="/assets/images/bifidus_story/probiotic_img1.png" />
							</div>
						</div>
					</div>
				</div>

				<div class="story_con">
					<div class="probio_con">
						<h3>DR.G CHARACTER</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set" style="border:none">
								<img class="m_img" src="/assets/images/bifidus_story/character_img1.png" />
							</div>
						</div>
					</div>
				</div>

				<div class="story_con">
					<div class="probio_con">
						<h3>RESEARCH ABOUT PROBIOTICS</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set" style="border:none">
								<img class="m_img" src="/assets/images/bifidus_story/character_img2.png" />
								<a class="view_btn1" href="javascript:" style="position:absolute;top:193px;left:716px">
									<img src="/assets/images/common/plus_btn1.png" />
									<img src="/assets/images/common/plus_btn1_on.png" style="display:none" />
								</a>
								<a class="view_btn2" href="javascript:" style="position:absolute;top:193px;left:886px">
									<img src="/assets/images/common/plus_btn1.png" />
									<img src="/assets/images/common/plus_btn1_on.png" style="display:none" />
								</a>
							</div>
						</div>
					</div>

					<div class="view_con1" style="position:absolute;top:158px;left:340px;display:none">
						<img src="/assets/images/bifidus_story/character_view1.png" />
					</div>

					<div class="view_con2" style="position:absolute;top:120px;left:37px;display:none">
						<img src="/assets/images/bifidus_story/character_view2.png" />
					</div>

				</div>

				<div class="story_con">
					<div class="probio_con">
						<h3>HUMAN ORIGIN PROBIOTICS BGN4</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set" style="border:none">
								<img class="m_img" src="/assets/images/bifidus_story/character_img3.png" />
								<a class="view_btn3" href="javascript:" style="position:absolute;top:114px;left:130px">
									<img src="/assets/images/common/plus_btn2.png" />
									<img src="/assets/images/common/plus_btn2_on.png" style="display:none" />
								</a>
								<a class="view_btn4" href="javascript:" style="position:absolute;top:166px;left:130px">
									<img src="/assets/images/common/plus_btn3.png" />
									<img src="/assets/images/common/plus_btn3_on.png" style="display:none" />
								</a>
								<a class="view_btn5" href="javascript:" style="position:absolute;top:110px;left:482px">
									<img src="/assets/images/common/plus_btn4.png" />
									<img src="/assets/images/common/plus_btn4_on.png" style="display:none" />
								</a>
								<a class="view_btn6" href="javascript:" style="position:absolute;top:160px;left:450px">
									<img src="/assets/images/common/plus_btn5.png" />
									<img src="/assets/images/common/plus_btn5_on.png" style="display:none" />
								</a>
								<a class="view_btn7" href="javascript:" style="position:absolute;top:65px;left:876px">
									<img src="/assets/images/common/plus_btn6.png" />
									<img src="/assets/images/common/plus_btn6_on.png" style="display:none" />
								</a>
								<a class="view_btn8" href="javascript:" style="position:absolute;top:133px;left:876px">
									<img src="/assets/images/common/plus_btn6.png" />
									<img src="/assets/images/common/plus_btn6_on.png" style="display:none" />
								</a>
								<a class="view_btn9" href="javascript:" style="position:absolute;top:201px;left:876px">
									<img src="/assets/images/common/plus_btn6.png" />
									<img src="/assets/images/common/plus_btn6_on.png" style="display:none" />
								</a>
							</div>
						</div>
					</div>

					<div class="view_con3" style="position:absolute;top:163px;left:42px;display:none">
						<img src="/assets/images/bifidus_story/character_view3.png" />
					</div>

					<div class="view_con4" style="position:absolute;top:339px;left:39px;display:none">
						<img src="/assets/images/bifidus_story/character_view4.png" />
					</div>

					<div class="view_con5" style="position:absolute;top:158px;left:483px;display:none">
						<img src="/assets/images/bifidus_story/character_view5.png" />
					</div>

					<div class="view_con6" style="position:absolute;top:334px;left:452px;display:none">
						<img src="/assets/images/bifidus_story/character_view6.png" />
					</div>

					<div class="view_con7" style="position:absolute;top:204px;left:692px;display:none">
						<img src="/assets/images/bifidus_story/character_view7.png" />
					</div>

					<div class="view_con8" style="position:absolute;top:216px;left:686px;display:none">
						<img src="/assets/images/bifidus_story/character_view8.png" />
					</div>

					<div class="view_con9" style="position:absolute;top:208px;left:684px;display:none">
						<img src="/assets/images/bifidus_story/character_view9.png" />
					</div>

				</div>

				<div class="story_con">
					<div class="probio_con">
						<h3>HUMAN ORIGIN PROBIOTICS BORI</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set" style="border:none">
								<img class="m_img" src="/assets/images/bifidus_story/character_img4.png" />
								<a class="view_btn10" href="javascript:" style="position:absolute;top:114px;left:130px">
									<img src="/assets/images/common/plus_btn2.png" />
									<img src="/assets/images/common/plus_btn2_on.png" style="display:none" />
								</a>
								<a class="view_btn11" href="javascript:" style="position:absolute;top:166px;left:130px">
									<img src="/assets/images/common/plus_btn3.png" />
									<img src="/assets/images/common/plus_btn3_on.png" style="display:none" />
								</a>
								<a class="view_btn12" href="javascript:" style="position:absolute;top:110px;left:482px">
									<img src="/assets/images/common/plus_btn4.png" />
									<img src="/assets/images/common/plus_btn4_on.png" style="display:none" />
								</a>
								<a class="view_btn13" href="javascript:" style="position:absolute;top:160px;left:450px">
									<img src="/assets/images/common/plus_btn5.png" />
									<img src="/assets/images/common/plus_btn5_on.png" style="display:none" />
								</a>
								<a class="view_btn14" href="javascript:" style="position:absolute;top:65px;left:876px">
									<img src="/assets/images/common/plus_btn6.png" />
									<img src="/assets/images/common/plus_btn6_on.png" style="display:none" />
								</a>
								<a class="view_btn15" href="javascript:" style="position:absolute;top:133px;left:876px">
									<img src="/assets/images/common/plus_btn6.png" />
									<img src="/assets/images/common/plus_btn6_on.png" style="display:none" />
								</a>
								<a class="view_btn16" href="javascript:" style="position:absolute;top:201px;left:876px">
									<img src="/assets/images/common/plus_btn6.png" />
									<img src="/assets/images/common/plus_btn6_on.png" style="display:none" />
								</a>
							</div>
						</div>
					</div>

					<div class="view_con10" style="position:absolute;top:125px;left:92px;display:none">
						<img src="/assets/images/bifidus_story/character_view10.png" />
					</div>

					<div class="view_con11" style="position:absolute;top:339px;left:135px;display:none">
						<img src="/assets/images/bifidus_story/character_view11.png" />
					</div>

					<div class="view_con12" style="position:absolute;top:158px;left:483px;display:none">
						<img src="/assets/images/bifidus_story/character_view12.png" />
					</div>

					<div class="view_con13" style="position:absolute;top:334px;left:452px;display:none">
						<img src="/assets/images/bifidus_story/character_view13.png" />
					</div>

					<div class="view_con14" style="position:absolute;top:204px;left:682px;display:none">
						<img src="/assets/images/bifidus_story/character_view14.png" />
					</div>

					<div class="view_con15" style="position:absolute;top:241px;left:682px;display:none">
						<img src="/assets/images/bifidus_story/character_view15.png" />
					</div>

					<div class="view_con16" style="position:absolute;top:319px;left:682px;display:none">
						<img src="/assets/images/bifidus_story/character_view16.png" />
					</div>

				</div>

				<div class="story_con">
					<div class="probio_con">
						<h3>ROTAVIRUS</h3>
						<div class="line2"></div>
						<div class="list_con">
							<div class="list_set" style="border:none">
								<img class="m_img" src="/assets/images/bifidus_story/character_img5.png" />
							</div>
						</div>
					</div>

				</div>
				
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->