
<script type="text/javascript">
$(function ()
{
	$(window).resize(function ()
	{
		if(isMobile)
		{
			$(".top_search_con input[type='text']").css({width:$(".top_search_con").width()-68});
			$(".table_con col").eq(2).attr("width", "35%");	
			$(".table_con td a").css({width:$(".top_search_con").width()-180});
		}	
		else
		{
			$(".top_search_con input[type='text']").css({width:""});
			$(".table_con col").eq(2).attr("width", "15%");	
		}
	});
});

</script>



<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content customer">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>NEWS</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- top_search_con -->
				<div class="top_search_con">
					<form id="search_form" method="GET">
						<input id="search_txt" name="search" type="text">
						<button type="submit"><img class="m_img" src="/assets/images/common/search_icon.png" /><span class="ml10">SEARCH</span></button>
					</form>
				</div>
				<!-- //top_search_con -->
				<!-- news -->
				<div class="news">
					<div class="news_list">
						
								
						<div class="table_con">
							<table>
								<caption>news</caption>
								<colgroup>
									<col width="15%">
									<col width="">
									<col width="15%">
								</colgroup>
								<thead>
									<tr>
										<th>No.</th>
										<th>Title</th>
										<th>Date</th>
									</tr>
								</thead>
								<tbody>
									<?php $i=1; ?>
                                	<?php foreach ($news_list as $list):?>
									<tr>
										<td><?= $i+$page ?></td>
										<td><a href="/en/customer/news_detail?<?php if($search != "") echo 'search='.$search.'&';?>idx=<?= $list->idx ?>&per_page=<?= $page ?>&no=<?= $i+$page ?>"><?= $list->title ?></a></td>
										<td><?= $list->date ?></td>
									</tr>
									<?php $i++; ?>
                                	<?php endforeach;?>
                                	
                                	<?php
                                		if(count($news_list) == 0) echo '<td colspan="3" style="height:200px">No results found.</td>';
                                	?>
								</tbody>
							</table>
						</div>
						<div class="paging_con">
							<?php echo $pagination;?>
						</div>
					</div>
				</div>
				<!-- //news -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->