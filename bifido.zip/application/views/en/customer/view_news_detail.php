<script type="text/javascript">
$(function ()
{
	$(window).bind("resize", function ()
	{
		if(!isMobile)
		{
			$(".table_con td img").each(function ( i )
			{
				if($(this).width() > $(".table_con").width())
				{
					
					$(this).css({width:$(".table_con").width(), height:"auto"});
				}
			});
		}
		else
		{
			$(".table_con td img").each(function ( i )
			{
				$(this).css({width:"", height:""});
			});
		}
	});
	
	$(window).bind("load", function ( e )
	{
		$(window).resize();
	});
});
</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content customer">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>NEWS</h4>
					<span class="line"></span>
				</div>
				<div class="page_btn_con">
					<?php
						if(empty($prev))
						{
							echo '<a class="disabled prev_btn"><img src="/assets/images/common/prev_arrow.png"><span class="ml10">PREVIOUS</span></a>';
						}
						else 
						{
							if($search == "")
							{
								echo '<a class="prev_btn" href="/en/customer/news_detail?idx='.$prev->idx.'&per_page='.$page.'&no='.($num-1).'"><img src="/assets/images/common/prev_arrow.png"><span class="ml10">PREVIOUS</span></a>';
							}
							else 
							{
								echo '<a class="prev_btn" href="/en/customer/news_detail?search='.$search.'&idx='.$prev->idx.'&per_page='.$page.'&no='.($num-1).'"><img src="/assets/images/common/prev_arrow.png"><span class="ml10">PREVIOUS</span></a>';
							}
						}
						
						if(empty($next))
						{
							echo '<a class="disabled next_btn">NEXT<span class="ml10"><img src="/assets/images/common/next_arrow.png"></span></a>';
						}
						else 
						{
							if($search == "")
							{
								echo '<a class="next_btn" href="/en/customer/news_detail?idx='.$next->idx.'&per_page='.$page.'&no='.($num+1).'">NEXT<span class="ml10"><img src="/assets/images/common/next_arrow.png"></span></a>';
							}
							else 
							{
								echo '<a class="next_btn" href="/en/customer/news_detail?search='.$search.'&idx='.$next->idx.'&per_page='.$page.'&no='.($num+1).'">NEXT<span class="ml10"><img src="/assets/images/common/next_arrow.png"></span></a>';
							}
						}
					?>
					<a class="list_btn" href="/en/customer/news?<?php if($search != "") echo 'search='.$search; ?>&per_page=<?=$page?>"><img src="/assets/images/common/list_icon.png"><span class="ml10">LIST</span></a>
				</div>
				<!-- //main_title -->
				<!-- news -->
				<div class="news_detail">
					<div class="news">
						<div class="news_detail">
							<div class="table_con">
								<table>
									<caption>news</caption>
									<thead>
										<tr>
											<th>
												<div class="tit"><?=strtoupper($news_list->title)?></div>
												<div class="date_con">
													<span>No.<?=$num?></span>
													<span>Date.<?=$news_list->date?></span>
												</div>
											</th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td><?= str_replace("\n", "", str_replace("\r", "", $news_list->content)) ?></td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
				<!-- //news -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->