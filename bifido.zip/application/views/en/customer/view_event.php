<script type="text/javascript">
$(function ()
{
	$(window).resize(function ()
	{
		if(isMobile)
		{
			$(".top_search_con input[type='text']").css({width:$(".top_search_con").width()-68});
			$(".event_list li .title_con").css({width:$(".event_list").width()-165});

		}	
		else
		{
			$(".top_search_con input[type='text']").css({width:""});
			$(".event_list li .title_con").css({width:""});
		}
	});
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		if(idx == 0)
		{
			location.href="/en/customer/event/upcomming";
		}
		else
		{
			location.href="/en/customer/event/last";
		}
	});

});

</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content customer">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>EVENT</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- top_search_con -->
				<div class="top_search_con">
					<form id="search_form" method="GET">
						<input id="search_txt" name="search" type="text">
						<button type="submit"><img src="/assets/images/common/search_icon.png" /><span class="ml10">SEARCH</span></button>
					</form>
				</div>
				<!-- //top_search_con -->
				<div class=tab_pannel>
						<ul>
							<li <?php if($cate != "last"){ echo 'class="on"';}?>><a href="javascript:">UPCOMMING EVENT</a></li>
							<li <?php if($cate == "last"){ echo 'class="on"';}?>><a href="javascript:">LAST EVENT</a></li>
						</ul>
					</div>
				<!-- news -->
				<div class="event">
					
					<div class="event_list">
						<div class="list_con">
							<ul>
								<?php $i=1; ?>
                                <?php foreach ($event_list as $list):?>
                                
								<li>
									<a href="/en/customer/event_detail/<?= $cate ?>?<?php if($search != "") echo 'search='.$search.'&';?>idx=<?= $list->idx ?>&per_page=<?= $page ?>&no=<?= $i+$page ?>">
										<div style="overflow:hidden">
										<div class="thumb_con">
										
											<div class="img_con">
											<?php if(empty($list->thumb)):?>
											<img src="/assets/images/common/default_event.png" />
											<?php else:?>
											<img src="<?= $list->thumb ?>" />
											<?php endIf;?>
											</div>
											<div class="date_con">
												<?php
													$sDateAr = explode("-", $list->s_date);
													$year = $sDateAr[0];
													$sDate = month_to_eng((int)removeZero($sDateAr[1])).' '.removeZero($sDateAr[2]);
													$eDateAr = explode("-", $list->e_date);
													$eDate = removeZero($eDateAr[2]);
												?>
												<p><?= $sDate ?> ~ <?= $eDate ?></p>
											</div>
										</div>
										<div class="title_con">
											<h4><span><?= $list->title ?></span></h4>
											<p>
												Date : <?=$sDate?> - <?=$eDate?> <?=$year?><br />
												Location : <?=$list->location?><br />
												<?=nl2br($list->subTitle)?>
											</p>
										</div>
										</div>
										<div class="m_title">
											Date : <?=$sDate?> - <?=$eDate?> <?=$year?><br />
											Location : <?=$list->location?><br />
											<?=nl2br($list->subTitle)?>
										</div>
										<div class="country_con">
											<span class="flag"><img src="/assets/images/flags/flag_<?=$list->country ?>.png" /></span>
											<h4><?=strtoupper($list->country)?></h4>
										</div>
									</a>
								</li>
								
								<?php $i++; ?>
                                <?php endforeach;?>
                                <?php
                                	if(count($event_list) == 0)
                                	{
                                		echo '<li class="ac" style="height:100px;font-size:14px;line-height:100px">No results found.</li>';
                                	}
                                ?>
							</ul>
						</div>
					</div>
					<div class="paging_con">
						<?php echo $pagination;?>
					</div>
					
					<div class="bottom_btn">
						<a href="/en/about/company/contact_us">CONTACT US</a>
					</div>
				</div>
				<!-- //news -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->