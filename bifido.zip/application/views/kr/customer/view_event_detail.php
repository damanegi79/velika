<script type="text/javascript">
$(function ()
{
	$(".table_con td a").each(function ( i )
	{
		$(this).append('<span class="link"></span>');
	});
		
	$(window).bind("resize", function ()
	{
		$(".table_con td img").each(function ( i )
		{
			if($(this).width() > $(".table_con").width())
			{
				
				$(this).css({width:$(".table_con").width(), height:"auto"});
			}
		});
	});
	
	$(window).bind("load", function ( e )
	{
		$(window).resize();
	});
});
</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content customer">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>EVENT</h4>
					<span class="line"></span>
				</div>
				<div class="page_btn_con">
					<?php
						if(empty($prev))
						{
							echo '<a class="disabled prev_btn"><img src="/assets/images/common/prev_arrow.png"><span class="ml10">PREVIOUS</span></a>';
						}
						else 
						{
							if($search == "")
							{
								echo '<a class="prev_btn" href="/kr/customer/event_detail/'.$cate.'?idx='.$prev->idx.'&per_page='.$page.'&no='.($num-1).'"><img src="/assets/images/common/prev_arrow.png"><span class="ml10">PREVIOUS</span></a>';
							}
							else 
							{
								echo '<a class="prev_btn" href="/kr/customer/event_detail/'.$cate.'?search='.$search.'&idx='.$prev->idx.'&per_page='.$page.'&no='.($num-1).'"><img src="/assets/images/common/prev_arrow.png"><span class="ml10">PREVIOUS</span></a>';
							}
						}
						
						if(empty($next))
						{
							echo '<a class="disabled next_btn">NEXT<span class="ml10"><img src="/assets/images/common/next_arrow.png"></span></a>';
						}
						else 
						{
							if($search == "")
							{
								echo '<a class="next_btn" href="/kr/customer/event_detail/'.$cate.'?idx='.$next->idx.'&per_page='.$page.'&no='.($num+1).'">NEXT<span class="ml10"><img src="/assets/images/common/next_arrow.png"></span></a>';
							}
							else 
							{
								echo '<a class="next_btn" href="/kr/customer/event_detail/'.$cate.'?search='.$search.'&idx='.$next->idx.'&per_page='.$page.'&no='.($num+1).'">NEXT<span class="ml10"><img src="/assets/images/common/next_arrow.png"></span></a>';
							}
						}
					?>
					<a class="list_btn" href="/kr/customer/event/<?=$cate?>?<?php if($search != "") echo 'search='.$search; ?>&per_page=<?=$page?>"><img src="/assets/images/common/list_icon.png"><span class="ml10">LIST</span></a>
				</div>
				<!-- //main_title -->
				<!-- event -->
				<div class="event_detail">
					<div class="event">
						<div class="event_detail">
							<div class="table_con">
								<table>
									<caption>event</caption>
									<colgroup>
										<col width="">
									</colgroup>
									<thead>
										<tr>
											<th><div class="tit"><?=$event_list->title?></div></th>
										</tr>
									</thead>
									<tbody>
										<tr>
											<td class="title">
												<div class="title_con">
													<div class="date_icon"><img src="/assets/images/common/date_icon.png" /><span class="ml5">Date</span></div>
													<?php
														$sDateAr = explode("-", $event_list->s_date);
														$sDate = month_to_eng(removeZero($sDateAr[1])).' '.removeZero($sDateAr[2]);
														$eDateAr = explode("-", $event_list->e_date);
														$eDate =  month_to_eng(removeZero($eDateAr[1])).' '.removeZero($eDateAr[2]);
													?>
													<p class="date_txt"><?=$sDate?> ~ <?=$eDate?></p>
													<div class="country_con">
														<span class="flag"><img src="/assets/images/flags/flag_<?= $event_list->country ?>.png" /></span>
														<span class="country"><?= strtoupper($event_list->country) ?></span>
													</div>
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<?= str_replace("\n", "", str_replace("\r", "", $event_list->content)) ?>
											</td>
										</tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<div class="bottom_btn">
						<a href="/kr/about/company/contact_us">CONTACT US</a>
					</div>
				</div>
				<!-- //event -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->