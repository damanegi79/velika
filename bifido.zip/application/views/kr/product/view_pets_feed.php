<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});

	$(window).resize();
	
	

	function resizeImg( e )
	{
		
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>애완동물을 위한 프로바이오틱스</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/real_bifidus_img.png" />
							</div>
							<div class="txt_con">
								<h4>REAL BIFIDUS (FOR PET)</h4>
								<p>
									애완동물을 위한 특별한 형태의 프로바이오틱스 보조사료 리얼비피더스를 추천합니다.<br />
									애완동물의 건강을 위해 좋은 균종과 고농도의 살아있는 프로바이오틱스를 함유하고 있습니다.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/real_bifidus_info_ko.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->


						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/cat_img.png" />
							</div>
							<div class="txt_con">
								<h4>REAL BIFIDUS CAT</h4>
								<p>
									리얼비피더스 캣은 당신의 고양이를 위해 씹을 수 있는 맛있는 정(Tablet)형태의 필수적인 영양분이 결합된 프로바이오틱스 보조사료입니다. 이 프로바이오틱스 보조사료는 고양이에게 필수아미노산인 타우린과 라이신이 함유되어 있습니다.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/cat_info_ko.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->						
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/cd7_img.png" />
							</div>
							<div class="txt_con">
								<h4>CD7 (FOR CHICKEN)</h4>
								<p>
									CD7은 닭의 위장 기관의 유익균은 늘어나고 유해균은 줄어들 수 있는 4종류의 식물유래 (김치) 락토바실러스와 3종류의 비피도박테리움이 함유되어 있습니다.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/cd7_info_ko.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/k9_img.png" />
							</div>
							<div class="txt_con">
								<h4>K9 (FOR COW)</h4>
								<p>
									K9은 소의 위장의 미생물의 활동과 균형을 조절하기 위해 2종류의 락토바실러스와 3종류의 비피도박테리움이 함유되어 있습니다.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/k9_info_ko.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/mr6_img.png" />
							</div>
							<div class="txt_con">
								<h4>MR.6 (FOR FISH)</h4>
								<p>
									MR.6은 물고기의 위장의 미생물의 활동과 균형을 조절하기 위해 나타난 3종류의 식물 유래 락토바실러스와 3종류의 비피도박테리움이 함유되어 있습니다.
								</p>
								<div class="info_con">
									<img class="m_img" src="/assets/images/product/mr6_info_ko.png" />
								</div>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->