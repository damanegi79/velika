<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});
	$(window).resize();
			
			
	function resizeImg( e )
	{
				
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>지근억 브랜드</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_fermented_ginseng_img.png" />
							</div>
							<div class="txt_con">
								<h4>지근억 발효인삼</h4>
								<p>
									비피도의 발효홍삼제품은 비피도박테리움에 의해 발효되어 생리활성이 우수한 진세노사이드 Rh1, Rh2, Compound K 등이 다량 함유되어 있습니다.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/vivido_premium_img.png" />
							</div>
							<div class="txt_con">
								<h4>
									비비도 프리미엄<br />
									<span>흡수율이 높은 진세노사이드 화합물 Compound K, Rh1, Rh2, Rg2, Rg3를 포함하는 특허.</span>
								</h4>
								<p>
									과학적인 연구와 수년간의 제품 개발 결과 높은 흡수율 (인삼 추출물로부터의 compound k, Rh1, Rh2, Rg2, Rg3) 의 진세노사이드를 추출하고 생산하는 자연적인 생산방법의 특허를 취득하였습니다. Vivido는 높은 흡수율의 진세노사이드를 함유하고 있는 활성화된 인삼농축분말입니다. 노인, 스트레스, 불균형한 식사 때문에 약한 소화 시스템을 가진 분들에게 추천합니다.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->