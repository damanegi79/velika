<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["zigunuk", "partners"];
		var idx =e.target.index();
		location.href = "/kr/product/probiotics/health?category="+linkAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">지근억 브랜드</a></li>
						<li><a href="javascript:">파트너 브랜드</a></li>
					</ul>
				</div>
				<!-- //tab_pannel -->
				<div class="box mt50"></div>
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>아이용<span> (3 - 36 개월)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bifiduc_baby_img.png" />
							</div>
							<div class="txt_con">
								<h4>지근억비피더스베이비</h4>
								<p>
									서울대학교 식품영양학과 지근억 교수 연구팀에 의하여 한국인의 장에서 분리한 비피더스균(BGN4, BORI)과 유산간균을 이용하여 개발한 생후 3개월~36개월까지의 아기를 위한 비피더스 영양, 정장제품입니다.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/kr/popup/product_baby');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->

					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>여성용 <span>(다이어트 & 장건강)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/slim_yogurtics_img.png" />
							</div>
							<div class="txt_con">
								<h4>슬림요거틱스</h4>
								<p>
									요구르트와 프로바이오틱스의 완벽한 조합. 건강한 장과 날씬한 몸매를 실현하기 위해 슬림요거틱스로 다양하고 맛있는 요리법과 자신만의 스타일로 아침식사를 직접 만드세요.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/kr/popup/product_slim');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>성인용</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_bifidus_img.png" />
							</div>
							<div class="txt_con">
								<h4>지근억비피더스</h4>
								<p>
									서울대학교 식품영양학과 지근억교수 연구팀에 의하여 한국인의 장에서 분리한 비피더스균(BGN4, BORI)과 유산간균, 그리고 비피더스균의 성장인자인 갈락토올리고당을 이용하여 개발한 성인용 건강기능식품입니다.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/kr/popup/product_zigunuk');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/zigunuk_prog_img.png" />
							</div>
							<div class="txt_con">
								<h4>한국인 맞춤 프로지 유산균과 먹이</h4>
								<p>
									본 제품은 장내 유산균 증식 및 유해균 억제에 도움이 되는 프로바이오틱스(한국인 유래 유산균)와 프로바이오틱스의 먹이가 되는 프락토올리고당이 함유된 유산균과 유산균의 먹이! 2가지를 모두 함께, 단 한 포에 넣는데 성공한 한국인 맞춤 유산균 제품입니다.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/kr/popup/product_prog');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->