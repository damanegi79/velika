<script type="text/javascript">


</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>온 가족용 <span>(DIY Probiotics breakfast)</span></h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bifidus_meal_img.png" />
							</div>
							<div class="txt_con">
								<h4>비피더스 밀</h4>
								<p>
									비피더스밀은 특히 아기들을 위한 고농도의 비피도박테리움 특허균주를 함유하고 있습니다. 크리미한 그릭 스타일 요거트로 아기들의 장 건강을 돌볼 수 있습니다.
								</p>
							</div>
							<div class="btn_con">
								<a href="javascript:openPopup('/kr/popup/product_meal');">PRODUCT DETAIL<span class="arrow"></span></a>
							</div>
						</div>
						<!-- //"list_con" -->
						
					</div>
					<!-- //product_list -->
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->