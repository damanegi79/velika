<script type="text/javascript">

$(function ()
{

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var linkAr = ["zigunuk", "partners"];
		var idx =e.target.index();
		location.href = "/kr/product/probiotics/health?category="+linkAr[idx];
	});			
});

</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li><a href="javascript:">지근억 브랜드</a></li>
						<li class="on"><a href="javascript:">파트너 브랜드</a></li>
					</ul>
				</div>
				<!-- //tab_pannel -->
				<div class="box mt50"></div>
				<!-- main_title -->
				<div class="main_title first" >
					<h4>파트너 브랜드</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				
				<!-- product_con -->
				<div class="product_con">
					<div class="partners1">
						<div class="blind">
							<h2>ODM PROCESS</h2>
							<ol>
								<li>
									<h4>고객의 수요</h4>
								</li>
								<li>
									<h4>비즈니스 상담</h4>
									<p>계약 판매 부서 체결</p>
								</li>
								<li>
									<h4>계약 판매 부서 체결</h4>
								</li>
								<li>
									<h4>준비 개발 및 표본 결정</h4>
									<p>기획 부서 및 중앙연구소</p>
								</li>
								<li>
									<h4>준비 개발 및 표본 결정</h4>
									<p>생산 부서 및 중앙연구소</p>
								</li>
								<li>
									<h4>생산</h4>
									<p>생산지원부서</p>
								</li>
								<li>
									<h4>배송</h4>
									<p>생산지원부서</p>
								</li>
							</ol>
						</div>
						<div class="img_con">
							<img src="/assets/images/product/odm_img_ko.png" />
						</div>
					</div>
					
					
					<div class="partners2" style="display:none">
						
						<ul>
							<li class="l">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li>
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="l t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
							<li class="t">
								<a href="#">
									<div class="img_con">
										<img src="/assets/images/product/partners_brand_guide.png" />
									</div>
									<div class="txt_con">
										<h4>
											Product Name
										</h4>
									</div>
								</a>
							</li>
						</ul>
						
					</div>
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->