<script type="text/javascript">

$(function ()
{
	$(".list_con .img_con img").bind("load", function ()
	{
		resizeImg();
	});
	$(window).resize();
			
			
	function resizeImg( e )
	{
				
		$(".list_con .img_con").each(function ( i )
		{
			if(!isMobile)
			{
				$(this).css({height:$(this).parent().height()});
				var top = ($(this).height()-$(this).find("img").height())/2;
				if(top < 0) top = 0;
				$(this).find("img").css({top:top});	
			}
			else
			{
				$(this).css({height:""});
				$(this).find("img").css({top:"", height:""});
			}
		});
	}
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content product -->
		<section class="sub_content product">
			<!-- content_set -->
			<div class="content_set">
				
				<!-- product_con -->
				<div class="product_con">
					
					<!-- product_list -->
					<div class="product_list">
						<!-- main_title -->
						<div class="main_title">
							<h4>화장품</h4>
							<span class="line"></span>
						</div>
						<!-- //main_title -->
					
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bori_detox_cream_img.png" />
							</div>
							<div class="txt_con">
								<h4>보리 디톡스 크림</h4>
								<p>
									비피다발효액, 발효인삼 및 발효황금의 완벽한 조합을 이용하여 피부를 재 활성화하세요.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/bori_detox_serum_img.png" />
							</div>
							<div class="txt_con">
								<h4>보리 디톡스 세럼</h4>
								<p>
									알코올, 합성색소 없는 천연 프로비이오틱스와 발효 식물 추출물의 결합으로 자연적이고 건강한 아름다움에 다가가세요.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						<!-- "list_con" -->
						<div class="list_con">
							<div class="img_con">
								<img src="/assets/images/product/pbs_img.png" />
							</div>
							<div class="txt_con">
								<h4>PBS (PROBIOTICS BEAUTY SOLUTION)</h4>
								<p>
									먹는 화장품으로 더욱 건강하게!<br />
									보리 AR81 PBS (Probiotics Beauty Solution)에 의해 inner & outer beauty를 실현하세요.
								</p>
							</div>
							
						</div>
						<!-- //"list_con" -->
						
						
					</div>
					<!-- //product_list -->
					
					
				</div>
				<!-- //product_con -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content product -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->