<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<div class="popup_frame">
	<div class="material_popup">
		<h2>장용성 코팅기법</h2>
		<div class="info_con">
			<div class="img_con">
				<?php if(isset($_GET["mobile"])):?>
					<img src="/assets/images/popup/material_enteral_img_m.png" />
				<?php else:?>
					<img src="/assets/images/popup/material_enteral_img.png" />
				<?php endIf;?>
			</div>
			<div class="txt_con">
				<p>
					비피도는 장용성 코팅 기법을 사용하여 프로바이오틱스 제품 (캡슐 / 정제)을 제조하고 있습니다.  <br />
					단백질 제인 등을 이용한 일반적인 단백질 코팅 방법과는 다르게 우리의 캡슐형 코팅 기법은 제인을 이용한 코팅 중에 들어있는 알코올에 의한 손상을 방지 할 뿐 만 아니라 소화과정으로부터 효과적으로 프로바이오틱스를 보호할 수 있습니다. 또한, 장용성 코팅은 산성인 위액에 저항 할 수 있어 프로바이오틱스의 장내 도달 효율을 높여 프로바이오틱스의 헬스 케어 기능을 보다 효율적으로 나타낼 수 있도록 합니다. 

				</p>
			</div>
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>