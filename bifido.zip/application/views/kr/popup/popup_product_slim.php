<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>슬림요거틱스</h2>
		<div class="info_con">
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left"'; ?>>
					<h4 class="title">성분</h4>
					<p class="tit">프로바이오틱스</p>
					
					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium lactis</i> AD011</li>
							<li><i>Lactobacillus fermentum</i> BH03</li>
							<li><i>Lactobacillus acidophilus</i> AD031</li>
						</ul>
					
					</div>
					<p class="tit mt20">슬림요거틱스</p>
					
					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium bifidum</i> BGN4 powder</li>
							<li><i>Bifidobacterium longum</i> BORI powder</li>
							<li><i>Bifidobacterium lactis</i> AD011 powder</li>
							<li><i>Lactobacillus acidophilus</i> AD031 powder</li>
							<li><i>Lactobacillus fermentum</i> BH03 powder</li>
							<li><i>Enterococcus faecium</i> BH06 powder</li>
						</ul>
					
					</div>
				</div>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:180px;padding-top:20px"'; ?>>
					<p class="tit mt20">식이섬유 & 올리고당</p>
					<div class="list_con">
						<ul>
							<li>난소화성말토덱스트린</li>
							<li>치커리뿌리추출물(이눌린)</li>
							<li>갈락토올리고당</li>
							<li>프락토올리고당</li>
							<li>자일로올리고당</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">가르시아 캄보지아 추출물</h4>
				<div class="list_con">
					<ul>
		
						<li>HCA(60%) :  840mg</li>
					</ul>
				</div>
			</div>
			<div class="pop_list">
				<div class="infi_slim">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_slim_img1_ko_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_slim_img1_ko.png" />
					<?php endIf;?>
					
				</div>
			</div>
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<h4 class="title">영양성분 (1회 제공량)</h4>
				
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;"'; ?>>
					<ul>
						<li>칼로리 :  20kcal</li>
						<li>탄수화물 :  18g</li>
						<li>단백질 :  0mg</li>					
					</ul>
				
				</div>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:200px"'; ?>>
					<ul>
						<li>지방 : 0mg</li>
						<li>나트륨 : 20mg</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">섭취 방법</h4>
				<div class="intake_con slim">
					<ul>
						<li>
							<div class="blind">
								<h4>블루베리 스무디</h4>
								<div>
									<ol>
										<li>딸기 2개</li>
										<li>블루베리 5개</li>
										<li>우유 100ml</li>
										<li>슬림요거틱스 분말 20g (1개 스틱)</li>
										<li>얼음 2개</li>
									</ol>
								</div>
								<p>
									<strong>사용법</strong><br />
									믹서기에 재료를 넣고 스무디가 될 때까지 혼합하세요.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img2_ko.png" />
						</li>
						<li>
							<div class="blind">
								<h4>그린 스무디</h4>
								<div>
									<ol>
										<li>양배추 1/8개</li>
										<li>사과 1/2개</li>
										<li>브로콜리 25g</li>
										<li>우유 100ml</li>
										<li>슬림요거틱스 20g (1개 스틱)</li>
										<li>얼음 2개</li>
									</ol>
								</div>
								<p>
									<strong>사용법</strong><br />
									믹서기에 재료를 넣고 스무디가 될 때까지 혼합하세요.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img3_ko.png" />
						</li>
						<li>
							<div class="blind">
								<h4>곡물 스무디</h4>
								<div>
									<ol>
										<li>키오아 25g</li>
										<li>현미 15g</li>
										<li>우유 100ml</li>
										<li>슬림요거틱스 20g (1개 스틱)</li>
										<li>얼음 2개</li>
									</ol>
								</div>
								<p>
									<strong>사용법</strong><br />
									믹서기에 재료를 넣고 스무디가 될 때까지 혼합하세요.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img4_ko.png" />
						</li>
						<li>
							<div class="blind">
								<h4>견과류 스무디</h4>
								<div>
									<ol>
										<li>아몬드 3개</li>
										<li>호두 3개</li>
										<li>건포드 3개</li>
										<li>우유 100ml</li>
										<li>슬림요거틱스 20g (1개 스틱)</li>
										<li>얼음 3개</li>
									</ol>
								</div>
								<p>
									<strong>사용법</strong><br />
									믹서기에 재료를 넣고 스무디가 될 때까지 혼합하세요.
								</p>
							</div>
							<img src="/assets/images/popup/product_slim_img5_ko.png" />
						</li>
					</ul>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">PRINT</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">보관</h4>
				<div class="stroage_con">
					<div class="img_con">
						<img src="/assets/images/popup/product_slim_img6_ko.png" />
					</div>
					<p class="mt15">
						직사광선을 피하고 습기가 없는 서늘한 곳에 보관하세요.
					</p>
				</div>
			</div>
			<div class="pop_list last">
				<h4 class="title">특징</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">건강한 인체 유래 특허 생균제를 사용합니다.</span></li>
					<li><span class="num">02</span><span class="txt">칼로리 걱정 없는 다이어트 영양간식.</span></li>
					<li><span class="num">03</span><span class="txt">2중 기능성 건강기능식품 (다이어트와 장 건강)</span></li>
					<li><span class="num">04</span><span class="txt">HCA 840mg를 함유하고 있습니다.</span></li>
					<li><span class="num">05</span><span class="txt">1000억 프로바이오틱스 투입 (기준규격 1억)</span></li>
					<li><span class="num">06</span><span class="txt">다양하고 간편한 레시피</span></li>
				</ol>
				<div class="ac">
					<img class="charact_img" src="/assets/images/popup/product_slim_img7_ko.png" />
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>