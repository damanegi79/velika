<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	
	$(".popup_frame .tab_pannel li a").bind("click", function ( e )
	{
		$(".popup_frame .tab_pannel li").removeClass("on");
		$(this).parent().addClass("on");
		
		var idx = $(this).parent().index();
		
		$(".popup_frame .tab_content li").css({display:"none"});
		$(".popup_frame .tab_content li").eq(idx).css({display:"block"});
	});
	resizeWindow();

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>지근억 비피더스</h2>
		<div class="info_con">
			<div class="pop_list" style="overflow:hidden">
				<div style="float:left">
					<h4 class="title">성분</h4>
					<p class="tit">프로바이오틱스</p>
					<div class="list_con">
						<ul>
							<li>20억 <i>Bifidobacterium bifidum</i> BGN4 :  1포</li>
							<li>20억 <i>Bifidobacterium longum</i> BORI :  1포</li>
							<li>4억 <i>Lactobacillus acidophilus</i> :  1포</li>
						</ul>
					</div>
					<p class="tit mt20">프리바이오틱스</p>
					<div class="list_con">
						<ul>
							<li>갈락토올리고당</li>
							<li>프락토올리고당</li>
						</ul>
					</div>
				</div>
				<!-- 
				<div class="video_con" style="float:right">
					<h4 class="title">RELEVANT VIDEO</h4>
					<div class="movie_con">
						<iframe allowfullscreen="" class="YOUTUBE-iframe-video" data-thumbnail-src="https://i.ytimg.com/s_vi/xC7hSuKVyYI/default.jpg?sqp=4CVLFiH7DQU&amp;rs=AOn4CLBcYa3LJ6wYcHfnnK8TeeduQFuNUg" frameborder="0" width="235" height="168" src="https://www.youtube.com/embed/4CVLFiH7DQU?feature=player_embedded&amp;wmode=opaque" ></iframe>
					</div>
				</div>
				-->
			</div>
			<div class="pop_list">
				<h4 class="title">영양성분 (1회 제공량)</h4>
				<div class="list_con">
					<ul>
						<li>칼로리 :  10kcal</li>
						<li>탄수화물 :  2g</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">섭취방법</h4>
				<div class="intake_con zigunuk">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_zigunuk_img1_ko_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_zigunuk_img1_ko.png" />
						<?php endIf;?>
					</div> 
					<div class="blind">
						<ol>
							<li>집이나 직장에서 매일 한 포씩 섭취하세요.</li>
							<li>2g 한 포를 매일 물이나 음료와 함께 섭취하세요.</li>
						</ol>
					</div>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">PRINT</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">보관</h4>
				<div class="stroage_con">
					<div class="img_con">
						<?php if(isset($_GET["mobile"])):?>
							<img src="/assets/images/popup/product_zigunuk_img2_ko_m.png" />
						<?php else:?>
							<img src="/assets/images/popup/product_zigunuk_img2_ko.png" />
						<?php endIf;?>
						
					</div>
					<p>
						직사광선을 피하고 습기가 없는 서늘한 곳에 보관하세요.<br />
						냉장 보관하는 경우 생균수 유지에 더욱 좋습니다.

					</p>
				</div>
				
			</div>
			<div class="pop_list">
				<h4 class="title">특징</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">특허 유산균 사용</span></li>
					<li><span class="num">02</span><span class="txt">인체 유래 높은 장정착력</span></li>
					<li><span class="num">03</span><span class="txt">프리바이오틱스 올리고당과 결합</span></li>
					<li><span class="num">04</span><span class="txt">다양한 비타민 함유</span></li>
				</ol>
				<div class="ac">
					
					<img class="charact_img" src="/assets/images/popup/product_zigunuk_img3_ko.png" />
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">NOTES</h4>
				
				<div class=tab_pannel>
					<ul>
						<li class="on"><a href="javascript:">WHO</a></li>
						<li><a href="javascript:">HOW</a></li>
						<li><a href="javascript:">HOW LONG</a></li>
						<li><a href="javascript:">WHY</a></li>
					</ul>
				</div>
				
				<div class=tab_content>
					<ul>
						<li>
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab1_ko_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab1_ko.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab2_ko_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab2_ko.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab3_ko_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab3_ko.png" />
							<?php endIf;?>
						</li>
						<li style="display:none">
							<?php if(isset($_GET["mobile"])):?>
								<img src="/assets/images/popup/product_zigunuk_tab4_ko_m.png" />
							<?php else:?>
								<img src="/assets/images/popup/product_zigunuk_tab4_ko.png" />
							<?php endIf;?>
							<div class="story_btn">
								<span class="txt">see more details</span>
								<a href="/kr/story">BIFIDUS STORY<span class="arrow"></span></a>
							</div>
						</li>
					</ul>
				</div>
				
			</div>
			<div class="pop_list last note_con">
				<h4 class="title">기능</h4>
				
				<div class="ac">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_zigunuk_img4_ko_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_zigunuk_img4_ko.png" />
					<?php endIf;?>
				</div>
			</div>
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>