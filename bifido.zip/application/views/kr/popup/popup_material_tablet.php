<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<div class="popup_frame">
	<div class="material_popup">
		<h2>Small tablet technique</h2>
		<div class="info_con">
			<div class="img_con">
				<?php if(isset($_GET["mobile"])):?>
					<img src="/assets/images/popup/material_tablet_img_m.png" />
				<?php else:?>
					<img src="/assets/images/popup/material_tablet_img.png" />
				<?php endIf;?>
			</div>
			<div class="txt_con">
				<p>
					몇 년 간의 정제(tablet) 제품 개발 결과, 프로바이오틱스 보조사료 생산공정에 Small tablet technique을 적용하게 되었습니다.<br /> 
					분말이나 과립에 고속으로 직접적인 압력을 가하여 Small tablet을 만드는 이 기술은 도전이였지만 결국 비피도의 개발팀은 수분 활성도를 낮추고 유통기한을 늘리는 제품 개발에 성공하였습니다.<br /> 
Small tablet은 일반적인 정제(tablet)이나 캡슐(capsule)보다 가축이나 애완동물이 섭취하기에 용이하며 Small tablet은 일반적인 정제(tablet)보다 결합제의 함유량을 줄일 수 있어 프로바이오틱스 균주의 스트레스를 감소하여 안정성을 높일 수 있습니다.
				</p>
			</div>
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>