<?php if(isset($_GET["mobile"])):?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>BIFIDO</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">
<meta name="description" content="" />
<meta name="keywords" content="" />
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="blac">
<link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="/assets/css/common.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/layout.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/popup.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/customSelectBox.css" />
<link rel="stylesheet" type="text/css" href="/assets/css/jquery.ui.datepicker.css" />
<script type="text/javascript" src="/assets/js/jquery.js"></script>
<script type="text/javascript" src="/assets/js/jquery.easing.1.3.js"></script>
<script type="text/javascript" src="/assets/js/jquery.form.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.browser.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.mousewheel.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.js"></script>
<script type="text/javascript" src="/assets/js/jquery.ui.datepicker.kr.js"></script>
<script type="text/javascript" src="/assets/js/greensock/TweenMax.min.js"></script>
<script type="text/javascript" src="/assets/js/greensock/plugins/CSSPlugin.min.js"></script>
<script type="text/javascript" src="/assets/js/modernizr-1.5.min.js"></script>
<script type="text/javascript" src="/assets/js/jquery.placeholder.js"></script>
<script type="text/javascript" src="/assets/js/iscroll.js"></script>
<script type="text/javascript" src="/assets/js/icheck.min.js"></script>
<script type="text/javascript" src="/assets/js/slider.js"></script>
<script type="text/javascript" src="/assets/js/customSelectBox.js"></script>
<script type="text/javascript" src="/assets/js/common.js"></script>
<script type="text/javascript" src="/assets/js/ui.js"></script>
</head>
<body>
<?php endIf; ?>
<script type="text/javascript">
$(function ()
{
	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".charact_list").removeClass("blind");

		}
		else
		{
			$(".charact_list").addClass("blind");
		}
	});
});
</script>
<div class="popup_frame">
	<div class="product_popup">
		<h2>비피더스밀</h2>
		<div class="info_con">
			<div class="pop_list" <?php if(!isset($_GET["mobile"])) echo 'style="overflow:hidden"'; ?>>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left"'; ?>>
					<h4 class="title">성분</h4>
					<p class="tit">프로바이오틱스</p>
					
					<div class="list_con">
						<ul>
							<li><i>Bifidobacterium bifidum</i> BGN4</li>
							<li><i>Bifidobacterium longum</i> BORI</li>
							<li><i>Lactobacillus acidophilus</i> AD031</li>
						</ul>
					
					</div>
				</div>
				<div <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:180px;padding-top:20px"'; ?>>
					<p class="tit mt20">프리바이오틱스</p>
					<div class="list_con">
						<ul>
							<li>치커리식이섬유</li>
							<li>말토덱스트린</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="pop_list">
				<div class="infi_slim">
					<?php if(isset($_GET["mobile"])):?>
						<img src="/assets/images/popup/product_meal_img7_ko_m.png" />
					<?php else:?>
						<img src="/assets/images/popup/product_meal_img7_ko.png" />
					<?php endIf;?>
				</div>
			</div>
			<div class="pop_list" style="overflow:hidden">
				<h4 class="title">영양성분 (1회 제공량)</h4>
				
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;"'; ?>>
					<ul>
						
						<li>칼로리: 55 kcal</li>
						<li>탄수화물: 16g</li>
						<li>단백질: 2g </li>
					
					</ul>
				
				</div>
				<div class="list_con" <?php if(!isset($_GET["mobile"])) echo 'style="float:left;margin-left:200px"'; ?>>
					<ul>
						<li>지방: 1.5g</li>
						<li>콜레스테롤: less than 10mg</li>
						<li>나트륨: 20mg</li>
					</ul>
				</div>
			</div>
			<div class="pop_list intake">
				<h4 class="title">섭취방법</h4>
				<div class="intake_con meal">
					<ul>
						<li>
							<div class="blind">
								<h4>그릭요거트</h4>
								<p>분말 20g<br />우유 100ml</p>
								<div>
									<strong>tips</strong>
									<ol>
										<li>더 크리미한 입맛을 위해서는 비피더스밀 파우더 우유와 함께 스푼으로 잘 저어서 섭취하세요.</li>
										<li>신선한 과일, 시리얼, 견과류나 말린 과일을 추가하세요. 더 영양가 있는 비피더스밀을 즐기실 수 있습니다.</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img1_ko.png" />
						</li>
						<li>
							<div class="blind">
								<h4>치즈케이크</h4>
								<p>분말 20g<br />milk 100ml</p>
								<div>
									<strong>tips</strong>
									<ol>
										<li>스푼으로 잘 저은 후 2-3시간 동안 냉장고에 놓아두신 후 드시면 치즈케이크와 같은 맛과 질감을 느끼실 수 있습니다.</li>
										<li>과일과 잼으로 토핑하시면 더욱 좋습니다.</li>
										<li>비피더스밀 치즈케이크는 냉장 보관해 주세요.</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img2_ko.png" />
						</li>
						<li>
							<div class="blind">
								<h4>요거트아이스크림</h4>
								<p>분말 20g<br />우유 100ml</p>
								<div>
									<strong>tips</strong>
									<ol>
										<li>맛있는 프로바이오틱스 아이스크림을 위해 Half & Half 우유로 대신해 보세요.</li>
										<li>좋아하는 과일이나 딸기, 바나나, 초콜릿, 커피, 녹차 맛을 추가하세요.</li>
										<li>신선한 과일이나 견과류 토핑 하세요.</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img3_ko.png" />
						</li>
						<li>
							<div class="blind">
								<h4>요거트크림</h4>
								<p>분말 20g<br />우유 100ml</p>
								<div>
									<strong>tips</strong>
									<ol>
										<li>덜 달콤하게 쿠키, 빵, 케이크에 발라 드시면 좋습니다.</li>
										<li>학생, 직장인을 위해 영야가 있고 쉽고 맛있게 즐길 수 있는 아침 식사입니다.</li>
										<li>맛도 좋고, 다이어트에 좋은 여성을 위한 간편 식사입니다.</li>
										<li>노인들을 위한 건강식품입니다.</li>
									</ol>
								</div>
							</div>
							<img src="/assets/images/popup/product_meal_img4_ko.png" />
						</li>
					</ul>
				</div>
				<div class="print_btn">
					<a href="javascript:Utils.printer();">PRINT</a>
				</div>
			</div>
			<div class="pop_list">
				<h4 class="title">보관</h4>
				<div class="stroage_con">
					<div class="img_con">
						<img src="/assets/images/popup/product_meal_img5_ko.png" />
					</div>
					<p class="mt15">
						직사광선을 피하고 습기가 없는 서늘한 곳이나 냉장고에 보관하세요.
					</p>
				</div>
				
			</div>
			<div class="pop_list last">
				<h4 class="title">특징</h4>
				<ol class="charact_list blind">
					<li><span class="num">01</span><span class="txt">건강한 아침, 맛있는 선택!</span></li>
					<li><span class="num">02</span><span class="txt">당신의 장 건강을 도와주는 영양가있는 요거트</span></li>
					<li><span class="num">03</span><span class="txt">건강 업! 당류는 다운!</span></li>
					<li><span class="num">04</span><span class="txt">인체 유래 특허 유산균 함유</span></li>
					<li><span class="num">05</span><span class="txt">저칼로리의 건강한 비피더스밀</span></li>
				</ol>
				<div class="ac">
					
					<img class="charact_img" src="/assets/images/popup/product_meal_img6_ko.png" />
				</div>
			</div>
			
		</div>
	</div>
	<?php if(isset($_GET["mobile"])):?>
		<a class="emt close_btn" href="javascript:parent.close();">close</a>
	<?php else:?>
		<a class="emt close_btn" href="javascript:closeModalPopup();">close</a>
	<?php endIf;?>
</div>
<?php if(isset($_GET["mobile"])):?>
</body>
</html>
<?php endIf; ?>