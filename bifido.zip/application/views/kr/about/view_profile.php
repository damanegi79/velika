
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content about -->
		<section class="sub_content about">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>WHAT WE DO</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					생명공학의 최고의 기술력에 대한 도전 정신으로 ㈜ 비피도는 프로바이오틱스 기반의 식품공학분야에서 세계 최고가 되기 위해 최선을 다하고 있습니다.
				</div>
				<!-- //sub_title -->
				<!-- profile -->
				<div class="profile">
					<!-- profile_list -->
					<div class="profile_list">
						<ul>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon1.png" alt="Professional on bifidus" />
									</div>
									<h4 class="titl">비피더스 전문가</h4>
								</div>
								<div class="txt_con">
									<p>
										㈜ 비피도는 건강기능식품분야의 선도적인 기업이 되기 위해 노력하고 있습니다. 다양한 프로바이오틱스 가운데, 비피더스 유산균은 장관 내 미생물 균형 유지를 위해 가장 이로운 미생물로 알려져 있으며, 오늘날 기능성 식품 분야에 널리 응용되고 있습니다. 특히, (주)비피도는 수년간 비피더스 유산균분야에 집중하여 얻어진 연구결과를 바탕으로 비피더스 유산균 분야의 독자적인 기업으로 발전해나가고 있습니다.
									</p>
								</div>
							</li>
							<li>
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon2.png" alt="Business area" />
									</div>
									<h4 class="titl">사업 영역</h4>
								</div>
								<div class="txt_con">
									<p>
										우리는 자체 기술에 의한 프로바이오틱스 원료와 발효인삼의 원료를 생산하고 지근억 브랜드의 완제품과 OEM/ODM 완제품을 생산합니다. 우리의 일상 생활로 프로바이오틱스의 이용을 확장시키기 위해 우리는 프로바이오틱스의 건강기능식품분야의 선도적인 기업이 되기 위해 노력하고 있습니다.
									</p>
								</div>
							</li>
							<li class="end">
								<div class="icon_con">
									<div class="img_con">
										<img src="/assets/images/about_bifido/profile_icon3.png" alt="Research & Development" />
									</div>
									<h4 class="titl">연구개발</h4>
								</div>
								<div class="txt_con">
									<p>
										㈜ 비피도의 지근억 대표는 현직 서울대학교 식품영양학과 교수로 루이지애나 대학교와 스탠포드 대학교에서 프로바이오틱스에 대한 연구 활동을 했으며, 현재 그는 장내 미생물과 비피더스 유산균 분야의 권위자입니다. 서울대학교 연구실은 프로바이오틱스분야를 연구하는 연구소입니다. 국제적인 경쟁력을 가진 기술을 가지고 있는 서울대학교 연구소는 국가지정연구소로 운영되었습니다.
									</p>
								</div>
							</li>
						</ul>
					</div>
					<!-- //profile_list -->
				</div>
				<!-- //profile -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content about -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->