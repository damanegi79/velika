<script type="text/javascript" src="/assets/js/main.js"></script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">

		<!-- bifido_home -->
		<section class="bifido_home">
			
			<!-- visual_con -->
			<div class="visual_con">
				<div class="visual_set">
					<div class="rol_target">
						<ul class="rol_ul">
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg1.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg1_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">Continuous effort for healthy life!</h2>
									<p class="title">
										World best probiotics, BIFIDO
									</p>
								</div>
							</li>
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg2.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg2_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">Doing our best to improve immune system</h2>
									<p class="title">
										World best probiotics, BIFIDO
									</p>
								</div>
							</li>
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg3.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg3_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">The company only focuses on probiotics</h2>
									<p class="title">
										World best probiotics, BIFIDO
									</p>
								</div>
							</li>
							<li class="rol_li">
								<?Php if(BROWSER_TYPE == "W"): ?>
									<img src="/assets/images/main/main_bg4.jpg" />
								<?Php else: ?>
									<img src="/assets/images/main/main_bg4_m.jpg" />
								<?Php endif; ?>
								<div class="title_con">
									<h2 class="title">We care for human health</h2>
									<p class="title">
										World best probiotics, BIFIDO
									</p>
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
			<!-- //visual_con -->
			
			<!-- "visual_pager" -->
			<div class="visual_pager">
				<div class="pager_con">
					<a href="javascript:"><span class="emt on">1</span></a>
					<a href="javascript:"><span class="emt on">2</span></a>
					<a href="javascript:"><span class="emt on">3</span></a>
					<a href="javascript:"><span class="emt on">4</span></a>
				</div>
			</div>
			<!-- //"visual_pager" -->
			
			<!-- banner_con -->
			<div class="banner_con">
				<!-- banner_set -->
				<div class="banner_set">
					<ul>
						<li>
							<a href="/kr/story">
								<div class="img_con"><img class="m_img" src="/assets/images/main/banner_icon1.png" alt="BIFIDUS STORY" /></div>
								<div class="txt_con">
									<h4>비피더스 스토리</h4>
									<p>비피더스 스토리 소개</p>
								</div>
							</a>
						</li>
						<li>
							<a href="/kr/customer/event">
								<div class="img_con"><img class="m_img" src="/assets/images/main/banner_icon2.png" alt="BIFIDUS STORY" /></div>
								<div class="txt_con">
									<h4>다가오는 이벤트</h4>
									<p>이벤트를 확인하시고 저희와 함께 하세요.</p>
								</div>
							</a>
						</li>
						<li>
							<a href="/kr/product">
								<div class="img_con"><img class="m_img" src="/assets/images/main/banner_icon3.png" alt="BIFIDUS STORY" /></div>
								<div class="txt_con">
									<h4>신제품</h4>
									<p>면역 시스템을 위한 제품</p>
								</div>
							</a>
						</li>
					</ul>
				</div> 
				<!-- //banner_set -->
			</div> 
			<!-- //banner_con -->
			
		</section>
		<!-- //bifido_home -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->