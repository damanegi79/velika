<script type="text/javascript">

$(function ()
{
	
	$(".tab_pannel.tab1").bind("tabchange", function ( e )
	{
		var linkAr = ["clinical", "rh1", "rh2", "c_k", "rg5", "rk1"];
		var idx =e.target.index();
		location.href = "/kr/material/fermented_ginseng/active_g5?category="+linkAr[idx];
	});	

	$(".tab_pannel.tab2").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		$(".list_page p").css({display:"none"});
		$(".list_page .list"+(idx+1)).css({display:"block"});
	});		
	
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
			
				<!-- tab_pannel -->
				<div class="tab_pannel tab1" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">CLINICAL TRIAL</a></li>
						<li><a href="javascript:">RH1</a></li>
						<li><a href="javascript:">RH2</a></li>
						<?Php if(BROWSER_TYPE == "W"): ?>
							<li><a href="javascript:">COMPOUND K</a></li>
						<?Php else: ?>
							<li><a href="javascript:">C.K</a></li>
						<?Php endif; ?>
						<li><a href="javascript:">RG5</a></li>
						<li><a href="javascript:">RK1</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				
				
				<!-- main_title -->
				<div class="main_title">
					<h4>ACTIVE G5</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- active_g5 -->
				<div class="active_g5">
				
					<div class="clinical_list">
						<div class="clinical_img">
							<img src="/assets/images/raw_material/clinical_img.png" />
						</div>
						<p class="title">
							인삼을 발효시켜, 배당체 진세노사이드에서 비배당체 진세노사이드로 변환됩니다. 즉, 사포닌에 부착된 당이 특정 프로바이오틱 비피더스균에 의해 대사되어 당이 제거된 작은 크기의 진세노사이드로 변환됩니다. 발효 인삼은 CK, RH1, Rh2, Rg1, RG2 등의 생리활성이 증진된 화합물이 높은 농도로 포함되어 있습니다.
						</p>	
						<!-- tab_pannel -->
						<div class="tab_pannel tab2">
							<ul>
								<li class="on"><a href="javascript:">연구목적</a></li>
								<li><a href="javascript:">연구방법</a></li>
								<li><a href="javascript:">연구결과</a></li>
								<li><a href="javascript:">연구결론</a></li>
							</ul>
						</div>
						<!-- tab_pannel -->
						
						<!-- list_page -->
						<div class="list_page">
							<p class="list1">
								알레르기성 비염은 임상적으로 비 점막의 알레르겐 노출 후 IgE에 의해 매개되는 염증에 의한 코의 장애로 정의된다. 대부분의 보고서는 특히 TH2 형 염증에 대해, 인삼과 발효 홍삼은 항 염증 효과가 있음을 언급했다. 본 연구는 알레르기성 비염에 대한 발효 홍삼 치료 효과를 평가하기 위해 실시하였습니다.
							</p>
							<p class="list2" style="display:none">
								4주, 이중 맹검, 위약 대조 연구에서 지속적 다년생 알레르기 성 비염을 가진 59 명의 환자를 무작위로 실험군(발효홍삼정제 투여)과 위약군(대조군)의 두 그룹으로 나누었습니다. (TNSS: 재채기 콧물, 가려움 코, 코 막힘) 주요 효능 변수는 전체 비강 증상 점수입니다. 두 번째 유효성 변수는 skin prick test에 의해 결정되는 Rhinitis Quality of Life (RQoL) 점수, 흡입 알레르기 항원반응에 대한 skin reactivity 이었습니다.
							</p>
							<p class="list3" style="display:none">
								1, 2, 3, 4주의 실험군과 위약 그룹 사이의 TNSS score 와 TNSS duration score의 유의적인 차이가 없었습니다. 하지만 코막힘에 대해, 위약 그룹은 변화가 없었지만 발효홍삼은 유의적으로 효과가 있었습니다. (P<0.005)위약은 아무런 변화가 발생하지 않았지만 발효 홍삼 투여군에서는 삶의 질이 현저히 (P <0.05) 개선되었습니다. 추가적으로, 발효 홍삼은 다년생 알레르기 항원에 대한 피부 반응 (P <0.05)이 감소되었습니다. 또한, 발효 홍삼은 부작용이 없었습니다.

							</p>
							<p class="list4" style="display:none">
								발효 홍삼은 만성 알레르기 성 비염 환자의 코 막힘 증상과 삶의 질을 개선하였습니다.
							</p>
						</div>
						<!-- list_page -->
					</div>
					
				</div>
				<!-- //active_g5 -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->