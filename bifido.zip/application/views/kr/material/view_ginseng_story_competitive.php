<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/kr/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1.png" /></div>
								<h4>발효인삼</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3_on.png" /></div>
								<h4>비피도의 경쟁력</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>RESEARCH STUDY</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<p class="list">유익한 건강기능</p>
						<p class="list">고농도 작은 분자의 진세노사이드</p>
					</div>
					
					<div class="fermented_list">
						<div class="list_page">
							<h3>BIFIDO ACTIVE G5</h3>
							
							<div class="line2"></div>
							
							<div class="g5_list">
								<ul class="blind">
									<li>Support the Immune System</li>
									<li>Enhance Physical Energy</li>
									<li>Bodily Stamina and Fatigue Resistance</li>
									<li>Support Memory Functions</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img1_ko.png" />
							</div>

							<div class="g5_list_2">
								<ul class="blind">
									<li>GINSENG</li>
									<li>FERMENTED GINSENG</li>
								</ul>
								<img class="m_img" src="/assets/images/raw_material/g5_img2_ko.png" /><br /><br />
								<p>
									인삼을 발효시켜, 배당체 진세노사이드에서 비배당체 진세노사이드로 변환됩니다. 즉, 사포닌에 부착된 당이 특정 프로바이오틱 비피더스균에 의해 대사되어 당이 제거된 작은 크기의 진세노사이드로 변환됩니다. 
									<br /><br />
									발효 인삼은 CK, RH1, Rh2, Rg1, RG2 등의 생리활성이 증진된 화합물이 높은 농도로 포함되어 있습니다.
								</p><br />
								<h4>발효인삼 ACTIVE G5와 인삼추출물의 비교</h4><br />
								<img class="m_img" src="/assets/images/raw_material/g5_img3_ko.png" /> 
							</div>
							
							<div class="line2 mt40"></div>
						</div>
					</div>
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->