
<script type="text/javascript">

$(function ()
{
	var linkAr = ["b_lactis_as60", "pai_probiotics", "gnl_probiotics"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx = $(e.target).index();
		location.href = "/kr/material/probiotics/gut_health?category="+linkAr[idx];
	});
	
});


</script>

<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel" style="margin-top:0">
					<ul>
						<li class="on"><a href="javascript:">B.LACTIS AS60</a></li>
						<li><a href="javascript:">PAI PROBIOTICS</a></li>
						<li><a href="javascript:">GNL PROBIOTICS</a></li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- main_title -->
				<div class="main_title">
					<label>Probiotics</label>
					<h4>B. LACTIS AS60</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- sub_title -->
				<div class="sub_title">
					Bifidobacterium lactis AS60
				</div>
				<!-- //sub_title -->
				<!-- probiotics_sub -->
				<div class="probiotics_sub">
				
					<!-- con_info -->
					<div class="con_info">
						
						<div class="top_img_con">
							<img class="m_img" src="/assets/images/raw_material/cut_health_top_b_laactis_as60.png" />
						</div>
						
						<h4 class="sub_title">논문</h4>
						
						<div class="sub_txt">
							<a href="#">Bifidobacterium animalis BF8(KFCC1150P) against pathogenic Enterobacter(Cronobacter) sakazaki and food domposition therefrom<span class="link"></span></a>
						</div>
						
						<h4 class="sub_title"><i>ENTEROBACTER(CRONOBACTER) SAKAZAKI</i></h4>
						
						<div class="sub_txt">
							장내 세균의 일종인 엔테로박터 사카자키(Enterobacter sakazakii)는 막대 모양의 그람 음성 병원성 세균입니다. 조제분유에 들어 있는 사카자키균에 의해 감염된 유아의 40~80%가 사망하는 것으로 알려져 있습니다. 장염, 뇌막염, 수막염을 유발하는 균으로 엔테로박터 사카자키 감염은 분말화 된 유아용 조제유에 건조된 상태로  2년 동안 생존할 수 있는 한 종의 사카자키균 변종이 함유되어 있는 것과 관련이 있습니다. 
						</div>
						
						
						<div class="effect_con">
							<div class="img_con"><img class="m_img" src="/assets/images/raw_material/cut_health_b_laactis_as60_ko.png" /></div>
						</div>
						
					</div>
					<!-- //con_info -->	
				</div>
				<!-- //probiotics_sub -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->