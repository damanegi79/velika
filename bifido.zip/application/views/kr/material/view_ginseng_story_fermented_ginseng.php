<script type="text/javascript">

$(function ()
{
	var cateAr = ["fermented_ginseng", "activ5", "competitive", "research"];
	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		location.href="/kr/material/fermented_ginseng/ginseng_story?category="+cateAr[idx];
	});
			
});

</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- tab_pannel -->
				<div class="tab_pannel img_pannel" style="margin-top:0">
					<ul>
						<li class="on">
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon1_on.png" /></div>
								<h4>발효인삼</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon2.png" /></div>
								<h4>ACTIVE 5</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon3.png" /></div>
								<h4>비피도의 경쟁력</h4>
							</a>
						</li>
						<li>
							<a href="javascript:">
								<div class="icon"><img src="/assets/images/raw_material/ginseng_icon4.png" /></div>
								<h4>RESEARCH STUDY</h4>
							</a>
						</li>
					</ul>
				</div>
				<!-- tab_pannel -->
				<!-- fermented -->
				<div class="fermented">
				
					<div class="fermented_list">
						<h4>발효인삼이란 무엇인가요?</h4>
						<p class="mt10">
							지금까지 고려인삼으로부터 약 30여종 이상의 진세노사이드를 분리하였으며, 구조적 특징에 따라 Diol계, Triol계, Oleanane계로 구분되고 서로의 약리작용이 다른 것으로 알려져 있습니다. 이러한 인삼(홍삼)의 가장 큰 유효성분으로 알려진 진세노사이드는 분자크기가 크기 때문에 진세노사이드 그 자체로 인체에 흡수되지 못하고 장내 미생물에 의해 분자량이 작은 진세노사이드 대사물로 분해되어 흡수됩니다.<br />
							<br />
							이에 진세노사이드의 체내 흡수율을 증진시키고 효능의 표준화를 위해 인삼(홍삼)을 특정 미생물로 발효하여 얻어진 것을 ‘발효인삼(홍삼)’이라 합니다.
						</p>	
					</div>
					
					<div class="fermented_list">
						<div class="ginseng_list">
							<ol class="blind">
								<li>
									<h4>인삼</h4>
									<p>홍삼이 알려지기 전에는 일반적으로 인삼이 최고의 건강식품이였습니다.</p>
								</li>
								<li>
									<h4>홍삼</h4>
									<p>발효인삼을 발견하기 전에는 홍삼이 최고의 건강식품이였습니다.</p>
								</li>
								<li>
									<h4>발효인삼 추출물</h4>
									<p>그러나 지금은 발효인삼이 효과적인 약용 성분을 가장 많이 함유하고 있는 최고의 건강식품입니다.</p>
								</li>
							</ol>
							<img class="m_img" src="/assets/images/raw_material/permented_img1_ko.png" />
						</div>	
					</div>
					
				</div>
				<!-- //fermented -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->