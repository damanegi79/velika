<script type="text/javascript">

$(function ()
{
	$(".intro_list").each(function ( i )
	{
		var left = $(".probiotics").width()*i;
		$(this).css({left:left});
	});

	$(".tab_pannel").bind("tabchange", function ( e )
	{
		var idx =e.target.index();
		var left = -1000*idx;
		TweenMax.to($(".intro_con .list_set"), 1, {x:left, ease:Expo.easeInOut});
		$(".intro_con_m .intro_list").css({display:"none"});
		$(".intro_con_m .intro_list").eq(idx).css({display:"block"});
	});

	$(window).bind("changeDisplay", function ( e )
	{
		if(e.mobile)
		{
			$(".service_list li").removeClass("blind");
		}
		else
		{
			$(".service_list li").addClass("blind");
		}
	});

});



</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					<h4>PROBIOTICS WE PRODUCE</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics -->
				<div class="probiotics">
				
					<!-- "produce_con" -->
					<div class="produce_con">
						<ul>
							<li class="l">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img1.png" /></div>
								<p class="title">B.bifidum <strong>BGN4</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img2.png" /></div>
								<p class="title">B.longum <strong>BORI</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img3.png" /></div>
								<p class="title">B.lactis <strong>AD011</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img4.png" /></div>
								<p class="title">B.lactis <strong>AS60</strong></p>
							</li>
							<li>
								<div class="img_con"><img src="/assets/images/raw_material/produce_img5.png" /></div>
								<p class="title">B.infantis <strong>BH07</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img6.png" /></div>
								<p class="title">L.acidophilus <strong>AD031</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img7.png" /></div>
								<p class="title">L.paracasei <strong>BH08</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img8.png" /></div>
								<p class="title">L.plantarum <strong>BH02</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img9.png" /></div>
								<p class="title">L.casei <strong>IBS041</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img10.png" /></div>
								<p class="title">L.fermentum <strong>BH03</strong></p>
							</li>
							<li class="l t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img11.png" /></div>
								<p class="title">L.rhamnosus <strong>BH09</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img12.png" /></div>
								<p class="title">L.bulgaricus <strong>BH04</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img13.png" /></div>
								<p class="title">L.lactis <strong>BH10</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img14.png" /></div>
								<p class="title">S.thermophilus <strong>BH05</strong></p>
							</li>
							<li class="t">
								<div class="img_con"><img src="/assets/images/raw_material/produce_img15.png" /></div>
								<p class="title">E.faecium <strong>BH06</strong></p>
							</li>
						</ul>
					</div>
					<!-- //"produce_con" -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>서비스 소개</h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- sub_title -->
					<div class="sub_title">
						<strong>우리가 제공 할 수 있는 다양한 제품과 제품의 농도.</strong>
						BIFIDO는 고객의 요구 사항에 따라 분말, 스틱, 캡슐 및 정제 등 다양한 제형을 제공할 수 있습니다. 각 제품은 원료 및 완제품( PTP포장, 병포장 또는 박스)으로 포장될 수 있습니다.
					</div>
					<!-- //sub_title -->
					
					<!-- tab_pannel -->
					<div class=tab_pannel>
						<ul>
							<li class="on"><a href="javascript:">분말(Powder)</a></li>
							<li><a href="javascript:">스틱(Sachet)</a></li>
							<li><a href="javascript:">캡슐(Capsule)</a></li>
							<li><a href="javascript:">정제(Tablet)</a></li>
						</ul>
					</div>
					<!-- //tab_pannel -->
					
					<!-- intro_con" -->
					<div class="intro_con">
						<!-- list_set" -->
						<div class="list_set">
							<!-- powder" -->
							<div class="intro_list powder">
								<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img_ko.png" /></div>
								<div class="txt_con">
									<h4>분말(Powder) 형태</h4>
									<p>
										원심분리, 동결건조 공정을 통하여, 프로바이오틱스 배양의 안정성이<br />
										증가하였고, 유산균 분말의 안정성을 증가시키기 위해 특별한 <br />
										부형제와 분말을 희석하여 사용합니다. 
									</p>
									<p>
										품질보증시스템은 BIFIDO에서 생산한 분말 제품의 좋은<br />
										품질을 유지하는 것이 중요합니다. 제품의 최고 품질을<br />
										보장하기 위해 모양, 수분, 수분활성도, 부형제, 색, 맛 등 <br />
										BIFIDO의 품질 관리팀에 의해 엄격하게 모니터링됩니다. 
									</p>
									<p>
										대량의 프로바이오틱스 분말은 고객의 요구에 따라 프리바이오틱스와 <br />
										같은 다른 기능성분과 혼합되어 최종 제품의 제조에 적용될 수 있습니다.
									</p>
								</div>
							</div>
							<!-- //powder -->
							<!-- stick" -->
							<div class="intro_list stick">
								<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img_ko.png" /></div>
								<div class="txt_con">
									<h4>스틱(Sachet) 형태</h4>
									<p>
										스틱 포장 시 질소 가스를 주입하여 프로바이오틱스의 활성을 <br />
										유지하고 있습니다. 자동화된 생산 라인을 통해 다양한 <br />
										형태와 크기의 제품을 생산할 수 있습니다. 10스틱씩 <br />
										제습제(실리카겔)를 포함하여 2차 포장을 하여 <br />
										환경으로부터 올 수 있는 유해요소를 예방합니다.
									</p>
									<p>
										스틱 포장 공정 중 열에 의한 영향을 감소하기 위해, <br /> 
										cooling packing system을 사용합니다.
									</p>
								</div>
							</div>
							<!-- //stick" -->
							<!-- capsule" -->
							<div class="intro_list capsule">
								<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img_ko.png" /></div>
								<div class="txt_con">
									<h4>캡슐(Capsule) 형태</h4>
									<p>
										캡슐 포장은 공기중의 산소에 민감한 프로바이오틱스의 안정성을<br />
										유지하기 위해 공기와의 접촉을 예방할 수 있습니다. <br />
										캡슐의 <a href="javascript:openPopup('/kr/popup/material_enteral');">Enteric-coating technique<span class="link"></span></a>은 소화관에서 생균제의<br />
                                        생존율을 증가시킬 수 있습니다. 
									</p>
									<div class="list">
										<dl>
											<dt style="width:110px">· <strong>장점 :</strong></dt>
											<dd>쉽게 복용하고 휴대 간편합니다.</dd>
										</dl>
										<dl>
											<dt style="width:110px">· <strong>단점 :</strong></dt>
											<dd>
												캡슐의 크기가 한정되어 있기 때문에<br /> 
												프로바이오틱스의 증식인자인 프리바이오<br />
												틱스의 함유량이 제한적입니다.

											</dd>
										</dl>
									</div>
									<div class="list">
										<dl>
											<dt style="width:130px">· 캡슐기재 :</dt>
											<dd>Gelatin, HPMC, HPMCP</dd>
										</dl>
										<dl>
											<dt style="width:130px">· 캡슐 사이즈 :</dt>
											<dd>0 / 1</dd>
										</dl>
									</div>
								</div>
							</div>
							<!-- //capsule -->
							<!-- tablet" -->
							<div class="intro_list tablet">
								<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img_ko.png" /></div>
								<div class="txt_con">
									<h4>정제(Tablet) 형태</h4>
									<p>
										프로바이오틱스의 활성을 유지할 뿐만 아니라,결합제의 양을<br />
										줄일 수 있도록 <a href="javascript:openPopup('/kr/popup/material_tablet');">small tablet technique</a><span class="link"></span> 제품을 생산하고 있습니다.
<br />
										<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2_ko.png" />
									</p>
								</div>
							</div>
							<!-- //tablet -->
						</div>
						<!-- //list_set" -->
					</div>
					<!-- //intro_con" -->
					
					<!-- intro_con_m" -->
					<div class="intro_con_m">
						<!-- powder" -->
						<div class="intro_list powder">
							<div class="img_con"><img src="/assets/images/raw_material/intro_powder_img_ko_m.png" /></div>
							<div class="txt_con">
								<h4>분말(Powder) 형태</h4>
								<p>
									원심분리, 동결건조 공정을 통하여, 프로바이오틱스 배양의 안정성이 증가하였고, 생균제 분말의 안정성을 증가시키기 위해 특별한 부형제와 분말을 희석하여 사용합니다. 
								</p>
								<p>
									품질보증시스템은 BIFIDO에서 생산한 분말 제품의 좋은 품질을 유지하는 것이 중요합니다.<br />
									제품의 최고 품질을 보장하기 위해 모양, 수분, 수분활성도, 부형제, 색, 맛 등  BIFIDO의 품질 관리팀에 의해 엄격하게 모니터링됩니다. 
								</p>
								<p>
									대량의 프로바이오틱스 분말은 고객의 요구에 따라 프리바이오틱스와 같은 다른 기능성분과 혼합되어 최종 제품의 제조에 적용될 수 있습니다.
								</p>
							</div>
						</div>
						<!-- //powder -->
						<!-- stick" -->
						<div class="intro_list stick">
							<div class="img_con"><img src="/assets/images/raw_material/intro_stick_img_ko_m.png" /></div>
							<div class="txt_con">
								<h4>스틱(Sachet) 형태</h4>
								<p>
									스틱 포장 시 질소 가스를 주입하여 프로바이오틱스의 활성을 유지하고 있습니다. <br />
									자동화된 생산 라인을 통해 다양한 형태와 크기의 제품을 생산할 수 있습니다. <br />
									10스틱씩 제습제(실리카겔)를 포함하여 2차 포장을 하여 환경으로부터 올 수 있는 유해요소를 예방합니다.
								</p>
								<p>
									스틱 포장 공정 중 열에 의한 영향을 감소하기 위해, cooling packing system을 사용합니다.
								</p>
							</div>
						</div>
						<!-- //stick" -->
						<!-- capsule" -->
						<div class="intro_list capsule">
							<div class="img_con"><img src="/assets/images/raw_material/intro_capsule_img_ko_m.png" /></div>
							<div class="txt_con">
								<h4>캡슐(Capsule) 형태</h4>
								<p>
									캡슐 포장은 공기중의 산소에 민감한 프로바이오틱스의 안정성을 유지하기 위해 공기와의 접촉을 예방할 수 있습니다. <br />
									캡슐의 <a href="javascript:openPopup('/kr/popup/material_enteral');">Enteric-coating techniqu<span class="link"></span></a>은 소화관에서 생균제의 생존율을 증가시킬 수 있습니다. 
									<br />
									· <strong>장점 :</strong>쉽게 복용하고 휴대 간편합니다.<br />
									· <strong>단점 :</strong>캡슐의 크기가 한정되어 있기 때문에 프로바이오틱스의 증식인자인 프리바이오틱스의 함유량이 제한적입니다.
									<br />
									· 캡슐기재 : Gelatin, HPMC, HPMCP<br />
									· 캡슐 사이즈: 0 / 1<br />
								</p>
							</div>
						</div>
						<!-- //capsule -->
						<!-- tablet" -->
						<div class="intro_list tablet">
							<div class="img_con"><img src="/assets/images/raw_material/intro_tablet_img_ko_m.png" /></div>
							<div class="txt_con">
								<h4>정제(Tablet) 형태</h4>
								<p>
									프로바이오틱스의 활성을 유지할 뿐만 아니라,결합제의 양을 줄일 수 있도록 <a href="javascript:openPopup('/kr/popup/material_tablet');">small tablet technique</a><span class="link"></span> 제품을 생산하고 있습니다.<br />
									<img class="mt10" src="/assets/images/raw_material/intro_tablet_img2_ko_m.png" />
								</p>
							</div>
						</div>
						<!-- //tablet -->
					</div>
					<!-- //intro_con_m" -->
					
					<!-- main_title -->
					<div class="main_title">
						<p>제품의 주요 경쟁력</p>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- product_con -->
					<div class="product_con">
						<div class="product_list">
							<ul>
								<li style="top:30px;left:20px">
									<h4>인체 유래</h4>
									<p>
										임상연구에 의하면 인체 유래의 프로바이오틱스가<br />
										장융모에 잘 정착하고 장관에서 성장하기 쉽습니다.
									</p>
								</li>
								<li class="r" style="top:30px;right:20px">
									<h4>
										논문 및 특허 등 연구자료
									</h4>
									<p>
										· 26개 특허<br />
										· 유산균에 대한100 개 이상의 연구 논문
									</p>
								</li>
								<li style="bottom:30px;left:20px">
									<h4>비피도는 비피더스균의 전문가입니다.</h4>
									<p>
										비피도의 연구진은 프로바이오틱스의 연구와  <br />
										배양을 전문으로 하고 있습니다. 특히,  <br />
										비피더스균을 비롯한 인체 유래의 혐기성미생물에 <br /> 
										대한 연구에 집중하고 있습니다. 
									</p>
								</li>
								<li class="r" style="bottom:30px;right:20px">
									<h4>인체유래비피더스</h4>
									<p>
										· 인체유래 probiotics는 동물유래 probiotics에 <br />
										의해 발생하는 유익하지 않은 DNA 접합에 의한 변이로<br />
										부터 발생하는 잠재적인 위험을 줄일 수 있습니다.
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">See more details</span>
							<a href="/kr/story">BIFIDUS STORY<span class="icon"></span></a>
						</div>
					</div>
					<!-- //product_con -->
					
					<!-- main_title -->
					<div class="main_title">
						<h4>문서 서비스</h4>
						<span class="line"></span>
					</div>
					<!-- //main_title -->
					
					<!-- "service_con" -->
					<div class="service_con kr">
						<div class="service_list">
							<ul>
								<li class="blind">
									<h4>회사</h4>
									<p>
										· GMP 인증서
									</p>
								</li>
								<li class="blind">
									<h4>STRAINS</h4>
									<p>
										· 할랄 인증서<br />
										· 임상연구<br />
										· 안정성 연구데이터<br />
										· 분석 방법(MOA)<br />
										· 물질 안전 보건 자료(MSDS)<br />
										· Etc.
									</p>
								</li>
								<li class="blind">
									<h4>등록 서류</h4>
									<p>
										· 자유판매증명서<br />
										· 분석증명서<br />
										· 검역증명서<br />
										· 원산지 증명서<br />
										· Etc.
									</p>
								</li>
							</ul>
						</div>
						<div class="bottom_btn">
							<span class="info">See more details</span>
							<a href="/kr/about/download/brochure">DOWNLOAD<span class="icon"></span></a>
						</div>
					</div>
					<!-- //"service_con" -->
					
					
					
				</div>
				<!-- //probiotics -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->