<script type="text/javascript">


$(function ()

{
	
	$(".intro_list").each(function ( i )
	
	{
		
		var left = $(".probiotics").width()*i;
		
		$(this).css({left:left});
	
	});

	

	$(".tab_pannel").bind("tabchange", function ( e )
	
	{
		
		var idx =e.target.index();
		
		var left = -$(".probiotics").width()*idx;
		
		TweenMax.to($(".intro_con .list_set"), 1, {x:left, ease:Expo.easeInOut});
	
	});

});


</script>
<!-- wrap -->
<div id="wrap">

	<!-- container -->
	<article id="container">
		<?php
			 $this->load->view('layout/view_sub_top', $depth);
		?>
		
		<!-- sub_content material -->
		<section class="sub_content material">
			<!-- content_set -->
			<div class="content_set">
				<!-- main_title -->
				<div class="main_title">
					
					<label>Probiotics</label>
					<h4>Lactobacillus fermentum</h4>
					<span class="line"></span>
				</div>
				<!-- //main_title -->
				<!-- probiotics_sub -->
				<div class="probiotics_sub">
				
					<!-- con_info -->

					<div class="con_info">
	
						<div class="top_txt_con">
							
							<p>

								<i>Lactobacillus fermentum</i>은 인간을 포함한 포유 동물의 위장관, 입과 질에 서식하는 프로바이오틱스 중의 하나입니다. 이 균주는 소화촉진, 호흡기질환의 감소와 여성의 비뇨 생식기 감염에 대한 치료활성이 보고 된 바 있습니다.							
							</p>
						
						</div>
						
						
						<h4 class="sub_title">연구자료</h4>
						
						
						<div class="effect_con">

							<div class="img_con">
								<img class="m_img" src="/assets/images/raw_material/woman_health_ko.png" />
							</div>
						
						</div>
						
					
					</div>
					
					<!-- //con_info -->	
					
				</div>
				<!-- //probiotics_sub -->
			</div>
			<!-- //content_set -->
			
		</section>
		<!-- //sub_content material -->

	</article>
	<!-- //container -->

</div>
<!-- //wrap -->