<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('admin_m');
		$this->load->helper(array('url', 'date', 'language', 'geoip'));
		$this->lang->load('layout');
		$this->languege = $this->lang->lang();
	}
	
	public function index()
	{
		$lang = $this->lang->lang();
		
		if($this->uri->uri_string()==="")
		{
			$code = strtolower(get_country_code());
			if($code == 'kr') 		$lang = 'kr';
			else if($code == 'ch')  $lang = 'ch';
			else if($code == 'vn')  $lang = 'vn';
			else                    $lang = 'en';
			
			redirect('/'.$lang);
		}
		
		$main_list = $this->admin_m->get_main_list();
		$data = array();
		$data['main_list'] = $main_list; 
		//print_r($main_list);
		$this->load->layout($lang, 'view_home', $data);
	}
	
}
