<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Sendmail extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url', 'date', 'util', 'language'));
		$this->languege = $this->lang->lang();
	}
	
	public function index()
	{
		if($_POST)
		{
			$config['mailtype']  = 'html';
			$config['protocol']  = 'smtp';
			$config['smtp_host'] = 'ssl://smtp.googlemail.com';
			$config['smtp_port'] = '465';
			$config['smtp_user'] = 'bifidodata@gmail.com';
			$config['smtp_pass'] = 'a15440977';
			$config['smtp_timeout'] = 10;
			
			$mail_addr = isset($_POST['mail_addr']) ? $_POST['mail_addr'] : "";
			$mail_name = isset($_POST['mail_name']) ? $_POST['mail_name'] : "";
			
			
			
			$this->load->library('email', $config);
			$this->email->set_newline("\r\n");
			$this->email->from($mail_addr, $mail_name);
			$this->email->to('bifidodata@gmail.com');
			$this->email->subject("contact us");
			
			$name = isset($_POST['mail_name']) ? $_POST['mail_name'] : "";
			$company = isset($_POST['mail_company']) ? $_POST['mail_company'] : "";
			$phone = isset($_POST['mail_phone']) ? $_POST['mail_phone'] : "";
			$content = isset($_POST['mail_content']) ? $_POST['mail_content'] : "";
			
			$message = '<h4>작성자</h4>';
			$message .= '<p>'.$name.'</p>';
			$message .= '<h4>메일주소</h4>';
			$message .= '<p>'.$mail_addr.'</p>';
			$message .= '<h4>회사명</h4>';
			$message .= '<p>'.$company.'</p>';
			$message .= '<h4>연락처</h4>';
			$message .= '<p>'.$phone.'</p>';
			$message .= '<h4>내용</h4>';
			$message .= '<p>'.$content.'</p>';
			
			$this->email->message($message);
			
			if($_POST['upload_path'])
			{
				$this->email->attach('.'.$_POST['upload_path']);
			}
			
			if($this->email->send())
			{
				echo 'success';
			}
			else 
			{
				echo 'error';
			}
			
		}
		else 
		{
			alertMsg('잘못된 접근 입니다.');
		}
	}
	
	public function mail_upload()
	{
		$config['upload_path'] = './uploads/mail';
		$config['allowed_types'] = '*';
		$config['max_size']	= '100000';
		$config['max_width']  = '2000';
		$config['max_height']  = '2000';
		
		$this->load->library('upload', $config);
		
		if ($this->upload->do_upload())
		{
			$data =$this->upload->data();
			echo '/uploads/mail/'.$data['file_name'];
		}
		
	}
	
	
}
