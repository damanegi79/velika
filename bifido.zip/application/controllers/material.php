<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Material extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url', 'date', 'language', 'form'));
		$this->lang->load('layout');
		$this->languege = $this->lang->lang();
	}
	
	public function index()
	{
		$data = array();
		//$this->load->layout($this->languege, 'view_about', $data);
		redirect(uri_string().'/probiotics/raw_material');
	}
	
	public function probiotics($seg = null)
	{
		if(!isset($seg))
		{
			redirect(uri_string().'/raw_material');
		}
		else 
		{
			$data = array('depth'=>get_depth($seg));
			if($_GET)
			{
				$this->load->layout($this->languege, '/material/view_'.$seg.'_'.$this->input->get("category"), $data);
			}
			else
			{
				if($seg == "immunity")
				{
					redirect(uri_string().'?category=bgn4');
				}
				else if($seg == "gut_health")
				{
					redirect(uri_string().'?category=b_lactis_as60');
				}
				else 
				{
					$this->load->layout($this->languege, '/material/view_'.$seg, $data);
				}
			}
		}
	}
	
	public function fermented_ginseng($seg = null)
	{
		if(!isset($seg))
		{
			redirect(uri_string().'/ginseng_story?category=fermented_ginseng');
		}
		else 
		{
			$data = array('depth'=>get_depth($seg));
			if($_GET)
			{
				$this->load->layout($this->languege, '/material/view_'.$seg.'_'.$this->input->get("category"), $data);
			}
			else
			{
				if($seg == "ginseng_story")
				{
					redirect(uri_string().'?category=fermented_ginseng');
				}
				else if($seg == "active_g5")
				{
					redirect(uri_string().'?category=clinical');
				}
				else 
				{
					show_404();
				}
			}
		}
	}
	
}
