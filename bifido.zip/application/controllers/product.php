<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Product extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url', 'date', 'language'));
		$this->lang->load('layout');
		$this->languege = $this->lang->lang();
	}
	
	public function index()
	{
		$data = array();
		//$this->load->layout($this->languege, 'view_about', $data);
		redirect(uri_string().'/probiotics');
	}
	
	public function probiotics($seg = null)
	{
		if(!isset($seg))
		{
			redirect(uri_string().'/health?category=zigunuk');
		}
		else
		{
			$data = array('depth'=>get_depth($seg));
			
			
			if($seg == "health")
			{
				if($_GET)
				{
					$this->load->layout($this->languege, '/product/view_'.$seg.'_'.$this->input->get("category"), $data);
				}
				else
				{
					redirect(uri_string().'?category=zigunuk');
				}
			}
			else
			{
				$this->load->layout($this->languege, '/product/view_'.$seg, $data);
			}
		}
	}
	
	public function fermented_ginseng($seg = null)
	{
		if(!isset($seg))
		{
			redirect(uri_string().'/zigunuk_brand');
		}
		else 
		{
			$data = array('depth'=>get_depth($seg));
			$this->load->layout($this->languege, '/product/view_'.$seg, $data);
		}
	}
	
}
