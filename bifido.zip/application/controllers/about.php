<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class About extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('admin_m');
		$this->load->helper(array('url', 'date', 'language',  'util', 'form'));
		$this->lang->load('layout');
		$this->languege = $this->lang->lang();
	}
	
	public function index()
	{
		$data = array();
		//$this->load->layout($this->languege, 'view_about', $data);
		redirect($this->languege.'/about/company');
	}
	
	public function company($seg = null)
	{
		if(!isset($seg))
		{
			redirect(uri_string().'/profile');
		}
		else 
		{
			if($seg == "vod")
			{
				$vod_list = $this->admin_m->get_vod_list();
				$data = array('depth'=>get_depth($seg), 'vod_list'=>$vod_list);
				$this->load->layout($this->languege, '/about/view_'.$seg, $data);
			}
			else 
			{
				$data = array('depth'=>get_depth($seg));
				$this->load->layout($this->languege, '/about/view_'.$seg, $data);
			}
		}
	}
	
	public function download($seg = null)
	{
		if(!isset($seg))
		{
			redirect(uri_string().'/brochure');
		}
		else 
		{
			$pdf_list = $this->admin_m->get_pdf_list( $seg );
			$data = array('depth'=>get_depth($seg), 'pdf_list'=>$pdf_list);
			$this->load->layout($this->languege, '/about/view_'.$seg, $data);
		}
	}
	
}
