<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customer extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('admin_m');
		$this->load->helper(array('url', 'date', 'language',  'util', 'form'));
		$this->lang->load('layout');
		$this->languege = $this->lang->lang();
	}
	
	public function index()
	{
		$data = array();
		//$this->load->layout($this->languege, 'view_about', $data);
		redirect(uri_string().'/news');
	}
	
	public function news()
	{
		$page = 0;
		if(isset($_GET['per_page']) && $_GET['per_page'] != "")  $page = $_GET['per_page'];
		
		$search = "";
		if(isset($_GET['search']) && $_GET['search'] != "")  $search = $_GET['search'];
		
		if($this->languege == "kr")  $lang = 'ko';
		else                         $lang = $this->languege;
		
		if($search == "")
		{
			$low = $this->db->where('lang', $lang)->get('news')->num_rows;
		}
		else 
		{
			$low = $this->db->where("(lang='".$lang."') AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%')", NULL)->get('news')->num_rows;
		}
		
		$news_list = $this->admin_m->get_news_list($lang, $page, $search);
		
		
		$data = array();
		$data['news_list'] = $news_list;
		$seg1 = $this->uri->segment(1);
		if($search == "") $data['pagination'] = get_pagination_link('/'.$seg1.'/customer/news?', $low);
		else              $data['pagination'] = get_pagination_link('/'.$seg1.'/customer/news?search='.$search, $low);
		$data['page'] = $page;
		$data['search'] = $search;
		$data['depth'] = get_depth('news');
		$this->load->layout($this->languege, '/customer/view_news', $data);
	}
	
	public function news_detail()
	{
		if(isset($_GET['idx']) && $_GET['idx'] != "")
		{
			$page = 0;
			if(isset($_GET['per_page']) && $_GET['per_page'] != "")  $page = $_GET['per_page'];
			
			$num = 1;
			if(isset($_GET['no']) && $_GET['no'] != "")  $num = $_GET['no'];
			
			$search = "";
			if(isset($_GET['search']) && $_GET['search'] != "")  $search = $_GET['search'];
			
			
			if($this->languege == "kr")  $lang = 'ko';
			else                         $lang = $this->languege;
			
			$news_list = $this->admin_m->get_news_list_row($_GET['idx']);
			$prev = $this->admin_m->get_news_list_prev($lang, $news_list->id, $search);
			$next = $this->admin_m->get_news_list_next($lang, $news_list->id, $search);
			
			$data = array();
			$data['news_list'] = $news_list;
			$data['page'] = $page;
			$data['depth'] = get_depth('news');
			$data['num'] = $num;
			$data['prev'] = $prev;
			$data['next'] = $next;
			$data['search'] = $search;
			$this->load->layout($this->languege, '/customer/view_news_detail', $data);
		}
		else 
		{
			show_404();
		}
	}
	
	public function event( $cate = "upcomming" )
	{
		$page = 0;
		if(isset($_GET['per_page']) && $_GET['per_page'] != "")  $page = $_GET['per_page'];
		
		$search = "";
		if(isset($_GET['search']) && $_GET['search'] != "")  $search = $_GET['search'];
		
		if($this->languege == "kr")  $lang = 'ko';
		else                         $lang = $this->languege;
		
		$date = date('Ymd');
		if($cate == "upcomming")
		{
			if($search == "")
			{
				$low = $this->db->where('(lang="'.$lang.'") AND (e_date >= '.$date.')', NULL)->get('event')->num_rows;
			}
			else
			{
				$low = $this->db->where("(lang='".$lang."') AND (e_date >= '.$date.') AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%')", NULL)->get('event')->num_rows;
			}
		}
		else 
		{
			if($search == "")
			{
				$low = $this->db->where('(lang="'.$lang.'") AND (e_date < '.$date.')', NULL)->get('event')->num_rows;
			}
			else
			{
				$low = $this->db->where("(lang='".$lang."') AND (e_date < '.$date.') AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%')", NULL)->get('event')->num_rows;
			}
		}
		
		$event_list = $this->admin_m->get_event_list($lang, $page, $cate, $search);
		
		
		$data = array();
		$data['event_list'] = $event_list;
		$seg1 = $this->uri->segment(1);
		if($cate == "upcomming")
		{
			if($search == "") $data['pagination'] = get_pagination_link('/'.$seg1.'/customer/event?', $low);
			else              $data['pagination'] = get_pagination_link('/'.$seg1.'/customer/event?search='.$search, $low);
		}
		else 
		{
			if($search == "") $data['pagination'] = get_pagination_link('/'.$seg1.'/customer/event/last?', $low);
			else              $data['pagination'] = get_pagination_link('/'.$seg1.'/customer/event/last?search='.$search, $low);
		}
		
		$data['page'] = $page;
		$data['search'] = $search;
		$data['cate'] = $cate;
		$data['depth'] = get_depth('event');
		
		//print_r($event_list);
		$this->load->layout($this->languege, '/customer/view_event', $data);
	}
	
	public function event_detail( $cate = "upcomming" )
	{
		if(isset($_GET['idx']) && $_GET['idx'] != "")
		{
			$page = 0;
			if(isset($_GET['per_page']) && $_GET['per_page'] != "")  $page = $_GET['per_page'];
				
			$num = 1;
			if(isset($_GET['no']) && $_GET['no'] != "")  $num = $_GET['no'];
				
			$search = "";
			if(isset($_GET['search']) && $_GET['search'] != "")  $search = $_GET['search'];
				
				
			if($this->languege == "kr")  $lang = 'ko';
			else                         $lang = $this->languege;
				
			$event_list = $this->admin_m->get_event_list_row($_GET['idx']);
			$prev = $this->admin_m->get_event_list_prev($lang, $event_list->id, $cate, $search);
			$next = $this->admin_m->get_event_list_next($lang, $event_list->id, $cate, $search);
				
			$data = array();
			$data['event_list'] = $event_list;
			$data['page'] = $page;
			$data['depth'] = get_depth('event');
			$data['num'] = $num;
			$data['prev'] = $prev;
			$data['next'] = $next;
			$data['search'] = $search;
			$data['cate'] = $cate;
			$this->load->layout($this->languege, '/customer/view_event_detail', $data);
		}
		else
		{
			show_404();
		}
	}
	
	public function webtoon()
	{
		$data = array();
		$data['depth'] = get_depth('webtoon');
		$this->load->layout($this->languege, '/customer/view_webtoon', $data);
	}
	
}
