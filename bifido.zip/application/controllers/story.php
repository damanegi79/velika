<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Story extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url', 'date', 'language',  'util'));
		$this->lang->load('layout');
		$this->languege = $this->lang->lang();
	}
	
	public function index()
	{
		$data = array();
		//$this->load->layout($this->languege, 'view_about', $data);
		redirect(uri_string().'/competitive');
	}
	
	public function competitive()
	{
		$data = array('depth'=>get_depth($this->uri->segment(3)));
		$this->load->layout($this->languege, '/story/view_competitive', $data);
	}
	
	public function probiotics()
	{
		$data = array('depth'=>get_depth($this->uri->segment(3)));
		$this->load->layout($this->languege, '/story/view_probiotics', $data);
	}
	
	public function core_strains()
	{
		$data = array('depth'=>get_depth($this->uri->segment(3)));
		$this->load->layout($this->languege, '/story/view_core_strains', $data);
	}
	
	public function core_technology()
	{
		$data = array('depth'=>get_depth($this->uri->segment(3)));
		$this->load->layout($this->languege, '/story/view_rnd', $data);
	}

	public function character()
	{
		$data = array('depth'=>get_depth($this->uri->segment(3)));
		$this->load->layout($this->languege, '/story/view_character', $data);
	}
	
}
