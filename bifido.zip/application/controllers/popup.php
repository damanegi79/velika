<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Popup extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->helper(array('url', 'date', 'language',  'util'));
		$this->languege = $this->lang->lang();
	}
	
	public function vod( $idx )
	{
		$data = array('idx'=>$idx);
		$this->load->view($this->languege.'/popup/popup_vod', $data);
	}
	
	public function material_enteral()
	{
		$data = array();
		$this->load->view($this->languege.'/popup/popup_material_enteral', $data);
	}
	
	public function material_tablet()
	{
		$data = array();
		$this->load->view($this->languege.'/popup/popup_material_tablet', $data);
	}
	
	
	public function product_baby()
	{
		$data = array();
		$this->load->view($this->languege.'/popup/popup_product_baby', $data);
	}
	
	public function product_zigunuk()
	{
		$data = array();
		$this->load->view($this->languege.'/popup/popup_product_zigunuk', $data);
	}
	
	public function product_prog()
	{
		$data = array();
		$this->load->view($this->languege.'/popup/popup_product_prog', $data);
	}
	
	public function product_meal()
	{
		$data = array();
		$this->load->view($this->languege.'/popup/popup_product_meal', $data);
	}
	
	public function product_slim()
	{
		$data = array();
		$this->load->view($this->languege.'/popup/popup_product_slim', $data);
	}
}
