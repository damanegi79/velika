<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin extends CI_Controller 
{
	
	function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->model('admin_m');
		$this->load->helper(array('url', 'form', 'string', 'util'));
		$this->load->library(array('form_validation', 'session'));
		$this->user_id = $this->session->userdata('user_id');
	}
	
	public function index()
	{
		$this->session->unset_userdata('user_id');
		redirect('admin/login');
	}
	
	public function login()
	{
		$this->load->view('admin/view_login');
	}
	
	public function login_check()
	{
		$reqLoginId = $this->input->post('loginId');
		$reqLoginPass = $this->input->post('loginPass');
		
		$loginRst = $this->admin_m->get_users_id($reqLoginId, $reqLoginPass);
		
		
		if($loginRst == TRUE)
		{
			$this->session->set_userdata('user_id' , $reqLoginId);
			redirect('admin/vod');
		}
		else
		{
			$data['errorMsg'] = "아이디/비밀번호를 다시 확인하시기 바랍니다.";
			$this->load->view('admin/view_login', $data);
		}
	}
	
	
	public function main_visual()
	{
		if($this->user_id == NULL)   redirect('admin/login');
		$main_list = $this->admin_m->get_main_list();
		$data = array();
		$data['main_list'] = $main_list; 
		$this->load->admin_layout('view_visual', $data);
	}
	
	
	public function vod()
	{
		if($this->user_id == NULL)   redirect('admin/login');
		$vod_list = $this->admin_m->get_vod_list();
		$data = array();
		$data['vod_list'] = $vod_list; 
		$this->load->admin_layout('view_vod', $data);
	}
	
	
	public function download( $cate = null )
	{
		if($this->user_id == NULL)   redirect('admin/login');
		if($cate == NULL)			redirect("/admin/download/brochure");
		$pdf_list = $this->admin_m->get_pdf_list($cate);
		$data = array();
		$data['category'] = $cate;
		$data['pdf_list'] = $pdf_list;
		
		$this->load->admin_layout('view_download', $data);
	}
	
	public function customer( $cate = null )
	{
		if($this->user_id == NULL)   redirect('admin/login');
		if($cate == NULL)			redirect("/admin/customer/news");
		//$pdf_list = $this->admin_m->get_pdf_list($cate);
		if($cate == "news")
		{
			$page = 0;
			if(isset($_GET['per_page']) && $_GET['per_page'] != "")  $page = $_GET['per_page']; 
			
			$lang = "";
			
			if(isset($_GET['lang']) && $_GET['lang'] != "")
			{
				$lang = $_GET['lang'];
				$low = $this->db->where('lang', $lang)->get('news')->num_rows;
			}
			else 
			{
				$low = $this->db->get('news')->num_rows;
			}
			
			$news_list = $this->admin_m->get_news_list($lang, $page);
			
			$data = array();
			$data['news_list'] = $news_list;
			$data['pagination'] = get_pagination_link('/admin/customer/news?lang='.$lang, $low);
			$data['page'] = $page;
			$data['lang'] = $lang;
			
			//print_r($news_list);
			$this->load->admin_layout('view_'.$cate, $data);
		}
		else if($cate == "news_write")
		{
			$data = array();
			$this->load->admin_layout('view_'.$cate, $data);
		}
		else if($cate == "news_detail")
		{
			if(isset($_GET['idx']) && $_GET['idx'] != "")
			{
				$idx = $_GET['idx'];
				$news_list = $this->admin_m->get_news_list_row( $idx );
				if(count($news_list)>0)
				{
					$data = array();
					$data['news_list'] =$news_list; 
					$data['lang'] = $_GET['lang'];
					$data['page'] = $_GET['per_page'];
					$this->load->admin_layout('view_'.$cate, $data);
				}
				else 
				{
					alertMsg('페이지가 존재하지 않습니다.', '/admin/customer/news');
				}
			}
			else 
			{
				alertMsg('페이지가 존재하지 않습니다.', '/admin/customer/news');
			}
		}
		else if($cate == "event")
		{
			$page = 0;
			if(isset($_GET['per_page']) && $_GET['per_page'] != "")  $page = $_GET['per_page'];
			
			$lang = "";
			
			if(isset($_GET['lang']) && $_GET['lang'] != "")
			{
				$lang = $_GET['lang'];
				$low = $this->db->where('lang', $lang)->get('event')->num_rows;
			}
			else 
			{
				$low = $this->db->get('event')->num_rows;
			}
			
			
			$event_list = $this->admin_m->get_event_list($lang, $page);
			
			$data = array();
			$data['event_list'] = $event_list;
			$data['pagination'] = get_pagination_link('/admin/customer/event?lang='.$lang, $low);
			$data['page'] = $page;
			$data['lang'] = $lang;
			//print_r($event_list);
			$this->load->admin_layout('view_'.$cate, $data);
		}
		else if($cate == "event_write")
		{
			$data = array();
			$this->load->admin_layout('view_'.$cate, $data);
		}
		else if($cate == "event_detail")
		{
			if(isset($_GET['idx']) && $_GET['idx'] != "")
			{
				$idx = $_GET['idx'];
				$event_list = $this->admin_m->get_event_list_row( $idx );
				if(count($event_list)>0)
				{
					$data = array();
					$data['event_list'] =$event_list;
					$data['lang'] = $_GET['lang'];
					$data['page'] = $_GET['per_page'];
					$this->load->admin_layout('view_'.$cate, $data);
				}
				else
				{
					alertMsg('페이지가 존재하지 않습니다.', '/admin/customer/news');
				}
			}
			else
			{
				alertMsg('페이지가 존재하지 않습니다.', '/admin/customer/news');
			}
		}
		else
		{
			show_404();
		}
	}
	
	public function upload_file($path)
	{
		$config['upload_path'] = './uploads/'.$path;
		if($path != "pdf")
		{
			$config['encrypt_name'] = TRUE;
		}
		$config['allowed_types'] = 'gif|jpg|png|jpeg|pdf|doc|xml';
		$this->load->library('upload', $config);
			
		if ( $this->upload->do_upload())
		{
			$data =$this->upload->data();
			echo '/uploads/'.$path.'/'.$data['file_name'];
		}
	}
	
	public function upload_edit()
	{
		if (isset ( $_FILES ) && isset ( $_FILES ['upload'] ))
		{
			$CKEditorFuncNum = $this->input->get('CKEditorFuncNum');
			$config['upload_path'] = './uploads/editor/';
			$config['encrypt_name'] = TRUE;
			$config['allowed_types'] = 'gif|jpg|png|jpeg';
			$this->load->library('upload', $config);
			
			if ( $this->upload->do_upload('upload'))
			{
				$data =$this->upload->data();
				echo "<script type='text/javascript'>window.parent.CKEDITOR.tools.callFunction('".$CKEditorFuncNum."', '/uploads/editor/".$data['file_name']."', '전송에 성공 했습니다')</script>";
			}
			else 
			{
				echo "<script>alert('업로드에 실패 했습니다.')</script>";
			}
			
			return;
		}
		
		echo "<script>alert('첨부파일이 없습니다.')</script>";
		
	}
	
	public function upload_main()
	{
		if($_POST)
		{
			$imgPath = $this->input->post('img_path');
			$count = $this->input->post('count');
			$mainTitleEn = $this->input->post('main_title_en');
			$subTitleEn = $this->input->post('sub_title_en');
			$infoTextEn = $this->input->post('info_text_en');
			
			$mainTitleKr = $this->input->post('main_title_kr');
			$subTitleKr = $this->input->post('sub_title_kr');
			$infoTextKr = $this->input->post('info_text_kr');
			
			$mainTitleCh = $this->input->post('main_title_kr');
			$subTitleCh = $this->input->post('sub_title_kr');
			$infoTextCh = $this->input->post('info_text_kr');
			
			$mainTitleVn = $this->input->post('main_title_vn');
			$subTitleVn = $this->input->post('sub_title_vn');
			$infoTextVn = $this->input->post('info_text_vn');
			
			$query = $this->admin_m->insert_main($count, $imgPath, $mainTitleEn, $subTitleEn, $infoTextEn, 
													$mainTitleKr, $subTitleKr, $infoTextKr, 
													$mainTitleCh, $subTitleCh, $infoTextCh, 
													$mainTitleVn, $subTitleVn, $infoTextVn);
			
			
			if($query)
			{
				alertMsg('저장되었습니다.', '/admin/main_visual');
			}
			else 
			{
				alertMsg('저장실패.', '/admin/main_visual');
			}
		}
		else 
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function upload_vod()
	{
		if($_POST)
		{
			$imgPath = $this->input->post('img_path');
			$youtubePath = $this->input->post('youtube_path');
			$category = $this->input->post('category');
			if($category == "on") $category="about";
			$titleEn = $this->input->post('title_en');
			$titleKr = $this->input->post('title_kr');
			$titleCh = $this->input->post('title_ch');
			$titleVn = $this->input->post('title_vn');
	
			$query = $this->admin_m->insert_vod($imgPath, $category, $youtubePath, $titleEn, $titleKr, $titleCh, $titleVn);
				
				
			if($query)
			{
				alertMsg('저장되었습니다.', '/admin/vod');
			}
			else
			{
				alertMsg('저장실패.', '/admin/vod');
			}
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function upload_pdf( $cate )
	{
		if($_POST)
		{
			
			$filePath = $this->input->post('file_path');
			$category1 = $cate;
			$category2 = $this->input->post('cate_select');
			
			if($this->input->post('title_kr'))  $titleKr = $this->input->post('title_kr');
			else                                      	$titleKr = "";
			
			if($this->input->post('title_en'))  $titleEn = $this->input->post('title_en');
			else                                      	$titleEn = "";
			
			if($this->input->post('title_ch'))  $titleCh = $this->input->post('title_ch');
			else                                      	$titleCh = "";
			
			if($this->input->post('title_vn'))  $titleVn = $this->input->post('title_vn');
			else                                     	$titleVn = "";
			
			if($this->input->post('leng_kr') == "on") $usedKr = 1;
			else                                      $usedKr = 0;
				
			if($this->input->post('leng_en') == "on") $usedEn = 1;
			else                                      $usedEn = 0;
				
			if($this->input->post('leng_ch') == "on") $usedCh = 1;
			else                                      $usedCh = 0;
				
			if($this->input->post('leng_vn') == "on") $usedVn = 1;
			else                                      $usedVn = 0;
	
			$query = $this->admin_m->insert_pdf($filePath, $category1, $category2, $titleKr, $titleEn, $titleCh, $titleVn, $usedKr, $usedEn, $usedCh, $usedVn);
	
			if($query)
			{
				alertMsg('저장되었습니다.', '/admin/download/'.$cate);
			}
			else
			{
				alertMsg('저장실패.', '/admin/download/'.$cate);
			}
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function upload_news()
	{
		if($_POST)
		{
			$date = date('Y-m-d');
			$title = $_POST['title_txt'];
			$content = $_POST['editor'];
			$idx = date('ymdhmsmis');
			$lang = $_POST['lang_slt'];
			$query = $this->admin_m->insert_news($date, $title, $content, $idx, $lang);
			
			if($query)
			{
				alertMsg('저장되었습니다.', '/admin/customer/news');
			}
			else
			{
				alertMsg('저장실패.', '/admin/customer/news');
			}
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function upload_event()
	{
		if($_POST)
		{
			$date = date('Y-m-d');
			$idx = date('ymdhmsmis');
			$s_date = $_POST['s_date'];
			$e_date = $_POST['e_date'];
			$lang = $_POST['lang_slt'];
			$country = $_POST['country_slt'];
			$title = $_POST['title_txt'];
			$location = $_POST['location_txt'];
			$sub_title = $_POST['sub_title_txt'];
			$content = $_POST['editor'];
			$thumb = $_POST['thumb_path'];
			$query = $this->admin_m->insert_event($date, $idx, $s_date, $e_date, $lang, $country, $title, $location, $sub_title, $content, $thumb);
			
			if($query)
			{
				alertMsg('저장되었습니다.', '/admin/customer/event');
			}
			else
			{
				alertMsg('저장실패.', '/admin/customer/event');
			}
			print_r($_POST);
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function delete_main()
	{
		if($_POST)
		{
			$id = $this->input->post('list_id');
			$imgPath = $this->input->post('img_path');
			
			if(is_file($imgPath)) 
			{
				unlink($imgPath);
			}
			
			if($this->admin_m->delete_main( $id ))
			{
				alertMsg('삭제 되었습니다.', '/admin/main_visual');
			}
			else 
			{
				alertMsg('삭제 실패.', '/admin/main_visual');
			}
			
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function delete_vod()
	{
		if($_POST)
		{
			$id = $this->input->post('list_id');
			$imgPath = $this->input->post('img_path');
				
			if(is_file($imgPath))
			{
				unlink($imgPath);
			}
				
			if($this->admin_m->delete_vod( $id ))
			{
				alertMsg('삭제 되었습니다.', '/admin/vod');
			}
			else
			{
				alertMsg('삭제 실패.', '/admin/vod');
			}
				
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function delete_pdf( $cate )
	{
		if($_POST)
		{
			$id = $this->input->post('list_id');
			$filePath = $this->input->post('file_path');
	
			if(is_file($filePath))
			{
				unlink($filePath);
			}
	
			if($this->admin_m->delete_pdf( $id ))
			{
				alertMsg('삭제 되었습니다.', '/admin/download/'.$cate);
			}
			else
			{
				alertMsg('삭제 실패.', '/admin/download/'.$cate);
			}
	
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function delete_news()
	{
		if($_POST)
		{
			$del_list = $_POST["chk_list"];
			
			if($this->admin_m->delete_news( $del_list ))
			{
				
				alertMsg('삭제 되었습니다.', $_POST['prev']);
			}
			else
			{
				alertMsg('삭제 실패.');
			}
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function delete_event()
	{
		if($_POST)
		{
			$del_list = $_POST["chk_list"];
				
			if($this->admin_m->delete_event( $del_list ))
			{
	
				alertMsg('삭제 되었습니다.', $_POST['prev']);
			}
			else
			{
				alertMsg('삭제 실패.');
			}
		}
		else
		{
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function modify_main()
	{
		if($_POST)
		{
			$id = $this->input->post('list_id');
			$mainTitleEn = $this->input->post('main_title_en');
			$subTitleEn = $this->input->post('sub_title_en');
			$infoTextEn = $this->input->post('info_text_en');
			
			$mainTitleKr = $this->input->post('main_title_kr');
			$subTitleKr = $this->input->post('sub_title_kr');
			$infoTextKr = $this->input->post('info_text_kr');
			
			$mainTitleCh = $this->input->post('main_title_kr');
			$subTitleCh = $this->input->post('sub_title_kr');
			$infoTextCh = $this->input->post('info_text_kr');
			
			$mainTitleVn = $this->input->post('main_title_vn');
			$subTitleVn = $this->input->post('sub_title_vn');
			$infoTextVn = $this->input->post('info_text_vn');
			
			$data = array(
					'mainTitleEn'=>$mainTitleEn,
					'subTitleEn'=>$subTitleEn,
					'infoTextEn'=>$infoTextEn,
			
					'mainTitleKr'=>$mainTitleKr,
					'subTitleKr'=>$subTitleKr,
					'infoTextKr'=>$infoTextKr,
			
					'mainTitleCh'=>$mainTitleCh,
					'subTitleCh'=>$subTitleCh,
					'infoTextCh'=>$infoTextCh,
			
					'mainTitleVn'=>$mainTitleVn,
					'subTitleVn'=>$subTitleVn,
					'infoTextVn'=>$infoTextVn
			);
			
			if($this->admin_m->modify_main($id, $data))
			{
				alertMsg('수정 되었습니다.', '/admin/main_visual');
			}
			else
			{
				alertMsg('수정 실패.', '/admin/main_visual');
			}
				
		}
		else
		{
				
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function modify_vod()
	{
		if($_POST)
		{
			$id = $this->input->post('list_id');
			$youtubePath = $this->input->post('youtube_path');
			$category = $this->input->post('category');
			if($category == "on") $category="about";
			
			$titleEn = $this->input->post('title_en');
			$titleKr = $this->input->post('title_kr');
			$titleCh = $this->input->post('title_ch');
			$titleVn = $this->input->post('title_vn');
				
			$data = array(
					'id'=>$id,
					'youtubePath'=>$youtubePath,
					'category'=>$category,
					'titleEn'=>$titleEn,
					'titleKr'=>$titleKr,
					'titleCh'=>$titleCh,
					'titleVn'=>$titleVn
			);
				
			if($this->admin_m->modify_vod($id, $data))
			{
				alertMsg('수정 되었습니다.', '/admin/vod');
			}
			else
			{
				alertMsg('수정 실패.', '/admin/vod');
			}
		
		}
		else
		{
		
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function modify_pdf( $cate )
	{
		if($_POST)
		{
			$id = $this->input->post('list_id');
			$category = $this->input->post('cate_select');
							
			if($this->input->post('title_kr'))  $titleKr = $this->input->post('title_kr');
			else                                $titleKr = "";
			
			if($this->input->post('title_en'))  $titleEn = $this->input->post('title_en');
			else                                $titleEn = "";
			
			if($this->input->post('title_ch'))  $titleCh = $this->input->post('title_ch');
			else                                $titleCh = "";
			
			if($this->input->post('title_vn'))  $titleVn = $this->input->post('title_vn');
			else                                $titleVn = "";
			
			if($this->input->post('leng_kr') == "on") $usedKr = 1;
			else                                      $usedKr = 0;
				
			if($this->input->post('leng_en') == "on") $usedEn = 1;
			else                                      $usedEn = 0;
				
			if($this->input->post('leng_ch') == "on") $usedCh = 1;
			else                                      $usedCh = 0;
				
			if($this->input->post('leng_vn') == "on") $usedVn = 1;
			else                                      $usedVn = 0;
	
			$data = array(
					'id'=>$id,
					'category1'=>$cate,
					'category2'=>$category,
					'titleEn'=>$titleEn,
					'titleKr'=>$titleKr,
					'titleCh'=>$titleCh,
					'titleVn'=>$titleVn,
					'usedKr'=>$usedKr,
					'usedEn'=>$usedEn,
					'usedCh'=>$usedCh,
					'usedVn'=>$usedVn
			);
	
			if($this->admin_m->modify_pdf($id, $data))
			{
				alertMsg('수정 되었습니다.', '/admin/download/'.$cate);
			}
			else
			{
				alertMsg('수정 실패.', '/admin/download/'.$cate);
			}
	
		}
		else
		{
	
			alertMsg('잘못된 접근입니다.');
		}
	}
	public function modify_news()
	{
		if($_POST)
		{
			$lang =  $this->input->post('lang_slt');
			$title =  $this->input->post('title_txt');
			$content =  $this->input->post('editor');
			$idx =  $this->input->post('idx');
			$date = date('Y-m-d');
			
			
			
			$data = array(
					'title'=>$title,
					'content'=>$content,
					'lang'=>$lang,
					'date'=>$date
			);
			
			
			
			if($this->admin_m->modify_news($idx, $data))
			{
				alertMsg('수정 되었습니다.', $this->input->post('prev'));
			}
			else
			{
				alertMsg('수정 실패.',  $this->input->post('prev'));
			}
		}
		else
		{
		
			alertMsg('잘못된 접근입니다.');
		}
	}
	
	public function modify_event()
	{
		if($_POST)
		{
			$idx =  $this->input->post('idx');
				
			$lang =  $this->input->post('lang_slt');
			$country =  $this->input->post('country_slt');
			$title =  $this->input->post('title_txt');
			$location = $this->input->post('location_txt');
			$sub_title = $this->input->post('sub_title_txt');
			$content = $this->input->post('editor');
			$thumb = $this->input->post('thumb_path');
			$date = date('Y-m-d');
			$s_date = $this->input->post('s_date');
			$e_date = $this->input->post('e_date');
				
			$data = array(
					'title'=>$title,
					'location'=>$location,
					'subTitle'=>$sub_title,
					'content'=>$content,
					'thumb'=>$thumb,
					'lang'=>$lang,
					'country'=>$country,
					's_date'=>$s_date,
					'e_date'=>$e_date,
					'date'=>$date
			);
				
			if($this->admin_m->modify_event($idx, $data))
			{
				alertMsg('수정 되었습니다.', $this->input->post('prev'));
			}
			else
			{
				alertMsg('수정 실패.',  $this->input->post('prev'));
			}
		}
		else
		{
	
			alertMsg('잘못된 접근입니다.');
		}
	}
}
