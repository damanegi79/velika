<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

class MY_Loader extends CI_Loader
{

    public function layout($seg, $body, $vars,  $return = FALSE)
    {
    	if($return):
    	
	    	$content = $this->view("layout/view_header", $vars, $return);
    		$content .= $this->view($seg.'/'.$body, $vars, $return);
	    	$content .= $this->view("layout/view_footer", $vars, $return);
	    	return $content;
    	
    	else:
    	
	    	$this->view("layout/view_header", $vars, $return);
    		$this->view($seg.'/'.$body, $vars, $return);
	    	$this->view("layout/view_footer", $vars, $return);
    	
    	endif;
    }
    
    public function admin_layout($body, $vars,  $return = FALSE)
    {
    	if($return):
    	 
    	$content = $this->view('admin/layout/view_header', $vars, $return);
    	$content .= $this->view('admin/'.$body, $vars, $return);
    	$content .= $this->view('admin/layout/view_footer', $vars, $return);
    	return $content;
    	 
    	else:
    	 
    	$this->view('admin/layout/view_header', $vars, $return);
    	$this->view('admin/'.$body, $vars, $return);
    	$this->view('admin/layout/view_footer', $vars, $return);
    	 
    	endif;
    }
}

/* End of file Someclass.php */