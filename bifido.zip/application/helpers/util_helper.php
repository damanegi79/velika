<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed'); 

function alertMsg($msg='', $url='') 
{
	$CI =& get_instance();
	echo "<meta http-equiv=\"content-type\" content=\"text/html; charset=".$CI->config->item('charset')."\">";
	echo "<script type='text/javascript'>alert('".$msg."');";
	if ($url)
	echo "location.replace('".$url."');";
	else
	echo "history.go(-1);";
	echo "</script>";
	exit;
}


function getMainTitle()
{
	$titleAr = array(
		array('title'=>'ABOUT BIFIDO', 'link'=>'/en/about'),
		array('title'=>'BIFIDUS STORY', 'link'=>'/en/story'),
		array('title'=>'RAW MATERIAL', 'link'=>'/en/material'),
		array('title'=>'PRODUCT', 'link'=>'/en/product'),
		array('title'=>'CUSTOMER', 'link'=>'/en/customer')
	);
	return $titleAr;
}

function getSubTitle()
{

	$titleAr = array();
    $titleAr[0] = array(
		array(
				array('title'=>'COMPANY', 'link'=>'/en/about/company'),
				array('title'=>'Company Profile', 'link'=>'/en/about/company/profile'),
				array('title'=>'History', 'link'=>'/en/about/company/history'),
				array('title'=>'Partners', 'link'=>'/en/about/company/partners'),
				array('title'=>'Contact Us ', 'link'=>'/en/about/company/contact_us'),
				array('title'=>'VOD', 'link'=>'/en/about/company/vod')
		),
		array(
				array('title'=>'DOWNLOAD', 'link'=>'/en/about/download'),
				array('title'=>'Brochure', 'link'=>'/en/about/download/brochure'),
				array('title'=>'Paper', 'link'=>'/en/about/download/paper'),
				array('title'=>'Patents', 'link'=>'/en/about/download/patents'),
				array('title'=>'Certificate', 'link'=>'/en/about/download/certificate'),
				array('title'=>'Honor', 'link'=>'/en/about/download/honor')
		)
	);

	$titleAr[1] = array();
	$titleAr[1][0] = array(
		array('title'=>'BIFIDUS STORY', 'link'=>'/en/story'),
		array('title'=>'Competitive Edge', 'link'=>'/en/story/competitive'),
		array('title'=>'Probiotics & Bifidus', 'link'=>'/en/story/probiotics'),
		array('title'=>'Core Strains', 'link'=>'/en/story/core_strains'),
		array('title'=>'Core Technology', 'link'=>'/en/story/core_technology'),
		array('title'=>'Character', 'link'=>'/en/story/character')
	);


	$titleAr[2] = array(
		array(
				array('title'=>'PROBIOTICS', 'link'=>'/en/material/probiotics'),
				array('title'=>'Raw Material', 'link'=>'/en/material/probiotics/raw_material'),
				array('title'=>'Immunity', 'link'=>'/en/material/probiotics/immunity'),
				array('title'=>'Gut Health', 'link'=>'/en/material/probiotics/gut_health'),
				array('title'=>'Woman Health', 'link'=>'/en/material/probiotics/woman_health')
		),
		array(
				array('title'=>'FERMENTED GINSENG', 'link'=>'/en/material/fermented_ginseng'),
				array('title'=>'Ginseng Story', 'link'=>'/en/material/fermented_ginseng/ginseng_story'),
				array('title'=>'Active G5', 'link'=>'/en/material/fermented_ginseng/active_g5')
		)
	);


	$titleAr[3] = array(
		array(
				array('title'=>'PROBIOTICS', 'link'=>'/en/product'),
				array('title'=>'Health Food', 'link'=>'/en/product/probiotics/health'),
				array('title'=>'Food', 'link'=>'/en/product/probiotics/food'),
				array('title'=>'Pet’s Feed', 'link'=>'/en/product/probiotics/pets_feed'),
				array('title'=>'Cosmetics', 'link'=>'/en/product/probiotics/cosmetics')
		),
		array(
				array('title'=>'FERMENTED GINSENG', 'link'=>'/en/product/fermented_ginseng'),
				array('title'=>'ZIGUNUK Brand', 'link'=>'/en/product/fermented_ginseng/zigunuk_brand'),
				array('title'=>'Partner’s Brand', 'link'=>'/en/product/fermented_ginseng/partners_brand')
		)
	);



	$titleAr[4] = array();
	$titleAr[4][0] = array(
			array('title'=>'CUSTOMER', 'link'=>'/en/customer'),
		array('title'=>'News', 'link'=>'/en/customer/news'),
		array('title'=>'Event', 'link'=>'/en/customer/event')
	);
	return $titleAr;
}




function get_depth( $title )
{
	$CI =& get_instance();
	$gnb = getMainTitle();
	$num = 0;
	
	for($i = 0; $i<count($gnb); $i++)
	{
		$list = $gnb[$i];

		if(strtolower($list['title']) == $CI->uri->segment(2) || 
		strpos(strtolower($list['title']), $CI->uri->segment(2))>-1 ||
		strpos($CI->uri->segment(2), strtolower($list['title']))>-1)
		{
			$num = $i;
			break;
		}
	}
	
	$all_menu = getSubTitle();
	$title = str_replace("_", " ", $title);
	$menuList = $all_menu[$num];
	
	for($i=0; $i<count($menuList); $i++)
	{
		$lists = $menuList[$i];
		
		for($j=1; $j<count($lists); $j++)
		{
			$tit = str_replace("’", "", strtolower($lists[$j]['title']));
			if($tit == $title)
			{
				return array('depth1'=>$num, 'depth2'=>$i, 'depth3'=>$j-1);
			}		
		}
		
		for($j=1; $j<count($lists); $j++)
		{
			$tit = strtolower($lists[$j]['title']);
			if(strpos($tit, $title)>-1 || strpos($title, $tit)>-1)
			{
				return array('depth1'=>$num, 'depth2'=>$i, 'depth3'=>$j-1);
			}
		}
	}
	
	return null;
}

function get_pagination_link( $baseUrl, $totalRows )
{
	$CI =& get_instance();
	$CI->load->library('pagination');
	
	$config['base_url'] = $baseUrl;
	$config['total_rows'] = $totalRows;
	$config['per_page'] = 10;
	$config['page_query_string'] = TRUE;
	$config['enable_query_strings'] = TRUE;
	
	$config['display_always'] = TRUE;
	$config['use_fixed_page'] = TRUE;
	$config['fixed_page_num'] = 5;
	
	$config['display_first_always'] = TRUE;
	$config['display_last_always'] = TRUE;
	$config['disable_first_link'] = TRUE;
	$config['disable_last_link'] = TRUE;
	
	$config['display_prev_always'] = TRUE;
	$config['display_next_always'] = TRUE;
	$config['disable_prev_link'] = TRUE;
	$config['disable_next_link'] = TRUE;
	$config['first_link'] = "<<";
	$config['last_link'] = ">>";
	
	
	
	$config['full_tag_open']='<ul class="pagination">';
	$config['full_tag_close']='</ul>';
	
	$config['num_tag_open']='<li>';
	$config['num_tag_close']='</li>';
	
	$config['prev_tag_open']='<li class="prev">';
	$config['prev_tag_close']='</li>';
	
	$config['next_tag_open']='<li class="next">';
	$config['next_tag_close']='</li>';
	
	$config['first_tag_open']='<li class="first">';
	$config['first_tag_close']='</li>';
	
	$config['last_tag_open']='<li class="last">';
	$config['last_tag_close']='</li>';
	
	$config['disabled_prev_tag_open'] = '<li class="prev disabled"><a>';
	$config['disabled_prev_tag_close'] = '</a></li>';
	
	$config['disabled_next_tag_open'] = '<li class="next disabled"><a>';
	$config['disabled_next_tag_close'] = '</a></li>';
	
	$config['disabled_first_tag_open'] = '<li class="first disabled"><a>';
	$config['disabled_first_tag_close'] = '</a></li>';
	
	$config['disabled_last_tag_open'] = '<li class="last disabled"><a>';
	$config['disabled_last_tag_close'] = '</a></li>';
	
	$config['cur_tag_open']='<li class="active"><a>';
	$config['cur_tag_close']='</a></li>';
	
	
	
	$CI->pagination->initialize($config);
	$link = $CI->pagination->create_links();
	
	return $link;
}

function month_to_eng( $month )
{
	switch ( $month )
	{
		case 1 : return 'January';break;
		case 2 : return 'February';break;
		case 3 : return 'March';break;
		case 4 : return 'April';break;
		case 5 : return 'May';break;
		case 6 : return 'June';break;
		case 7 : return 'July';break;
		case 8 : return 'August';break;
		case 9 : return 'September';break;
		case 10 : return 'October';break;
		case 11 : return 'November';break;
		case 12 : return 'December';break;
	}
}

function removeZero( $num )
{
	$first = substr($num, 0, 1);
	if((int)$first == 0) 
	{
		return substr($num, -1);
	}
	return $num;
}

 
