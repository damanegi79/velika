<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

Class Admin_m extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	function get_users_id( $id, $pass )
	{
		return db_query_row($this, "SELECT * FROM users WHERE id='".$id."' AND pass='".$pass."'");
	}
	
	function get_main_list()
	{
		return db_query_result($this, "SELECT * FROM main ORDER BY id DESC");
	}
	
	function get_vod_list()
	{
		return db_query_result($this, "SELECT * FROM vod ORDER BY id DESC");
	}
	
	function get_pdf_list( $cate )
	{
		return db_query_result($this, "SELECT * FROM pdf WHERE category1='".$cate."' ORDER BY id DESC");
	}
	
	
	
	
	
	
	function get_news_list( $lang, $offset, $search="")
	{
		if($search == "")
		{
			if(empty($lang))	$query = db_query_result($this, "SELECT * FROM news ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			else		        $query = db_query_result($this, "SELECT * FROM news WHERE (lang='".$lang."') ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
		}
		else 
		{
			if(empty($lang))	$query = db_query_result($this, "SELECT * FROM news WHERE title LIKE '%".$search."%' OR content LIKE '%".$search."%' ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			else		        $query = db_query_result($this, "SELECT * FROM news WHERE (lang='".$lang."') AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
		}
		return $query;
	}
	
	function get_news_list_row( $idx )
	{
		return db_query_row($this, "SELECT * FROM news WHERE idx='".$idx."'");
	}
	
	function get_news_list_prev( $lang, $id, $search="" )
	{
		if($search == "")
		{
			return db_query_row($this, "SELECT * FROM news WHERE (lang='".$lang."') AND id > ".$id." ORDER BY id ASC LIMIT 1");
		}
		else
		{
			return db_query_row($this, "SELECT * FROM news WHERE (lang='".$lang."') AND (id > ".$id.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id ASC LIMIT 1");
		}
		
		
	}
	
	
	function get_news_list_next( $lang, $id, $search="" )
	{
		if($search == "")
		{
			return db_query_row($this, "SELECT * FROM news WHERE (lang='".$lang."') AND (id < ".$id.") ORDER BY id DESC LIMIT 1");
		}
		else 
		{
			return db_query_row($this, "SELECT * FROM news WHERE (lang='".$lang."') AND (id < ".$id.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 1");
		}
	}
	
	
	function get_event_list( $lang, $offset, $cate="", $search="")
	{
		$date = date('Ymd');
		if($search == '')
		{
			if($cate == 'upcomming')
			{
				if(empty($lang))	$query = db_query_result($this, "SELECT * FROM event WHERE (e_date >= ".$date.") ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
				else		        $query = db_query_result($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (e_date >= ".$date.") ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			}
			else if($cate == 'last')
			{
				$date = date('Ymd');
				if(empty($lang))	$query = db_query_result($this, "SELECT * FROM event WHERE (e_date < ".$date.") ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
				else		        $query = db_query_result($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (e_date < ".$date.") ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			}
			else
			{
				if(empty($lang))	$query = db_query_result($this, "SELECT * FROM event ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
				else		        $query = db_query_result($this, "SELECT * FROM event WHERE lang='".$lang."' ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			}
		}
		else
		{
			if($cate == 'upcomming')
			{
				if(empty($lang))	$query = db_query_result($this, "SELECT * FROM event WHERE (e_date >= ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
				else		        $query = db_query_result($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (e_date >= ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			}
			else if($cate == 'last')
			{
				if(empty($lang))	$query = db_query_result($this, "SELECT * FROM event WHERE (e_date < ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
				else		        $query = db_query_result($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (e_date < ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			}
			else 
			{
				if(empty($lang))	$query = db_query_result($this, "SELECT * FROM event WHERE title LIKE '%".$search."%' OR content LIKE '%".$search."%' ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
				else		        $query = db_query_result($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 10 OFFSET ".$offset);
			}
		}
		return $query;
	}
	
	function get_event_list_row( $idx )
	{
		return db_query_row($this, "SELECT * FROM event WHERE idx='".$idx."'");
	}
	
	function get_event_list_prev( $lang, $id, $cate="", $search="" )
	{
		$date = date('Ymd');
		if($search == "")
		{
			if($cate == 'upcomming')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id > ".$id.") AND (e_date >= ".$date.") ORDER BY id ASC LIMIT 1");
			}
			else if($cate == 'last')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id > ".$id.") AND (e_date < ".$date.") ORDER BY id ASC LIMIT 1");
			}
			else 
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id > ".$id.") ORDER BY id ASC LIMIT 1");
			}
		}
		else
		{
			if($cate == 'upcomming')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id > ".$id.") AND (e_date >= ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id ASC LIMIT 1");
			}
			else if($cate == 'last')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id > ".$id.") AND (e_date < ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id ASC LIMIT 1");
			}
			else 
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id > ".$id.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id ASC LIMIT 1");
			}
		}
	
	
	}
	
	
	function get_event_list_next( $lang, $id, $cate="", $search="" )
	{
		$date = date('Ymd');
		if($search == "")
		{
			if($cate == 'upcomming')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id < ".$id.") AND (e_date >= ".$date.") ORDER BY id DESC LIMIT 1");
			}
			else if($cate == 'last')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id < ".$id.") AND (e_date < ".$date.") ORDER BY id DESC LIMIT 1");
			}
			else 
			{
				return db_query_row($this, "SELECT * FROM event WHERE lang='".$lang."' AND id < ".$id." ORDER BY id DESC LIMIT 1");
			}
		}
		else
		{
			if($cate == 'upcomming')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id < ".$id.") AND (e_date >= ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 1");
			}
			else if($cate == 'last')
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id < ".$id.") AND (e_date < ".$date.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 1");
			}
			else 
			{
				return db_query_row($this, "SELECT * FROM event WHERE (lang='".$lang."') AND (id < ".$id.") AND (title LIKE '%".$search."%' OR content LIKE '%".$search."%') ORDER BY id DESC LIMIT 1");
			}
		}
	}
	
	
	function insert_main($count, $imgPath, $mainTitleEn, $subTitleEn, $infoTextEn, $mainTitleKr, $subTitleKr, $infoTextKr, $mainTitleCh, $subTitleCh, $infoTextCh, $mainTitleVn, $subTitleVn, $infoTextVn)
	{
		$sql = "INSERT INTO main (count, imgPath, mainTitleEn, subTitleEn, infoTextEn, mainTitleKr, subTitleKr, infoTextKr, mainTitleCh, subTitleCh, infoTextCh, mainTitleVn, subTitleVn, infoTextVn)";
		$sql .= "VALUES ('".$count."', '".$imgPath."', '".$mainTitleEn."', '".$subTitleEn."', '".$infoTextEn."', '".$mainTitleKr."', '".$subTitleKr."', '".$infoTextKr."', '".$mainTitleCh."', '".$subTitleCh."', '".$infoTextCh."', '".$mainTitleVn."', '".$subTitleVn."', '".$infoTextVn."')";
		$query = $this->db->query($sql);
		return $query;
	}
	
	function insert_vod($imgPath, $category, $youtubePath, $titleEn, $titleKr, $titleCh, $titleVn)
	{
		$sql = "INSERT INTO vod (imgPath, category, youtubePath, titleEn, titleKr, titleCh, titleVn)";
		$sql .= "VALUES ('".$imgPath."', '".$category."', '".$youtubePath."', '".$titleEn."', '".$titleKr."', '".$titleCh."', '".$titleVn."')";
		$query = $this->db->query($sql);
		return $query;
	}
	
	function insert_pdf($filePath, $category1, $category2, $titleKr, $titleEn, $titleCh, $titleVn, $usedKr, $usedEn, $usedCh, $usedVn)
	{
		$sql = "INSERT INTO pdf (filePath, category1, category2, titleKr, titleEn, titleCh, titleVn, usedKr, usedEn, usedCh, usedVn)";
		$sql .= "VALUES ('".$filePath."', '".$category1."', '".$category2."', '".$titleKr."', '".$titleEn."', '".$titleCh."', '".$titleVn."', '".$usedKr."', '".$usedEn."', '".$usedCh."', '".$usedVn."')";
		$query = $this->db->query($sql);
		return $query;
	}
	
	function insert_news($date, $title, $content, $idx, $lang)
	{
		$sql = "INSERT INTO news (date, title, content, idx, lang)";
		$sql .= "VALUES ('".$date."', '".$title."', '".$content."', '".$idx."', '".$lang."')";
		$query = $this->db->query($sql);
		return $query;
	}
	
	function insert_event($date, $idx, $s_date, $e_date, $lang, $country, $title, $location, $sub_title, $content, $thumb)
	{
		$sql = "INSERT INTO event (date, s_date, e_date, title, location, subTitle, thumb, content, idx, lang, country)";
		$sql .= "VALUES ('".$date."', '".$s_date."', '".$e_date."', '".$title."', '".$location."', '".$sub_title."', '".$thumb."', '".$content."', '".$idx."', '".$lang."', '".$country."')";
		$query = $this->db->query($sql);
		return $query;
	}
	
	function delete_main( $id )
	{
		return $this->db->delete('main', array('id' => $id));
	}
	
	function delete_vod( $id )
	{
		return $this->db->delete('vod', array('id' => $id));
	}
	
	function delete_pdf( $id )
	{
		return $this->db->delete('pdf', array('id' => $id));
	}
	
	function delete_news( $idx )
	{
		return $this->db->where_in('idx', $idx)->delete('news');
	}
	
	function delete_event( $idx )
	{
		return $this->db->where_in('idx', $idx)->delete('event');
	}
	
	function modify_main($id, $data)
	{
		return $this->db->where('id', $id)->update('main', $data);
	}
	
	function modify_vod($id, $data)
	{
		return $this->db->where('id', $id)->update('vod', $data);
	}
	
	function modify_pdf($id, $data)
	{
		return $this->db->where('id', $id)->update('pdf', $data);
	}
	
	function modify_news($idx, $data)
	{
		return $this->db->where('idx', $idx)->update('news', $data);
	}
	
	function modify_event($idx, $data)
	{
		return $this->db->where('idx', $idx)->update('event', $data);
	}
	
}